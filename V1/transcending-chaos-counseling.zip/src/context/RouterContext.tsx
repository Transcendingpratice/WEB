import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type RoutePath =
  | "/"
  | "/providers"
  | `/providers/${string}`
  | "/services"
  | `/services/${string}`
  | "/schedule"
  | "/contact"
  | "/privacy"
  | "/good-faith-estimate"
  | "/404";

interface RouterContextType {
  currentPath: string;
  navigate: (path: string) => void;
  goBack: () => void;
}

const RouterContext = createContext<RouterContextType>({
  currentPath: "/",
  navigate: () => {},
  goBack: () => {},
});

function parseLocation(): string {
  // Support both hash routing and HTML5 path
  const hash = window.location.hash.replace(/^#/, "");
  if (hash) {
    return hash.startsWith("/") ? hash : `/${hash}`;
  }
  const pathname = window.location.pathname;
  return pathname && pathname !== "/" ? pathname : "/";
}

export const RouterProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentPath, setCurrentPath] = useState<string>(() => parseLocation());

  useEffect(() => {
    const handleLocationChange = () => {
      const nextPath = parseLocation();
      setCurrentPath(nextPath);
      window.scrollTo({ top: 0, behavior: "smooth" });
    };

    window.addEventListener("popstate", handleLocationChange);
    window.addEventListener("hashchange", handleLocationChange);

    return () => {
      window.removeEventListener("popstate", handleLocationChange);
      window.removeEventListener("hashchange", handleLocationChange);
    };
  }, []);

  const navigate = (path: string) => {
    const cleanPath = path.startsWith("/") ? path : `/${path}`;
    window.location.hash = cleanPath;
    setCurrentPath(cleanPath);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const goBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      navigate("/");
    }
  };

  return (
    <RouterContext.Provider value={{ currentPath, navigate, goBack }}>
      {children}
    </RouterContext.Provider>
  );
};

export const useRouter = () => useContext(RouterContext);
