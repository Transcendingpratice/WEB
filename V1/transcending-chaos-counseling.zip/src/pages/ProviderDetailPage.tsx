import React from "react";
import { PROVIDERS } from "../data/providers";
import { useRouter } from "../context/RouterContext";
import { SITE_INFO } from "../data/siteInfo";
import { CTASection } from "../components/CTASection";
import {
  Calendar,
  ArrowLeft,
  ArrowUpRight,
  Award,
  GraduationCap,
  FileCheck,
  CheckCircle,
  MapPin,
  Laptop,
  Users,
  Phone,
  ShieldCheck,
  Mail,
} from "lucide-react";
import {
  FadeIn,
  TextReveal,
  StaggerContainer,
  StaggerItem,
} from "../components/motion/MotionSystem";

export const ProviderDetailPage: React.FC<{ slug: string }> = ({ slug }) => {
  const { navigate } = useRouter();
  const provider = PROVIDERS.find((p) => p.slug === slug);

  if (!provider) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <h1 className="font-heading font-bold text-2xl text-slate-800 mb-4">
          Clinician Profile Not Found
        </h1>
        <p className="text-slate-600 mb-8">
          The requested provider profile does not exist or may have been updated.
        </p>
        <button
          onClick={() => navigate("/providers")}
          className="px-6 py-3 bg-[#174F86] text-white rounded-xl text-sm font-semibold hover:bg-[#0B2440] transition-colors"
        >
          View All Providers
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col w-full bg-white">
      {/* Seamless Breadcrumb Navigation */}
      <div className="bg-gradient-to-r from-[#F6F8FC] to-white py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onClick={() => navigate("/providers")}
            className="inline-flex items-center gap-2 text-xs font-semibold text-[#174F86] hover:text-[#0B2440] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Clinicians</span>
          </button>
        </div>
      </div>

      {/* Profile Header & Bio (Seamless gradient flowing down) */}
      <section className="relative py-12 sm:py-16 bg-gradient-to-b from-[#F6F8FC] via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Left: Clinician Photo & Sticky Companion Suite (Prevents empty wide spaces on laptop view) */}
            <div className="lg:col-span-4 flex flex-col gap-6 lg:sticky lg:top-24 self-start">
              <FadeIn direction="right" distance={24} delay={0.1}>
                <div className="relative rounded-2xl overflow-hidden border border-slate-100/90 shadow-lg shadow-blue-950/5 bg-[#F6F8FC] aspect-4/5 group">
                  <img
                    src={provider.image}
                    alt={`${provider.name}, ${provider.credentials}`}
                    className="w-full h-full object-cover object-top group-hover:scale-102 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />

                  <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs py-1 px-3 rounded-full text-xs font-semibold text-[#174F86] shadow-xs flex items-center gap-1.5 border border-slate-100/80">
                    <CheckCircle className="w-3.5 h-3.5 text-[#174F86]" />
                    <span>Accepting Clients</span>
                  </div>
                </div>
              </FadeIn>

              {/* Direct Booking Box with soft elevation */}
              <FadeIn direction="right" distance={24} delay={0.2}>
                <div className="p-6 rounded-2xl bg-white border border-slate-100/90 shadow-md shadow-blue-950/5 flex flex-col gap-4">
                  <h3 className="font-heading font-bold text-base text-[#0B2440]">
                    Schedule with {provider.name.split(" ")[0]}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Book directly via our encrypted SimplePractice portal. You can select either an in-person session in Tyngsborough or a virtual appointment.
                  </p>

                  <a
                    href={SITE_INFO.portalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl shadow-xs hover:shadow-md hover:-translate-y-0.5 text-center"
                  >
                    <Calendar className="w-4 h-4 text-[#0B2440]" />
                    <span>Book with {provider.name.split(" ")[0]}</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </a>

                  <div className="pt-3 border-t border-slate-100 flex flex-col gap-2 text-[11px] text-slate-500">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#174F86] shrink-0" />
                      <span>In-person: Tyngsborough, MA</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Laptop className="w-3.5 h-3.5 text-[#174F86] shrink-0" />
                      <span>Telehealth: Massachusetts & New Hampshire</span>
                    </div>
                  </div>
                </div>
              </FadeIn>

              {/* Direct Practice Contact Companion Card */}
              <FadeIn direction="right" distance={24} delay={0.3}>
                <div className="p-5 rounded-2xl bg-[#F6F8FC]/90 border border-slate-100/90 text-xs text-slate-600 space-y-3">
                  <div className="flex items-center gap-2 text-[#0B2440] font-bold text-xs uppercase tracking-wider">
                    <ShieldCheck className="w-4 h-4 text-[#174F86]" />
                    <span>Practice Assurance</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-slate-500">
                    Have questions regarding insurance coverage, scheduling coordination, or clinical fit? Reach out directly to our administrative team.
                  </p>
                  <div className="pt-2 border-t border-slate-200/60 flex flex-col gap-2">
                    <a
                      href={`tel:${SITE_INFO.phoneRaw}`}
                      className="flex items-center gap-2 font-semibold text-[#174F86] hover:underline"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#F5BD00]" />
                      <span>{SITE_INFO.phone}</span>
                    </a>
                    <a
                      href={`mailto:${SITE_INFO.email}`}
                      className="flex items-center gap-2 font-medium text-slate-600 hover:text-[#174F86] transition-colors break-all"
                    >
                      <Mail className="w-3.5 h-3.5 text-slate-400" />
                      <span>{SITE_INFO.email}</span>
                    </a>
                  </div>
                </div>
              </FadeIn>
            </div>

            {/* Right: Full Verified Biography & Clinical Qualifications */}
            <div className="lg:col-span-8 flex flex-col min-w-0">
              <FadeIn direction="up" distance={20} delay={0.1}>
                <div className="pb-6 mb-8 min-w-0">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2">
                    <Award className="w-4 h-4 text-[#F5BD00] shrink-0" />
                    <span>{provider.experience}</span>
                  </div>

                  <TextReveal
                    tag="h1"
                    text={provider.name}
                    className="font-heading font-extrabold text-2xl sm:text-4xl md:text-5xl text-[#0B2440] tracking-tight leading-tight break-words"
                  />
                  <p className="text-sm sm:text-base font-semibold text-[#174F86] mt-1.5 break-words">
                    {provider.credentials}
                  </p>
                  <p className="text-xs sm:text-sm text-slate-600 mt-1 break-words leading-relaxed">{provider.title}</p>
                </div>
              </FadeIn>

              {/* Biography Prose */}
              <FadeIn direction="up" distance={20} delay={0.2} className="mb-10">
                <h2 className="font-heading font-bold text-lg text-[#0B2440] mb-4">
                  Clinical Biography & Philosophy
                </h2>
                <div className="space-y-4 text-base text-slate-700 leading-relaxed">
                  {provider.fullBio.map((paragraph, idx) => (
                    <p key={idx}>{paragraph}</p>
                  ))}
                </div>
              </FadeIn>

              {/* Treatment Specialties & Client Focus */}
              <FadeIn direction="up" distance={20} delay={0.25} className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10 pt-8 border-t border-slate-100">
                <div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] mb-3 flex items-center gap-2">
                    <Award className="w-4 h-4 text-[#174F86]" />
                    <span>Treatment Specialties</span>
                  </h3>
                  <ul className="space-y-2 text-sm text-slate-600">
                    {provider.specialties.map((spec) => (
                      <li key={spec} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#174F86] shrink-0 mt-2" />
                        <span>{spec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] mb-3 flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#174F86]" />
                    <span>Client Focus</span>
                  </h3>
                  <ul className="space-y-2 text-sm text-slate-600">
                    {provider.clientFocus.map((focus) => (
                      <li key={focus} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#F5BD00] shrink-0 mt-2" />
                        <span>{focus}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </FadeIn>

              {/* Therapeutic Approaches & Modalities */}
              <FadeIn direction="up" distance={20} delay={0.3} className="mb-10 pt-8 border-t border-slate-100">
                <h3 className="font-heading font-bold text-base text-[#0B2440] mb-3">
                  Therapeutic Approaches & Modalities
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-slate-700">
                  {provider.modalities.map((mod) => (
                    <div key={mod} className="flex items-center gap-2 p-3 rounded-xl bg-[#F6F8FC] hover:bg-[#EEF4FB] transition-colors">
                      <CheckCircle className="w-4 h-4 text-[#174F86] shrink-0" />
                      <span>{mod}</span>
                    </div>
                  ))}
                </div>
              </FadeIn>

              {/* Education & Licensures */}
              <FadeIn direction="up" distance={20} delay={0.35} className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8 border-t border-slate-100">
                <div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] mb-3 flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-[#174F86]" />
                    <span>Education</span>
                  </h3>
                  <ul className="space-y-2 text-sm text-slate-600">
                    {provider.education.map((edu) => (
                      <li key={edu} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#174F86] shrink-0 mt-2" />
                        <span>{edu}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] mb-3 flex items-center gap-2">
                    <FileCheck className="w-4 h-4 text-[#174F86]" />
                    <span>State Licensures & Certifications</span>
                  </h3>
                  <ul className="space-y-2 text-sm text-slate-600">
                    {provider.licenses.map((lic) => (
                      <li key={lic} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#174F86] shrink-0 mt-2" />
                        <span>{lic}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      <CTASection
        title={`Begin Therapy with ${provider.name}`}
        description={`Schedule an in-person session in Tyngsborough or a virtual consultation across Massachusetts & New Hampshire.`}
      />
    </div>
  );
};
