import React, { useState } from "react";
import { SERVICES } from "../data/services";
import { ServiceCard } from "../components/ServiceCard";
import { CTASection } from "../components/CTASection";
import { useRouter } from "../context/RouterContext";
import {
  Laptop,
  MapPin,
  Clock,
  Shield,
  Award,
  ShieldAlert,
  Brain,
} from "lucide-react";
import {
  FadeIn,
  TextReveal,
  StaggerContainer,
  StaggerItem,
  ScaleIn,
} from "../components/motion/MotionSystem";

export const ServicesPage: React.FC = () => {
  const { navigate } = useRouter();
  const [activeFilter, setActiveFilter] = useState<string>("all");

  const filterTabs = [
    { id: "all", label: "All Services" },
    { id: "telehealth", label: "Telehealth / Online (MA & NH)" },
    { id: "in-person", label: "In-Person (Tyngsborough, MA)" },
    { id: "core", label: "Individual & Couple Therapy" },
    { id: "evaluations", label: "Court, Probation & RMV Evaluations" },
    { id: "variety", label: "Services for Specific Needs" },
    { id: "coming-soon", label: "Coming Soon! (Early 2027)" },
  ];

  const filteredServices = SERVICES.filter((service) => {
    if (activeFilter === "all") return true;
    if (activeFilter === "telehealth") {
      return service.deliveryModes.includes("telehealth");
    }
    if (activeFilter === "in-person") {
      return service.deliveryModes.includes("in-person");
    }
    if (activeFilter === "core") {
      return service.slug === "individual-therapy" || service.slug === "couples-therapy";
    }
    if (activeFilter === "evaluations") {
      return service.slug === "court-probation-evaluations";
    }
    if (activeFilter === "variety") {
      return (
        service.slug === "first-responders" ||
        service.slug === "veterans" ||
        service.slug === "addiction" ||
        service.slug === "mental-health"
      );
    }
    if (activeFilter === "coming-soon") {
      return service.isComingSoon;
    }
    return true;
  });

  return (
    <div className="flex flex-col w-full bg-white">
      {/* Header section with unified color gradient overlay & blended background (Inspired by Trust Therapeutics) */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#07172B] via-[#0B2440] to-[#103761] text-white py-14 sm:py-20">
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {/* Subtle textured background image with clear visibility */}
          <img
            src="/assets/services/serene-nature.jpg"
            alt=""
            aria-hidden="true"
            className="w-full h-full object-cover object-center opacity-70 filter brightness-95 contrast-105"
            referrerPolicy="no-referrer"
          />
          {/* Full-bleed rich brand color gradient overlay across the entire width */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#071626]/85 via-[#0B2440]/70 to-[#103761]/55" />
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#F5BD00]/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#174F86]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#F5BD00] mb-3 inline-block">
                TRANSCENDING CHAOS COUNSELING
              </span>
            </FadeIn>

            <TextReveal
              tag="h1"
              text="Our Clinical Services"
              className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-tight mb-4"
            />

            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base sm:text-lg text-slate-200 leading-relaxed mb-8">
                We provide evidence-based, client-centered care available through virtual <strong>Telehealth Therapy / Online</strong> across Massachusetts & New Hampshire, and confidential <strong>In-Person Therapy</strong> at our Tyngsborough, MA practice suites.
              </p>
            </FadeIn>

            {/* Delivery Pathways Banner with soft glass elevation */}
            <FadeIn direction="up" distance={20} delay={0.25}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl">
                <div
                  onClick={() => navigate("/services/telehealth-therapy")}
                  className="group p-4.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 hover:border-[#F5BD00]/40 shadow-xs hover:shadow-lg transition-all duration-300 flex items-center gap-4 cursor-pointer hover:-translate-y-0.5"
                >
                  <div className="w-11 h-11 rounded-xl bg-[#174F86] text-white flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                    <Laptop className="w-5 h-5 text-[#F5BD00]" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-[#F5BD00] tracking-wider block">
                      Virtual Care
                    </span>
                    <span className="font-heading font-bold text-sm text-white group-hover:text-[#F5BD00] transition-colors">
                      Telehealth Therapy / Online
                    </span>
                    <p className="text-[11px] text-slate-300">Virtual Care across MA & NH</p>
                  </div>
                </div>

                <div
                  onClick={() => navigate("/services/in-person-therapy")}
                  className="group p-4.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 hover:border-[#F5BD00]/40 shadow-xs hover:shadow-lg transition-all duration-300 flex items-center gap-4 cursor-pointer hover:-translate-y-0.5"
                >
                  <div className="w-11 h-11 rounded-xl bg-white/15 text-white flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                    <MapPin className="w-5 h-5 text-[#F5BD00]" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-[#F5BD00] tracking-wider block">
                      Office Sanctuary
                    </span>
                    <span className="font-heading font-bold text-sm text-white group-hover:text-[#F5BD00] transition-colors">
                      In-Person Therapy
                    </span>
                    <p className="text-[11px] text-slate-300">Tyngsborough, MA Sanctuary</p>
                  </div>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Services Grid Section */}
      <section className="relative py-12 sm:py-16 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Functional filter tabs */}
          <FadeIn direction="down" distance={16} delay={0.1}>
            <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 sm:mb-10 no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mr-2 shrink-0">
                Filter By Category:
              </span>
              {filterTabs.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveFilter(tab.id)}
                  className={`px-4 py-2 text-xs font-medium rounded-full transition-all duration-200 whitespace-nowrap shrink-0 ${
                    activeFilter === tab.id
                      ? "bg-[#174F86] text-white shadow-md shadow-blue-900/15 font-semibold scale-102"
                      : "bg-white/80 border border-slate-200/60 text-slate-700 hover:bg-[#EAF2FA] hover:text-[#174F86]"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </FadeIn>

          {/* Active Services Cards with StaggerContainer - Adaptive layout prevents empty column voids on laptop */}
          <StaggerContainer
            key={activeFilter}
            staggerDelay={0.07}
            initialDelay={0.05}
            className={`grid gap-8 ${
              filteredServices.length === 1
                ? "grid-cols-1 max-w-xl mx-auto"
                : filteredServices.length === 2
                ? "grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto"
                : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
            }`}
          >
            {filteredServices.map((service) => (
              <StaggerItem key={service.id} direction="up" distance={20}>
                <ServiceCard service={service} />
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* Services Breakdown by Specific Needs (Seamless blend, no harsh top border) */}
      <section className="relative py-14 sm:py-20 bg-gradient-to-b from-white via-[#F6F8FC] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-14">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2 inline-block">
                SPECIALIZED CLINICAL CARE
              </span>
            </FadeIn>
            <TextReveal
              tag="h2"
              text="Services Offered to a Variety of Needs"
              className="font-heading font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#0B2440] tracking-tight"
            />
            <FadeIn direction="up" distance={16} delay={0.15}>
              <p className="text-sm sm:text-base text-slate-600 mt-2 leading-relaxed max-w-2xl mx-auto">
                We specialize in providing culturally competent, trauma-informed, and evidence-based treatment for complex behavioral health needs.
              </p>
            </FadeIn>
          </div>

          <StaggerContainer
            staggerDelay={0.09}
            initialDelay={0.1}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {/* First Responders */}
            <StaggerItem direction="up" distance={24}>
              <div
                onClick={() => navigate("/services/first-responders")}
                className="p-7 rounded-2xl bg-white/90 backdrop-blur-xs border border-slate-100/90 hover:border-[#174F86]/30 cursor-pointer transition-all duration-300 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 group flex flex-col justify-between h-full"
              >
                <div>
                  <div className="w-11 h-11 rounded-xl bg-[#EAF2FA] text-[#174F86] flex items-center justify-center mb-4 group-hover:bg-[#174F86] group-hover:text-white transition-colors duration-300 shadow-xs">
                    <Shield className="w-5 h-5" />
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2">
                    First Responders
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    Police, Firefighters, EMTs, Paramedics, Dispatchers & Emergency Personnel.
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#174F86] inline-flex items-center gap-1 group-hover:gap-1.5 transition-all">
                  <span>Learn More</span>
                  <span>→</span>
                </span>
              </div>
            </StaggerItem>

            {/* Veterans */}
            <StaggerItem direction="up" distance={24}>
              <div
                onClick={() => navigate("/services/veterans")}
                className="p-7 rounded-2xl bg-white/90 backdrop-blur-xs border border-slate-100/90 hover:border-[#174F86]/30 cursor-pointer transition-all duration-300 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 group flex flex-col justify-between h-full"
              >
                <div>
                  <div className="w-11 h-11 rounded-xl bg-[#EAF2FA] text-[#174F86] flex items-center justify-center mb-4 group-hover:bg-[#174F86] group-hover:text-white transition-colors duration-300 shadow-xs">
                    <Award className="w-5 h-5" />
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2">
                    Veterans
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    Civilian reintegration, combat & operational trauma, moral injury, and family adjustment.
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#174F86] inline-flex items-center gap-1 group-hover:gap-1.5 transition-all">
                  <span>Learn More</span>
                  <span>→</span>
                </span>
              </div>
            </StaggerItem>

            {/* Addiction */}
            <StaggerItem direction="up" distance={24}>
              <div
                onClick={() => navigate("/services/addiction")}
                className="p-7 rounded-2xl bg-white/90 backdrop-blur-xs border border-slate-100/90 hover:border-[#174F86]/30 cursor-pointer transition-all duration-300 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 group flex flex-col justify-between h-full"
              >
                <div>
                  <div className="w-11 h-11 rounded-xl bg-[#EAF2FA] text-[#174F86] flex items-center justify-center mb-4 group-hover:bg-[#174F86] group-hover:text-white transition-colors duration-300 shadow-xs">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2">
                    Addiction
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    Alcohol, Drug, Gambling, Video Game, Sex, and Other Addictions with dual diagnosis care.
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#174F86] inline-flex items-center gap-1 group-hover:gap-1.5 transition-all">
                  <span>Learn More</span>
                  <span>→</span>
                </span>
              </div>
            </StaggerItem>

            {/* Mental Health */}
            <StaggerItem direction="up" distance={24}>
              <div
                onClick={() => navigate("/services/mental-health")}
                className="p-7 rounded-2xl bg-white/90 backdrop-blur-xs border border-slate-100/90 hover:border-[#174F86]/30 cursor-pointer transition-all duration-300 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 group flex flex-col justify-between h-full"
              >
                <div>
                  <div className="w-11 h-11 rounded-xl bg-[#EAF2FA] text-[#174F86] flex items-center justify-center mb-4 group-hover:bg-[#174F86] group-hover:text-white transition-colors duration-300 shadow-xs">
                    <Brain className="w-5 h-5" />
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2">
                    Mental Health
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    Depression, OCD, PTSD, ADHD, Anxiety, BPD, Bipolar, Schizophrenia, and Personality Disorders.
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#174F86] inline-flex items-center gap-1 group-hover:gap-1.5 transition-all">
                  <span>Learn More</span>
                  <span>→</span>
                </span>
              </div>
            </StaggerItem>
          </StaggerContainer>
        </div>
      </section>

      {/* Coming Soon Section (Seamless deep navy transition) */}
      <section className="relative py-14 sm:py-20 bg-gradient-to-b from-white via-[#0B2440] to-[#0B2440] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScaleIn delay={0.1}>
            <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-slate-900/90 via-[#103761]/90 to-[#0B2440]/90 border border-white/10 shadow-2xl relative overflow-hidden backdrop-blur-md">
              <div className="max-w-3xl relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F5BD00]/20 text-[#F5BD00] text-xs font-semibold uppercase tracking-wider mb-4 border border-[#F5BD00]/30">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Coming Soon! (Early 2027)</span>
                </div>
                <h2 className="font-heading font-extrabold text-2xl sm:text-3xl md:text-4xl text-white tracking-tight mb-3">
                  Group Therapy Cohorts
                </h2>
                <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-8">
                  We are actively developing structured, therapist-facilitated group cohorts to launch in early 2027:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all hover:-translate-y-0.5">
                    <h4 className="font-heading font-bold text-sm text-[#F5BD00] mb-1.5">
                      Mental Health Group Therapy
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Depression, anxiety, and emotional resilience in a supportive peer cohort.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all hover:-translate-y-0.5">
                    <h4 className="font-heading font-bold text-sm text-[#F5BD00] mb-1.5">
                      Addiction Group Therapy
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Shared recovery maintenance, trigger processing, and accountability.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all hover:-translate-y-0.5">
                    <h4 className="font-heading font-bold text-sm text-[#F5BD00] mb-1.5">
                      Gambling Group Therapy
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Targeted cognitive strategies to interrupt compulsive gambling patterns.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </ScaleIn>
        </div>
      </section>

      <CTASection />
    </div>
  );
};
