import React from "react";
import { useRouter } from "../context/RouterContext";
import { SITE_INFO } from "../data/siteInfo";
import { PROVIDERS } from "../data/providers";
import { SERVICES } from "../data/services";
import { ProviderCard } from "../components/ProviderCard";
import { ServiceCard } from "../components/ServiceCard";
import { CTASection } from "../components/CTASection";
import { BrandEmblem } from "../components/BrandLogo";
import {
  Calendar,
  Compass,
  ArrowRight,
  ShieldCheck,
  MapPin,
  Laptop,
  CheckCircle2,
  Users2,
  Heart,
  Brain,
  Clock,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";
import {
  FadeIn,
  TextReveal,
  StaggerContainer,
  StaggerItem,
  ImageReveal,
  ScaleIn,
} from "../components/motion/MotionSystem";

export const HomePage: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="flex flex-col w-full bg-white">
      {/* SECTION A: HERO SECTION (Split-screen editorial layout with seamless gradient blend) */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#F6F8FC] via-white to-[#F0F5FA] pt-12 sm:pt-16 pb-16 sm:pb-20">
        {/* Subtle ambient light shapes */}
        <div className="absolute top-10 left-1/4 w-96 h-96 bg-[#174F86]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-[#F5BD00]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
            {/* Left Column (Content) */}
            <div className="lg:col-span-7 flex flex-col items-start z-10">
              {/* Brand Label */}
              <FadeIn direction="down" distance={16} delay={0.05}>
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/90 shadow-xs border border-slate-200/60 text-[#174F86] text-xs font-bold uppercase tracking-wider mb-6">
                  <span className="w-2 h-2 rounded-full bg-[#F5BD00]" />
                  <span>Transcending Chaos Counseling</span>
                </div>
              </FadeIn>

              {/* Editorial Headline with Word-by-Word Motion Reveal */}
              <TextReveal
                tag="h1"
                text="Go Beyond The Range of Unpredictability."
                className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] text-[#0B2440] tracking-tight mb-6 leading-[1.12]"
              />

              {/* Supporting Description */}
              <FadeIn direction="up" distance={20} delay={0.2}>
                <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mb-8">
                  {SITE_INFO.heroDescription}
                </p>
              </FadeIn>

              {/* Primary & Secondary CTAs */}
              <FadeIn direction="up" distance={20} delay={0.3}>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto mb-10 max-w-full">
                  <a
                    href={SITE_INFO.portalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-5 sm:px-7 py-3.5 sm:py-4 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl shadow-md hover:shadow-xl hover:-translate-y-0.5 text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#174F86]"
                  >
                    <Calendar className="w-4 h-4 text-[#0B2440] shrink-0" />
                    <span>Schedule an Appointment</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" />
                  </a>

                  <button
                    type="button"
                    onClick={() => navigate("/services")}
                    className="inline-flex items-center justify-center gap-2 px-5 sm:px-7 py-3.5 sm:py-4 text-xs font-bold uppercase tracking-wider text-[#174F86] bg-[#EAF2FA] hover:bg-[#d9e8f7] active:scale-98 transition-all rounded-xl text-center hover:-translate-y-0.5"
                  >
                    <span>Explore Our Services</span>
                    <ArrowRight className="w-4 h-4 shrink-0" />
                  </button>
                </div>
              </FadeIn>

              {/* Verified Trust Pillars (Seamless flowing typography) */}
              <StaggerContainer
                staggerDelay={0.08}
                initialDelay={0.4}
                className="pt-6 border-t border-slate-200/50 w-full grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-600"
              >
                <StaggerItem direction="up" distance={12} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0" />
                  <span className="font-medium">Licensed in MA & NH</span>
                </StaggerItem>
                <StaggerItem direction="up" distance={12} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0" />
                  <span className="font-medium">Tyngsborough In-Person</span>
                </StaggerItem>
                <StaggerItem direction="up" distance={12} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0" />
                  <span className="font-medium">HIPAA Secure Portal</span>
                </StaggerItem>
              </StaggerContainer>
            </div>

            {/* Right Column (Hero Sanctuary Imagery & Calming Composition) */}
            <div className="lg:col-span-5 relative">
              <FadeIn direction="left" distance={30} delay={0.25} duration={0.85}>
                <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-blue-950/10 border border-white/80 group">
                  <img
                    src="/assets/hero/hero-sanctuary.jpg"
                    alt="Transcending Chaos Counseling peaceful modern therapy sanctuary with natural sunlight"
                    className="w-full aspect-4/3 object-cover group-hover:scale-103 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B2440]/80 via-transparent to-transparent pointer-events-none" />

                  {/* Floating practice trust tag */}
                  <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-4 rounded-xl border border-white/60 shadow-lg">
                    <div className="flex items-start gap-3">
                      <BrandEmblem size={32} className="shrink-0 mt-0.5" />
                      <div>
                        <p className="font-heading font-bold text-sm text-[#0B2440]">
                          Compassionate Clinical Sanctuary
                        </p>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Client-centered therapy tailored to help you navigate life's most complex transitions.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Decorative brand ambient glow */}
                <div className="absolute -top-4 -right-4 w-28 h-28 bg-[#F5BD00]/25 rounded-full blur-2xl -z-10 pointer-events-none" />
                <div className="absolute -bottom-6 -left-6 w-36 h-36 bg-[#174F86]/15 rounded-full blur-2xl -z-10 pointer-events-none" />
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION B: CLINICAL FOUNDATION & CARE PATHWAYS (Seamlessly flowing into white/soft blue) */}
      <section className="relative py-14 sm:py-18 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-14">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-3 inline-block">
                OUR CLINICAL FOUNDATION
              </span>
            </FadeIn>
            <TextReveal
              tag="h2"
              text="Therapeutic Excellence, Thoughtfully Delivered"
              className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight mb-5"
            />
            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed mb-4">
                "Rooted in evidence-based modalities, our practice offers a client-centered approach to help guide you through life's journey."
              </p>
              <p className="text-sm text-slate-500 leading-relaxed max-w-2xl mx-auto">
                We offer individual and couples therapy in person at our peaceful office in <strong>Tyngsborough, Massachusetts</strong>, as well as confidential virtual telehealth sessions for clients located across <strong>Massachusetts and New Hampshire</strong>.
              </p>
            </FadeIn>
          </div>

          {/* Seamless Dual Delivery Access (Unboxed, fluid editorial style) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <FadeIn direction="right" distance={24} delay={0.2}>
              <div
                onClick={() => navigate("/services/in-person-therapy")}
                className="group relative p-8 rounded-2xl bg-gradient-to-b from-white to-[#F8FAFD] border border-slate-100/90 hover:border-[#174F86]/30 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 transition-all duration-300 cursor-pointer flex items-start gap-5"
              >
                <div className="w-12 h-12 rounded-xl bg-[#EAF2FA] group-hover:bg-[#174F86] text-[#174F86] group-hover:text-white transition-all duration-300 shadow-xs flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#174F86] block mb-1">
                    Office Sanctuary
                  </span>
                  <h3 className="font-heading font-bold text-lg text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2">
                    In-Person Therapy in Tyngsborough
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-4">
                    Located at 1 Bridgeview Circle, Suite 5. A quiet, welcoming setting designed for deep emotional safety, reflection, and personalized therapeutic care.
                  </p>
                  <span className="text-xs font-semibold text-[#174F86] inline-flex items-center gap-1 group-hover:gap-1.5 transition-all">
                    <span>Convenient to Lowell, Chelmsford, Westford & Southern NH</span>
                    <span>→</span>
                  </span>
                </div>
              </div>
            </FadeIn>

            <FadeIn direction="left" distance={24} delay={0.3}>
              <div
                onClick={() => navigate("/services/telehealth-therapy")}
                className="group relative p-8 rounded-2xl bg-gradient-to-b from-white to-[#F8FAFD] border border-slate-100/90 hover:border-[#174F86]/30 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 transition-all duration-300 cursor-pointer flex items-start gap-5"
              >
                <div className="w-12 h-12 rounded-xl bg-[#EAF2FA] group-hover:bg-[#174F86] text-[#174F86] group-hover:text-white transition-all duration-300 shadow-xs flex items-center justify-center shrink-0">
                  <Laptop className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#174F86] block mb-1">
                    Virtual Telehealth
                  </span>
                  <h3 className="font-heading font-bold text-lg text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2">
                    Virtual Sessions Across MA & NH
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-4">
                    State-licensed telehealth sessions conducted through our encrypted, HIPAA-compliant SimplePractice video portal from the privacy of your home or office.
                  </p>
                  <span className="text-xs font-semibold text-[#174F86] inline-flex items-center gap-1 group-hover:gap-1.5 transition-all">
                    <span>Licensed in Massachusetts & New Hampshire</span>
                    <span>→</span>
                  </span>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* SECTION C: OUR CLINICAL APPROACH (Fluid gradient blend into misty soft blue) */}
      <section className="relative py-14 sm:py-20 bg-gradient-to-b from-white via-[#F6F8FC] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-3 inline-block">
                PRACTICE PHILOSOPHY
              </span>
            </FadeIn>
            <TextReveal
              tag="h2"
              text="Our Clinical Approach"
              className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight mb-4"
            />
            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base text-slate-600 leading-relaxed">
                We reject rigid, one-size-fits-all treatments. We meet each person where they are at, combining rigorous clinical methods with deep human empathy.
              </p>
            </FadeIn>
          </div>

          <StaggerContainer
            staggerDelay={0.08}
            initialDelay={0.15}
            className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6"
          >
            {[
              {
                title: "Client-Centered Care",
                desc: "Your lived experience and values anchor our work together. We partner with you to establish meaningful, realistic treatment goals.",
                icon: <Heart className="w-5 h-5 text-[#174F86]" />,
              },
              {
                title: "Evidence-Based Modalities",
                desc: "Grounded in CBT, DBT, ACT, trauma-informed care, and family systems to ensure proven clinical reliability.",
                icon: <Brain className="w-5 h-5 text-[#174F86]" />,
              },
              {
                title: "Individualized Treatment",
                desc: "Care plans customized to your unique developmental stage, neurodivergence, or specific addiction history.",
                icon: <Compass className="w-5 h-5 text-[#174F86]" />,
              },
              {
                title: "Compassionate Guidance",
                desc: "A warm, judgment-free space where you can speak with radical honesty and begin processing painful burdens.",
                icon: <Users2 className="w-5 h-5 text-[#174F86]" />,
              },
              {
                title: "Resilience & Growth",
                desc: "Equipping you with mental mastery, self-regulation, and boundary tools that endure long after therapy concludes.",
                icon: <ShieldCheck className="w-5 h-5 text-[#174F86]" />,
              },
            ].map((pillar) => (
              <StaggerItem
                key={pillar.title}
                direction="up"
                distance={24}
                className="group relative bg-white/80 backdrop-blur-xs p-6 rounded-2xl border border-slate-100/90 hover:border-[#174F86]/25 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-[#EAF2FA] group-hover:bg-[#174F86] group-hover:text-white transition-all duration-300 flex items-center justify-center mb-4 shadow-xs">
                    {pillar.icon}
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2">
                    {pillar.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {pillar.desc}
                  </p>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* SECTION D: SERVICES PREVIEW (Seamless transition into clean white) */}
      <section className="relative py-14 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-12 gap-6">
            <div>
              <FadeIn direction="down" distance={16}>
                <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-3 inline-block">
                  COMPREHENSIVE CARE
                </span>
              </FadeIn>
              <TextReveal
                tag="h2"
                text="Our Services"
                className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight"
              />
              <FadeIn direction="up" distance={16} delay={0.15}>
                <p className="text-base text-slate-600 mt-2 max-w-xl">
                  Explore our comprehensive clinical treatment offerings, from individual and couples therapy to specialized addiction recovery, first responder support, and court evaluations.
                </p>
              </FadeIn>
            </div>

            <FadeIn direction="left" distance={20} delay={0.2}>
              <button
                type="button"
                onClick={() => navigate("/services")}
                className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#174F86] hover:text-[#0B2440] transition-colors shrink-0 group py-2"
              >
                <span>View All Our Services</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </button>
            </FadeIn>
          </div>

          <StaggerContainer
            staggerDelay={0.07}
            initialDelay={0.1}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {SERVICES.filter((s) => !s.isComingSoon).map((service) => (
              <StaggerItem key={service.id} direction="up" distance={24}>
                <ServiceCard service={service} />
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* SECTION E: MEET OUR PROVIDERS (Seamless gradient blend into soft mist) */}
      <section className="relative py-14 sm:py-20 bg-gradient-to-b from-white via-[#F6F8FC] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-14">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-3 inline-block">
                CLINICAL TEAM
              </span>
            </FadeIn>
            <TextReveal
              tag="h2"
              text="Meet Our Providers"
              className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight mb-4"
            />
            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base text-slate-600 leading-relaxed">
                Our clinicians bring decades of combined outpatient experience, advanced licenses, and specialized training in addiction, family dynamics, and trauma recovery.
              </p>
            </FadeIn>
          </div>

          <StaggerContainer
            staggerDelay={0.1}
            initialDelay={0.1}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {PROVIDERS.map((provider) => (
              <StaggerItem key={provider.id} direction="up" distance={28}>
                <ProviderCard provider={provider} />
              </StaggerItem>
            ))}
          </StaggerContainer>

          <FadeIn direction="up" distance={20} delay={0.3} className="mt-12 text-center">
            <button
              type="button"
              onClick={() => navigate("/providers")}
              className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider px-6 py-3.5 rounded-xl bg-white border border-slate-200 hover:border-[#174F86] text-[#0B2440] hover:text-[#174F86] transition-all shadow-xs hover:shadow-md hover:-translate-y-0.5"
            >
              <span>Read Full Clinician Biographies & Credentials</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </FadeIn>
        </div>
      </section>

      {/* SECTION F: IN-PERSON AND VIRTUAL THERAPY DETAILS (Editorial layout with overlapping imagery) */}
      <section className="relative py-14 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Visual side with ImageReveal and floating location badge */}
            <div className="lg:col-span-5 relative order-2 lg:order-1">
              <FadeIn direction="right" distance={30} delay={0.15}>
                <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-blue-950/10 border border-slate-100 group">
                  <img
                    src="/assets/services/counseling-space.jpg"
                    alt="Transcending Chaos Counseling welcoming consultation space"
                    className="w-full aspect-4/3 object-cover group-hover:scale-103 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B2440]/60 via-transparent to-transparent pointer-events-none" />
                </div>
                <div className="absolute -bottom-5 -right-5 hidden sm:block p-4 rounded-xl bg-[#0B2440] text-white shadow-xl max-w-xs border border-white/10">
                  <p className="text-xs font-semibold text-[#F5BD00] flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Convenient Location</span>
                  </p>
                  <p className="text-[11px] text-slate-300 mt-1">
                    1 Bridgeview Circle, Suite 5, Tyngsborough, MA 01879
                  </p>
                </div>
              </FadeIn>
            </div>

            {/* Explanation side */}
            <div className="lg:col-span-7 order-1 lg:order-2">
              <FadeIn direction="down" distance={16}>
                <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-3 inline-block">
                  FLEXIBLE CARE OPTIONS
                </span>
              </FadeIn>
              <TextReveal
                tag="h2"
                text="Care Tailored to Your Life & Schedule"
                className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight mb-5"
              />
              <FadeIn direction="up" distance={20} delay={0.15}>
                <p className="text-base text-slate-600 leading-relaxed mb-6">
                  Whether you prefer the tangible calm of an in-person therapy office or the convenience and privacy of telehealth from home, Transcending Chaos Counseling offers adaptable care.
                </p>
              </FadeIn>

              <StaggerContainer staggerDelay={0.08} initialDelay={0.2} className="space-y-4 mb-8">
                <StaggerItem direction="up" distance={16} className="flex items-start gap-3.5">
                  <div className="w-6 h-6 rounded-full bg-[#EAF2FA] text-[#174F86] flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-sm text-[#0B2440]">
                      In-Person Sessions in Tyngsborough, MA
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Easily accessible from Route 3. Convenient for clients in Tyngsborough, Chelmsford, Lowell, Westford, Dunstable, Dracut, Nashua, and southern New Hampshire.
                    </p>
                  </div>
                </StaggerItem>

                <StaggerItem direction="up" distance={16} className="flex items-start gap-3.5">
                  <div className="w-6 h-6 rounded-full bg-[#EAF2FA] text-[#174F86] flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-sm text-[#0B2440]">
                      Virtual Telehealth in Massachusetts & New Hampshire
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Our clinicians hold active licenses in both MA and NH, allowing us to legally and securely serve residents throughout both states via encrypted SimplePractice video.
                    </p>
                  </div>
                </StaggerItem>

                <StaggerItem direction="up" distance={16} className="flex items-start gap-3.5">
                  <div className="w-6 h-6 rounded-full bg-[#EAF2FA] text-[#174F86] flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-sm text-[#0B2440]">
                      Seamless Online Scheduling
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                      Direct integration with SimplePractice allows you to select your clinician, review appointment availability, and manage your paperwork without phone tag.
                    </p>
                  </div>
                </StaggerItem>
              </StaggerContainer>

              <FadeIn direction="up" distance={20} delay={0.35}>
                <div className="flex flex-wrap items-center gap-4">
                  <a
                    href={SITE_INFO.portalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] rounded-xl shadow-xs hover:shadow-md hover:-translate-y-0.5 transition-all"
                  >
                    <span>Book Appointment Now</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>

                  <button
                    type="button"
                    onClick={() => navigate("/contact")}
                    className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-[#174F86] bg-slate-100 hover:bg-[#EAF2FA] rounded-xl transition-all hover:-translate-y-0.5"
                  >
                    <span>View Map & Directions</span>
                  </button>
                </div>
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION G: FUTURE SERVICES ANNOUNCEMENT (Atmospheric sanctuary connecting smoothly to CTA) */}
      <section className="relative py-14 sm:py-20 bg-gradient-to-b from-white via-[#0B2440] to-[#0B2440] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScaleIn delay={0.1}>
            <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-slate-900/90 via-[#103761]/90 to-[#0B2440]/90 border border-white/10 shadow-2xl relative overflow-hidden backdrop-blur-md">
              {/* Radial ambient lighting */}
              <div className="absolute top-0 right-0 w-96 h-96 bg-[#F5BD00]/15 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#174F86]/25 rounded-full blur-3xl pointer-events-none" />

              <div className="max-w-3xl relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F5BD00]/20 text-[#F5BD00] text-xs font-semibold uppercase tracking-wider mb-4 border border-[#F5BD00]/30">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Planned Expansion · Early 2027</span>
                </div>

                <h2 className="font-heading font-extrabold text-2xl sm:text-3xl md:text-4xl text-white tracking-tight mb-3">
                  Expanding Our Support
                </h2>

                <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-8">
                  Transcending Chaos Counseling is actively developing structured group therapy cohorts to foster community healing and shared recovery. Beginning in early 2027, we plan to launch:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                  <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all hover:-translate-y-0.5">
                    <h4 className="font-heading font-bold text-sm text-[#F5BD00] mb-1.5">
                      Mental Health Group Therapy
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Collaborative peer support for depression, anxiety, and emotional resilience.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all hover:-translate-y-0.5">
                    <h4 className="font-heading font-bold text-sm text-[#F5BD00] mb-1.5">
                      Addiction Group Therapy
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Relapse prevention, accountability, and sustainable recovery frameworks.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all hover:-translate-y-0.5">
                    <h4 className="font-heading font-bold text-sm text-[#F5BD00] mb-1.5">
                      Gambling Group Therapy
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Specialized cognitive strategies for interrupting compulsive gambling patterns.
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-400 italic">
                  *Note: These group therapy programs are planned services anticipated for early 2027 and are not currently active. If you are interested in joining an inquiry list, please contact our administrative team.
                </p>
              </div>
            </div>
          </ScaleIn>
        </div>
      </section>

      {/* SECTION H: FINAL CTA */}
      <CTASection />
    </div>
  );
};
