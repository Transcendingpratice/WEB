import React from "react";

interface BrandLogoProps {
  variant?: "header" | "footer" | "emblem-only" | "light";
  className?: string;
  showSubtitle?: boolean;
}

export const BrandEmblem: React.FC<{ size?: number; className?: string }> = ({
  size = 42,
  className = "",
}) => {
  return (
    <img
      src="/assets/logo/logo-original-1.png"
      alt="Transcending Chaos Counseling Logo"
      width={size}
      height={size}
      style={{ width: size, height: size }}
      className={`shrink-0 object-contain select-none ${className}`}
      draggable={false}
    />
  );
};

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = "header",
  className = "",
  showSubtitle = false,
}) => {
  if (variant === "emblem-only") {
    return <BrandEmblem size={44} className={className} />;
  }

  const isLight = variant === "light" || variant === "footer";

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <BrandEmblem size={variant === "header" ? 38 : 44} />
      <div className="flex flex-col">
        <span
          className={`font-heading font-extrabold tracking-tight leading-none ${
            variant === "header" ? "text-base sm:text-lg" : "text-xl"
          } ${isLight ? "text-white" : "text-[#0B2440]"}`}
        >
          Transcending Chaos
        </span>
        <span
          className={`text-xs font-semibold tracking-wider uppercase mt-0.5 ${
            isLight ? "text-[#F5BD00]" : "text-[#174F86]"
          }`}
        >
          Counseling
        </span>
        {showSubtitle && (
          <span className="text-[11px] text-slate-400 mt-0.5 hidden sm:inline">
            Tyngsborough, MA · MA & NH Telehealth
          </span>
        )}
      </div>
    </div>
  );
};
