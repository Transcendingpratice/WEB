export interface Provider {
  id: string;
  slug: string;
  name: string;
  credentials: string;
  title: string;
  experience: string;
  image: string;
  shortBio: string;
  fullBio: string[];
  specialties: string[];
  modalities: string[];
  education: string[];
  licenses: string[];
  clientFocus: string[];
  acceptingNewClients: boolean;
}

export const PROVIDERS: Provider[] = [
  {
    id: "cassandra-leclerc",
    slug: "cassandra-leclerc",
    name: "Cassandra Leclerc",
    credentials: "MA, MBA, LMFT, LADC-1, MLADC",
    title: "Licensed Marriage and Family Therapist & Licensed Addiction Counselor",
    experience: "14+ years in Mental Health and Addiction Treatment",
    image: "/assets/providers/cassandra-leclerc.png",
    shortBio:
      "With 14+ years of clinical experience, Cassandra works with individuals and families navigating complex life stages, relationship challenges, and addiction recovery across Massachusetts and New Hampshire.",
    fullBio: [
      "With 14+ years of experience in the field of Mental Health and Addiction Treatment, I have worked with a variety of individuals and families to help problem-solve through their most difficult and complex times.",
      "Treatment specialties include Couple Therapy, Family Therapy, First Responders, Providers, Addiction, Veterans, and Family members affected by Addiction.",
      "I have experience working with the various developmental stages across the lifespan and on a whole systems level to help understand and manage the different dynamics that may arise.",
      "My treatment approach is to adapt to each client's needs, meet them where they are at, and support each person through the various life changes.",
      "Educationally, I hold a Masters in Marriage and Family Therapy along with a Master of Business Administration with a concentration in Healthcare Administration. I am currently a Licensed Marriage and Family Therapist (LMFT) and a Licensed Addiction Counselor (LADC-1 & MLADC) in both NH and Mass."
    ],
    specialties: [
      "Couples & Marriage Therapy",
      "Family Systems Therapy",
      "First Responders & Healthcare Providers",
      "Addiction & Substance Use Recovery",
      "Veterans & Military Adjustment",
      "Family Members Affected by Addiction",
      "Lifespan Developmental Transitions"
    ],
    modalities: [
      "Family Systems Therapy",
      "Relational & Couples Therapy",
      "Systems-Level Intervention",
      "Client-Centered Supportive Care",
      "Addiction Relapse Prevention",
      "Whole-Person Healthcare Management"
    ],
    education: [
      "Master of Arts in Marriage and Family Therapy (MA)",
      "Master of Business Administration (MBA) – Healthcare Administration Concentration"
    ],
    licenses: [
      "Licensed Marriage and Family Therapist (LMFT) – Massachusetts & New Hampshire",
      "Licensed Alcohol and Drug Counselor (LADC-1) – Massachusetts",
      "Master Licensed Alcohol and Drug Counselor (MLADC) – New Hampshire"
    ],
    clientFocus: [
      "Couples & Partners",
      "Families & Adult Children",
      "First Responders & Medical Personnel",
      "Veterans & Service Members",
      "Adults (18+)"
    ],
    acceptingNewClients: true
  },
  {
    id: "erica-michael",
    slug: "erica-michael",
    name: "Erica Michael",
    credentials: "MA, BCPC, CFC",
    title: "Pre-Licensed Board Certified Professional Counselor & Forensic Counselor",
    experience: "15+ years in Mental Health and Addiction Treatment",
    image: "/assets/providers/erica-michael.png",
    shortBio:
      "With 15+ years of clinical experience, Erica is dedicated to helping individuals navigate life challenges, find clarity, and build fulfilling lives through evidence-based cognitive and trauma-focused modalities.",
    fullBio: [
      "With 15+ years of experience in the field of Mental Health and Addiction Treatment. She is dedicated to helping individuals navigate and explore life's challenges and find clarity and peace while remaining client-centered during every meeting.",
      "Specializations include Individuals (ages 16-99), Addiction, First Responders, Veterans, and Justice-Involved persons affected by Addiction and/or Mental Health.",
      "Erica's approach is to blend techniques from Cognitive Behavioral Therapy (CBT), Dialectical Behavioral Therapy (DBT), Acceptance and Commitment Therapy (ACT), Psychodynamic Therapy, Trauma-Focused Therapy, and mindfulness practices.",
      "She believes in the power of connection by creating a safe non-judgmental space where clients can build a more fulfilling life.",
      "Educationally, Erica holds a Bachelor's in Psychology and a Bachelor's in Sociology (Prelaw/criminology focused), and a Master's in Forensic Psychology. She is a Pre-Licensed Board Certified Professional Counselor and Certified Forensic Counselor through the American Psychotherapy Association."
    ],
    specialties: [
      "Individual Therapy (Ages 16–99)",
      "Addiction & Substance Use",
      "First Responders Support",
      "Veterans & Reintegration",
      "Justice-Involved Individuals",
      "Forensic & Mental Health Evaluations",
      "Trauma & Post-Traumatic Growth"
    ],
    modalities: [
      "Cognitive Behavioral Therapy (CBT)",
      "Dialectical Behavioral Therapy (DBT)",
      "Acceptance and Commitment Therapy (ACT)",
      "Trauma-Focused Therapy",
      "Psychodynamic Therapy",
      "Mindfulness Practices & Grounding"
    ],
    education: [
      "Master of Arts in Forensic Psychology (MA)",
      "Bachelor of Arts in Psychology",
      "Bachelor of Arts in Sociology (Prelaw / Criminology Focus)"
    ],
    licenses: [
      "Board Certified Professional Counselor (BCPC) – American Psychotherapy Association (Pre-Licensed)",
      "Certified Forensic Counselor (CFC) – American Psychotherapy Association"
    ],
    clientFocus: [
      "Individuals Ages 16 to 99",
      "Justice-Involved Persons",
      "First Responders",
      "Veterans & Military Personnel",
      "Individuals Seeking Addiction Recovery"
    ],
    acceptingNewClients: true
  },
  {
    id: "deb-smith",
    slug: "deb-smith",
    name: "Deb Smith",
    credentials: "MA, LADC-2",
    title: "Licensed Alcohol and Drug Counselor & Mental Health Clinician",
    experience: "Nearly 5 years of outpatient clinical experience",
    image: "/assets/providers/deb-smith.png",
    shortBio:
      "A dynamic clinician with extensive outpatient experience specializing in dual diagnosis, addiction, crisis intervention, and mood disorders, creating a warm, non-judgmental space for clients to transcend life's chaos.",
    fullBio: [
      "I'm a dynamic clinician with nearly five years of outpatient experience specializing in addiction and mental health treatment, including dual diagnosis, crisis intervention, and both group and individual counseling.",
      "I've worked with a wide range of diagnoses, including depression, anxiety, OCD, ODD, bipolar disorder, schizophrenia, addiction, substance use, PTSD, trauma, and personality disorders.",
      "As a Licensed Alcohol and Drug Counselor (LADC-2), I bring extensive expertise in treatment planning, case management, and clinical documentation.",
      "I'm skilled at collaborating with multidisciplinary healthcare teams to deliver client-centered care, even in fast-paced clinical settings.",
      "I create a warm, non-judgmental space where clients feel safe to be honest, and I meet clients where they are at.",
      "My goal is to support each person on their path to transcend the chaos we call life."
    ],
    specialties: [
      "Dual Diagnosis & Complex Co-occurring Needs",
      "Addiction & Substance Use Counseling",
      "Crisis Intervention & De-escalation",
      "Mood & Anxiety Disorders (OCD, Bipolar, Schizophrenia)",
      "Trauma & PTSD Recovery",
      "Personality Disorders & ODD",
      "Collaborative Treatment Planning & Case Management"
    ],
    modalities: [
      "Client-Centered Therapy",
      "Crisis Intervention & Safety Planning",
      "Dual-Diagnosis Treatment Planning",
      "Cognitive Restructuring",
      "Supportive Individual Counseling",
      "Multidisciplinary Team Collaboration"
    ],
    education: [
      "Master of Arts in Counseling / Behavioral Health (MA)"
    ],
    licenses: [
      "Licensed Alcohol and Drug Counselor (LADC-2) – Massachusetts"
    ],
    clientFocus: [
      "Adults & Young Adults",
      "Dual Diagnosis Clients",
      "Individuals Experiencing Crisis or Life Disruption",
      "Persons in Substance Recovery"
    ],
    acceptingNewClients: true
  }
];
