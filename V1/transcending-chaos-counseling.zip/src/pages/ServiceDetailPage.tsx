import React from "react";
import { SERVICES } from "../data/services";
import { PROVIDERS } from "../data/providers";
import { useRouter } from "../context/RouterContext";
import { SITE_INFO } from "../data/siteInfo";
import { ProviderCard } from "../components/ProviderCard";
import { CTASection } from "../components/CTASection";
import { getServiceIcon } from "../components/ServiceCard";
import {
  ArrowLeft,
  Calendar,
  ArrowUpRight,
  CheckCircle2,
  MapPin,
  Laptop,
  Clock,
  Sparkles,
  HelpCircle,
  ShieldCheck,
  Phone,
  Mail,
  FileText,
  ArrowRight,
  Shield,
} from "lucide-react";
import {
  FadeIn,
  TextReveal,
  StaggerContainer,
  StaggerItem,
  ScaleIn,
} from "../components/motion/MotionSystem";

export const ServiceDetailPage: React.FC<{ slug: string }> = ({ slug }) => {
  const { navigate } = useRouter();
  const service = SERVICES.find(
    (s) =>
      s.slug === slug ||
      s.id === slug ||
      (slug === "addiction" && (s.slug === "addiction" || s.id === "addiction-treatment")) ||
      (slug === "addiction-treatment" && s.slug === "addiction") ||
      (slug === "mental-health" && (s.slug === "mental-health" || s.id === "mental-health-counseling")) ||
      (slug === "mental-health-counseling" && s.slug === "mental-health")
  );

  if (!service) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <h1 className="font-heading font-bold text-2xl text-slate-800 mb-4">
          Service Not Found
        </h1>
        <p className="text-slate-600 mb-8">
          The requested service description could not be found.
        </p>
        <button
          onClick={() => navigate("/services")}
          className="px-6 py-3 bg-[#174F86] text-white rounded-xl text-sm font-semibold hover:bg-[#0B2440] transition-colors"
        >
          View Our Services
        </button>
      </div>
    );
  }

  // Find matching providers specializing in this service
  const matchingProviders = PROVIDERS.filter((p) => {
    const sSlug = service.slug.toLowerCase();
    if (sSlug === "couples-therapy") {
      return p.specialties.some((spec) => spec.toLowerCase().includes("couple"));
    }
    if (sSlug === "addiction" || sSlug === "addiction-treatment") {
      return p.specialties.some((spec) => spec.toLowerCase().includes("addiction"));
    }
    if (sSlug === "first-responders") {
      return p.specialties.some((spec) => spec.toLowerCase().includes("first responder"));
    }
    if (sSlug === "veterans") {
      return p.specialties.some((spec) => spec.toLowerCase().includes("veteran"));
    }
    if (sSlug === "court-probation-evaluations") {
      return p.specialties.some(
        (spec) => spec.toLowerCase().includes("evaluation") || spec.toLowerCase().includes("justice")
      );
    }
    return true;
  });

  return (
    <div className="flex flex-col w-full bg-white">
      {/* Service Hero with Unified Full Color Gradient Overlay (Inspired by Trust Therapeutics) */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#07172B] via-[#0B2440] to-[#103761] text-white pt-8 pb-16 sm:pt-10 sm:pb-24">
        {service.bgImage && (
          <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
            {/* The photographic texture with clear visibility */}
            <img
              src={service.bgImage}
              alt=""
              aria-hidden="true"
              className="w-full h-full object-cover object-center opacity-70 filter brightness-95 contrast-105"
              referrerPolicy="no-referrer"
            />
            {/* Translucent color gradient overlay - clear background image with rich brand color wash */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#071626]/85 via-[#0B2440]/70 to-[#103761]/55" />
            {/* Subtle atmospheric radial lights */}
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#F5BD00]/15 rounded-full blur-3xl" />
            <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#174F86]/25 rounded-full blur-3xl" />
          </div>
        )}

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb Navigation inside Hero */}
          <FadeIn direction="down" distance={10} delay={0.02} className="mb-6">
            <button
              onClick={() => navigate("/services")}
              className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white transition-colors group cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-[#F5BD00] group-hover:-translate-x-1 transition-transform" />
              <span>Services</span>
              <span className="text-slate-500">/</span>
              <span className="text-[#F5BD00] font-medium">{service.title}</span>
            </button>
          </FadeIn>

          <div className="max-w-3xl">
            <FadeIn direction="down" distance={16} delay={0.05}>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-[#F5BD00] shadow-sm">
                  {getServiceIcon(service.slug)}
                </div>
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-[#F5BD00] block">
                    Clinical Care Offering
                  </span>
                  {service.isComingSoon ? (
                    <span className="inline-flex items-center gap-1 text-[11px] text-amber-200 font-semibold bg-amber-900/60 px-2 py-0.5 rounded-full mt-0.5 border border-amber-500/30">
                      <Clock className="w-3 h-3 text-[#F5BD00]" />
                      <span>Planned for {service.expectedDate}</span>
                    </span>
                  ) : (
                    <span className="text-xs text-slate-300">
                      Active Clinical Care · Accepting New Clients
                    </span>
                  )}
                </div>
              </div>
            </FadeIn>

            <TextReveal
              tag="h1"
              text={service.title}
              className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-tight mb-4 leading-tight"
            />

            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base sm:text-lg text-slate-200 leading-relaxed mb-6 font-medium max-w-2xl">
                {service.shortDescription}
              </p>
            </FadeIn>

            {service.quote && (
              <FadeIn direction="up" distance={16} delay={0.25}>
                <div className="p-4.5 rounded-xl bg-white/5 backdrop-blur-md border border-white/15 text-xs sm:text-sm text-slate-200 italic mb-6 max-w-2xl">
                  "{service.quote}"
                </div>
              </FadeIn>
            )}

            <FadeIn direction="up" distance={16} delay={0.35}>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 pt-4 border-t border-white/15">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#F5BD00]" />
                  <span>In-Person: Tyngsborough, MA</span>
                </div>
                <span className="text-slate-500">·</span>
                <div className="flex items-center gap-1.5">
                  <Laptop className="w-4 h-4 text-[#F5BD00]" />
                  <span>Telehealth: MA & NH</span>
                </div>
                <span className="text-slate-500">·</span>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#F5BD00]" />
                  <span>SimplePractice Encrypted</span>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* In-Depth Overview & Clinical Details (Seamless soft blend) */}
      <section className="relative py-14 sm:py-18 bg-gradient-to-b from-[#F6F8FC] via-white to-[#F0F5FA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Left Column: Full Description, Who It's For, Modalities & FAQs */}
            <div className="lg:col-span-8 flex flex-col gap-8">
              {/* Clinical Overview Card */}
              <FadeIn direction="up" distance={20}>
                <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                  <h2 className="font-heading font-bold text-xl text-[#0B2440] mb-4">
                    Clinical Overview
                  </h2>
                  <p className="text-base text-slate-700 leading-relaxed mb-6">
                    {service.fullDescription}
                  </p>

                  <div className="p-4.5 rounded-xl bg-[#EAF2FA]/80 border border-[#174F86]/15">
                    <span className="text-xs font-bold text-[#174F86] uppercase tracking-wider block mb-1.5">
                      Target Audience:
                    </span>
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                      {service.targetAudience}
                    </p>
                  </div>
                </div>
              </FadeIn>

              {/* Specific Areas & Conditions Covered */}
              {service.subservices && (
                <FadeIn direction="up" distance={20} delay={0.1}>
                  <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                    <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-4">
                      Specific Areas & Conditions Covered
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {service.subservices.map((sub, idx) => (
                        <div key={idx} className="flex items-start gap-2.5 p-3.5 rounded-xl bg-[#F6F8FC] hover:bg-[#EEF4FB] transition-colors">
                          <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0 mt-0.5" />
                          <span className="text-xs sm:text-sm font-medium text-slate-800 leading-snug">{sub}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </FadeIn>
              )}

              {/* Who It Is For Details */}
              {service.details?.whoItIsFor && (
                <FadeIn direction="up" distance={20} delay={0.15}>
                  <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                    <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-4">
                      Who This Service Is Designed For
                    </h3>
                    <div className="space-y-3">
                      {service.details.whoItIsFor.map((item, idx) => (
                        <div key={idx} className="flex items-start gap-3 p-3.5 rounded-xl bg-[#F6F8FC] hover:bg-[#EEF4FB] transition-colors">
                          <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0 mt-0.5" />
                          <span className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                            {item}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </FadeIn>
              )}

              {/* Common Concerns / Clinical Focus Patterns */}
              {service.details?.commonConcerns && (
                <FadeIn direction="up" distance={20} delay={0.2}>
                  <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                    <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-5">
                      Common Experiences & What We Address
                    </h3>
                    <div className="space-y-4">
                      {service.details.commonConcerns.map((concern, idx) => (
                        <div key={idx} className="p-4.5 rounded-xl bg-[#F6F8FC]/80 hover:bg-[#EEF4FB] transition-colors">
                          <h4 className="font-heading font-bold text-sm text-[#0B2440] mb-1.5">
                            {concern.title}
                          </h4>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            {concern.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </FadeIn>
              )}

              {/* Key Topics Addressed */}
              <FadeIn direction="up" distance={20} delay={0.25}>
                <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                  <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-4">
                    Key Focus Areas
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {service.keyTopics.map((topic) => (
                      <div key={topic} className="flex items-start gap-2.5 p-3 rounded-xl bg-[#F6F8FC]">
                        <span className="w-2 h-2 rounded-full bg-[#174F86] shrink-0 mt-1.5" />
                        <span className="text-xs text-slate-700 font-medium leading-relaxed">
                          {topic}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </FadeIn>

              {/* What To Expect in Session */}
              {service.details?.whatToExpect && (
                <FadeIn direction="up" distance={20} delay={0.3}>
                  <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                    <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-4">
                      What to Expect During Sessions
                    </h3>
                    <div className="space-y-3">
                      {service.details.whatToExpect.map((step, idx) => (
                        <div key={idx} className="flex items-start gap-3 p-3.5 rounded-xl bg-[#F6F8FC]">
                          <span className="font-mono text-xs font-bold text-[#174F86] shrink-0 mt-0.5">
                            0{idx + 1}.
                          </span>
                          <span className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                            {step}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </FadeIn>
              )}

              {/* Evidence-Based Approaches */}
              <FadeIn direction="up" distance={20} delay={0.35}>
                <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                  <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-4">
                    Evidence-Based Clinical Modalities
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {service.evidenceBasedApproaches.map((app) => (
                      <div key={app} className="flex items-center gap-2.5 p-3 rounded-xl bg-[#F6F8FC]">
                        <Sparkles className="w-4 h-4 text-[#F5BD00] shrink-0" />
                        <span className="text-xs text-slate-700 font-semibold">{app}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </FadeIn>

              {/* Clinical FAQs */}
              {service.details?.clinicalQuestions && (
                <FadeIn direction="up" distance={20} delay={0.4}>
                  <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs">
                    <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-4">
                      Frequently Asked Questions
                    </h3>
                    <div className="space-y-4">
                      {service.details.clinicalQuestions.map((q, idx) => (
                        <div key={idx} className="p-4 rounded-xl bg-[#F6F8FC]">
                          <div className="font-heading font-bold text-xs sm:text-sm text-[#0B2440] mb-1.5 flex items-start gap-2">
                            <HelpCircle className="w-4 h-4 text-[#174F86] shrink-0 mt-0.5" />
                            <span>{q.q}</span>
                          </div>
                          <p className="text-xs text-slate-600 leading-relaxed pl-6">
                            {q.a}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </FadeIn>
              )}
            </div>

            {/* Right Column: Appointment Booking & Clinical Companion Cards */}
            <div className="lg:col-span-4 flex flex-col gap-6">
              {/* Primary Booking Card */}
              <FadeIn direction="left" distance={20} delay={0.15}>
                <div className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-slate-100/90 shadow-md shadow-blue-950/5">
                  <h3 className="font-heading font-bold text-base text-[#0B2440] mb-2">
                    Schedule {service.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-5">
                    Select your appointment format and choose your clinician using our encrypted SimplePractice portal.
                  </p>

                  {service.isComingSoon ? (
                    <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 mb-4">
                      <p className="font-semibold mb-1">Advance Inquiry Waitlist</p>
                      <p className="text-amber-800">
                        Group cohorts are scheduled to launch in early 2027. Contact our administrative office to be placed on the confidential cohort interest list.
                      </p>
                    </div>
                  ) : (
                    <a
                      href={SITE_INFO.portalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl shadow-xs hover:shadow-md hover:-translate-y-0.5 text-center mb-3 cursor-pointer"
                    >
                      <Calendar className="w-4 h-4 text-[#0B2440]" />
                      <span>Book Appointment Now</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => navigate("/contact")}
                    className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold text-[#174F86] bg-slate-100 hover:bg-[#EAF2FA] transition-all rounded-xl text-center hover:-translate-y-0.5 cursor-pointer"
                  >
                    <span>Ask a Clinical Question</span>
                  </button>

                  <div className="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500 space-y-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <span className="shrink-0 text-slate-400">Format:</span>
                      <span className="font-medium text-slate-800 text-right">{service.format}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Intake System:</span>
                      <span className="font-medium text-slate-800">SimplePractice (HIPAA)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Direct Inquiries:</span>
                      <a href={`tel:${SITE_INFO.phoneRaw}`} className="font-bold text-[#174F86] hover:underline">
                        {SITE_INFO.phone}
                      </a>
                    </div>
                  </div>
                </div>
              </FadeIn>

              {/* Office & Telehealth Sanctuary Card */}
              <FadeIn direction="left" distance={20} delay={0.25}>
                <div className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-slate-100/90 shadow-xs">
                  <h4 className="font-heading font-bold text-sm text-[#0B2440] mb-3 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#174F86]" />
                    <span>Practice Location & Telehealth</span>
                  </h4>
                  <div className="space-y-3 text-xs text-slate-600">
                    <div className="p-3 rounded-xl bg-[#F6F8FC] border border-slate-100">
                      <span className="font-bold text-[#0B2440] block mb-0.5">Tyngsborough Office:</span>
                      <span>1 Bridgeview Circle, Suite 5</span>
                      <span className="text-slate-400 block mt-0.5">Tyngsborough, MA 01879-2053</span>
                      <span className="text-[11px] text-[#174F86] font-medium block mt-1">Free parking · Accessible via Route 3</span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#F6F8FC] border border-slate-100">
                      <span className="font-bold text-[#0B2440] block mb-0.5">Virtual Care Coverage:</span>
                      <span>Active clinical licensure throughout Massachusetts & New Hampshire.</span>
                    </div>
                  </div>
                </div>
              </FadeIn>

              {/* Insurance & Transparent Billing Card */}
              <FadeIn direction="left" distance={20} delay={0.3}>
                <div className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-slate-100/90 shadow-xs">
                  <h4 className="font-heading font-bold text-sm text-[#0B2440] mb-2 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[#174F86]" />
                    <span>Transparent Billing & Self-Pay</span>
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed mb-3">
                    We offer self-pay therapy with superbill receipts provided for out-of-network insurance reimbursement where eligible.
                  </p>
                  <button
                    type="button"
                    onClick={() => navigate("/good-faith-estimate")}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#174F86] hover:underline cursor-pointer"
                  >
                    <span>Read No Surprises Act & GFE Notice</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </FadeIn>

              {/* Direct Practice Contact Card */}
              <FadeIn direction="left" distance={20} delay={0.35}>
                <div className="bg-gradient-to-br from-[#0B2440] to-[#103761] text-white p-6 rounded-2xl shadow-md">
                  <h4 className="font-heading font-bold text-sm text-white mb-2">
                    Need Help Getting Started?
                  </h4>
                  <p className="text-xs text-slate-200 leading-relaxed mb-4">
                    Our administrative team is here to answer clinical questions or guide you through the intake process.
                  </p>
                  <div className="space-y-2.5 text-xs">
                    <a
                      href={`tel:${SITE_INFO.phoneRaw}`}
                      className="flex items-center gap-2.5 text-slate-200 hover:text-white transition-colors"
                    >
                      <Phone className="w-4 h-4 text-[#F5BD00]" />
                      <span>{SITE_INFO.phone}</span>
                    </a>
                    <a
                      href={`mailto:${SITE_INFO.email}`}
                      className="flex items-center gap-2.5 text-slate-200 hover:text-white transition-colors"
                    >
                      <Mail className="w-4 h-4 text-[#F5BD00]" />
                      <span className="truncate">{SITE_INFO.email}</span>
                    </a>
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* Specializing Clinicians Section (Seamless soft blend) */}
      {matchingProviders.length > 0 && (
        <section className="relative py-14 sm:py-20 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-10 text-center max-w-2xl mx-auto">
              <FadeIn direction="down" distance={16}>
                <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-1 block">
                  SPECIALIZING CLINICIANS
                </span>
              </FadeIn>
              <TextReveal
                tag="h2"
                text={`Providers Offering ${service.title}`}
                className="font-heading font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#0B2440] tracking-tight"
              />
            </div>

            {/* Streamlined Horizontal Clinician Cards (Small pic + short designed description + View Profile button) */}
            <div className="max-w-4xl mx-auto flex flex-col gap-4">
              {matchingProviders.map((provider) => (
                <FadeIn key={provider.id} direction="up" distance={16}>
                  <ProviderCard provider={provider} variant="horizontal" />
                </FadeIn>
              ))}
            </div>
          </div>
        </section>
      )}

      <CTASection />
    </div>
  );
};
