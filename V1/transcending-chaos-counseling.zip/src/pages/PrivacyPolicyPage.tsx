import React from "react";
import { SITE_INFO } from "../data/siteInfo";
import { useRouter } from "../context/RouterContext";
import { Shield, ArrowLeft } from "lucide-react";
import { FadeIn, TextReveal } from "../components/motion/MotionSystem";

export const PrivacyPolicyPage: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="flex flex-col w-full bg-white">
      {/* Header with seamless gradient */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#F6F8FC] via-white to-[#F0F5FA] py-12 sm:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn direction="left" distance={16}>
            <button
              onClick={() => navigate("/")}
              className="inline-flex items-center gap-2 text-xs font-semibold text-[#174F86] hover:text-[#0B2440] transition-colors mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return to Home</span>
            </button>
          </FadeIn>

          <FadeIn direction="down" distance={16} delay={0.1}>
            <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2 block">
              CONFIDENTIALITY & LEGAL POLICIES
            </span>
          </FadeIn>

          <TextReveal
            tag="h1"
            text="Notice of Privacy Practices & Privacy Policy"
            className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight mb-4"
          />

          <FadeIn direction="up" distance={16} delay={0.2}>
            <p className="text-sm text-slate-600 leading-relaxed">
              Effective Date: November 2026 · Practice: Transcending Chaos Counseling, LLC
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Policy Content */}
      <section className="py-12 sm:py-16 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn direction="up" distance={20} delay={0.1}>
            <div className="prose prose-slate max-w-none space-y-10 text-slate-700 text-sm leading-relaxed">
              {/* Overview */}
              <div className="p-6 sm:p-8 rounded-2xl bg-white/95 backdrop-blur-xs border border-slate-100/90 shadow-md shadow-blue-950/5">
                <h2 className="font-heading font-bold text-lg text-[#0B2440] mb-3 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#174F86]" />
                  <span>Our Commitment to Your Privacy</span>
                </h2>
                <p>
                  Transcending Chaos Counseling is committed to protecting the privacy and confidentiality of your Protected Health Information (PHI) in compliance with the Health Insurance Portability and Accountability Act of 1996 (HIPAA), Massachusetts state health privacy regulations, and New Hampshire mental health licensure requirements.
                </p>
              </div>

            {/* Section 1 */}
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                1. How We Use and Disclose Protected Health Information (PHI)
              </h3>
              <p className="mb-3">
                We may use and disclose your health records for the purposes of:
              </p>
              <ul className="list-disc pl-5 space-y-2">
                <li>
                  <strong>Treatment:</strong> Providing, coordinating, or managing mental health and addiction counseling among licensed clinicians within our practice, or with your designated healthcare providers upon your signed release.
                </li>
                <li>
                  <strong>Payment:</strong> Processing claims with insurers, billing entities, or client-authorized credit card services via our secure electronic health record (SimplePractice).
                </li>
                <li>
                  <strong>Healthcare Operations:</strong> Quality assurance, internal auditing, licensing compliance, and practice administration necessary to ensure high clinical standards.
                </li>
              </ul>
            </div>

            {/* Section 2 */}
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                2. Mandatory Disclosures & Exceptions to Confidentiality
              </h3>
              <p className="mb-3">
                Under federal and state law (Massachusetts and New Hampshire), mental health professionals are legally mandated to disclose limited confidential information without prior consent in specific circumstances:
              </p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Suspected abuse, neglect, or exploitation of a child, elder, or disabled person.</li>
                <li>Imminent and serious threat of physical harm or death to oneself or another identifiable person.</li>
                <li>Valid court orders, subpoenas issued by a judge, or mandatory statutory regulatory audits.</li>
                <li>Defense against legal or ethical complaints initiated by the client.</li>
              </ul>
            </div>

            {/* Section 3 */}
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                3. Your Rights Regarding Your Health Records
              </h3>
              <ul className="list-disc pl-5 space-y-2">
                <li>
                  <strong>Right to Inspect and Copy:</strong> You have the right to inspect and obtain a copy of your mental health records, subject to professional clinical discretion and standard copying fees where permitted by law.
                </li>
                <li>
                  <strong>Right to Request Confidential Communications:</strong> You may request that we communicate with you via specific phone numbers, encrypted email, or your SimplePractice client portal.
                </li>
                <li>
                  <strong>Right to Revoke Authorization:</strong> Any written authorization for record release may be revoked in writing at any time, except to the extent that action has already been taken.
                </li>
              </ul>
            </div>

            {/* Section 4 */}
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                4. Website & Electronic Communications Privacy
              </h3>
              <p>
                This website provides general practice information and directions to our secure client portal. We do not store sensitive medical history or process financial transactions on this public marketing website. All client appointment requests, credit cards, and clinical notes are managed through SimplePractice, an independent, HIPAA-compliant electronic medical record provider adhering to SOC2 and HITRUST standards.
              </p>
            </div>

            {/* Section 5 */}
            <div className="pt-6 border-t border-slate-200">
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                5. Privacy Officer & Questions
              </h3>
              <p className="mb-2">
                If you have questions about our privacy practices, wish to file a privacy concern, or request an official paper copy of this notice, please contact:
              </p>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <p className="font-bold text-slate-800">Transcending Chaos Counseling, LLC</p>
                <p>Attention: Privacy Administrator</p>
                <p>Mailing Address: 265 Chelmsford St., Suite 7, Chelmsford, MA 01824-2665</p>
                <p>Telephone: {SITE_INFO.phone}</p>
                <p>Email: {SITE_INFO.email}</p>
              </div>
            </div>
          </div>
          </FadeIn>
        </div>
      </section>
    </div>
  );
};
