import React from "react";
import { motion } from "motion/react";
import { ServiceItem } from "../data/services";
import { useRouter } from "../context/RouterContext";
import {
  Heart,
  Users,
  ShieldAlert,
  Brain,
  Shield,
  Award,
  Scale,
  Sparkles,
  ArrowRight,
  Clock,
  Laptop,
  MapPin,
} from "lucide-react";

interface ServiceCardProps {
  service: ServiceItem;
}

export const getServiceIcon = (slug: string) => {
  switch (slug) {
    case "telehealth-therapy":
      return <Laptop className="w-6 h-6 text-[#174F86]" />;
    case "in-person-therapy":
      return <MapPin className="w-6 h-6 text-[#174F86]" />;
    case "individual-therapy":
      return <UserCircleIcon className="w-6 h-6 text-[#174F86]" />;
    case "couples-therapy":
      return <Heart className="w-6 h-6 text-[#174F86]" />;
    case "addiction":
    case "addiction-treatment":
      return <ShieldAlert className="w-6 h-6 text-[#174F86]" />;
    case "mental-health":
    case "mental-health-counseling":
      return <Brain className="w-6 h-6 text-[#174F86]" />;
    case "first-responders":
      return <Shield className="w-6 h-6 text-[#174F86]" />;
    case "veterans":
      return <Award className="w-6 h-6 text-[#174F86]" />;
    case "court-probation-evaluations":
      return <Scale className="w-6 h-6 text-[#174F86]" />;
    case "group-therapy":
      return <Users className="w-6 h-6 text-[#174F86]" />;
    default:
      return <Sparkles className="w-6 h-6 text-[#174F86]" />;
  }
};

const UserCircleIcon = ({ className }: { className?: string }) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="10" r="3" />
    <path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662" />
  </svg>
);

export const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  const { navigate } = useRouter();

  return (
    <motion.div
      onClick={() => navigate(`/services/${service.slug}`)}
      whileHover={{ y: -4, transition: { duration: 0.25, ease: [0.16, 1, 0.3, 1] } }}
      className={`group relative rounded-2xl p-5 sm:p-7 transition-all duration-300 flex flex-col justify-between cursor-pointer w-full max-w-full overflow-hidden ${
        service.isComingSoon
          ? "bg-gradient-to-b from-amber-50/50 to-white/90 border border-amber-200/50 shadow-xs hover:shadow-md hover:shadow-amber-900/5"
          : "bg-gradient-to-b from-white via-white to-[#F8FAFD] border border-slate-100/80 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:border-[#174F86]/20"
      }`}
    >
      <div className="min-w-0">
        {/* Header icon and format badge */}
        <div className="flex items-center justify-between gap-3 mb-5">
          <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-[#EAF2FA] flex items-center justify-center shrink-0 group-hover:bg-[#174F86] group-hover:text-white transition-all duration-300 shadow-xs group-hover:shadow-md">
            {getServiceIcon(service.slug)}
          </div>

          {service.isComingSoon ? (
            <span className="text-[10px] sm:text-[11px] font-semibold text-amber-800 bg-amber-100/70 px-2.5 py-1 rounded-full flex items-center gap-1.5 border border-amber-200/60 shrink-0">
              <Clock className="w-3 h-3" />
              <span>Coming {service.expectedDate}</span>
            </span>
          ) : (
            <span className="text-[10px] sm:text-[11px] font-medium text-slate-500 bg-slate-100/70 px-2.5 py-1 rounded-full shrink-0">
              In-Person & Telehealth
            </span>
          )}
        </div>

        {/* Title */}
        <h3 className="font-heading font-bold text-lg sm:text-xl text-[#0B2440] group-hover:text-[#174F86] transition-colors mb-2.5 leading-snug break-words">
          {service.title}
        </h3>

        {/* Short description */}
        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5 break-words">
          {service.shortDescription}
        </p>

        {/* Key focus topics - clean unboxed text with bullets */}
        <ul className="space-y-1.5 text-xs text-slate-600 mb-6">
          {service.keyTopics.slice(0, 3).map((topic) => (
            <li key={topic} className="flex items-start gap-2 min-w-0">
              <span className="w-1.5 h-1.5 rounded-full bg-[#174F86] shrink-0 mt-1.5 opacity-70 group-hover:opacity-100 transition-opacity" />
              <span className="line-clamp-1 break-words">{topic}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Card Footer action */}
      <div className="pt-4 border-t border-slate-100/80 flex items-center justify-between text-xs font-semibold text-[#174F86] group-hover:text-[#0B2440] transition-colors">
        <span>{service.isComingSoon ? "View Program Details" : "Learn More & Modalities"}</span>
        <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform duration-200" />
      </div>
    </motion.div>
  );
};
