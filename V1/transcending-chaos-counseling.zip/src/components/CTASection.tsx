import React from "react";
import { useRouter } from "../context/RouterContext";
import { SITE_INFO } from "../data/siteInfo";
import { ArrowUpRight, MessageSquare, Phone, CalendarCheck } from "lucide-react";
import { FadeIn, TextReveal } from "./motion/MotionSystem";

export const CTASection: React.FC<{
  title?: string;
  description?: string;
  showPhone?: boolean;
}> = ({
  title = "Your Journey Toward Clarity Starts Here.",
  description = "Take the first step toward a more balanced and fulfilling life. We are here to guide you through life's complexity with evidence-based clinical excellence.",
  showPhone = true,
}) => {
  const { navigate } = useRouter();

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[#0B2440] via-[#103761] to-[#174F86] text-white py-14 sm:py-20 px-4 sm:px-6 lg:px-8">
      {/* Soft atmospheric ambient glow */}
      <div className="absolute inset-0 opacity-10 pointer-events-none pattern-dots" />
      <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-[#F5BD00]/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-white/10 blur-3xl pointer-events-none" />

      <div className="relative max-w-4xl mx-auto text-center flex flex-col items-center">
        {/* Editorial kicker */}
        <FadeIn direction="down" distance={16} delay={0.05}>
          <span className="text-xs font-bold uppercase tracking-widest text-[#F5BD00] mb-3 inline-block">
            TRANSCENDING CHAOS COUNSELING
          </span>
        </FadeIn>

        {/* Headline with staggered blur-to-clear reveal */}
        <TextReveal
          tag="h2"
          text={title}
          className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-tight leading-tight mb-5 max-w-2xl mx-auto"
        />

        {/* Supporting description */}
        <FadeIn direction="up" distance={20} delay={0.2}>
          <p className="text-base sm:text-lg text-slate-200 leading-relaxed max-w-2xl mb-8">
            {description}
          </p>
        </FadeIn>

        {/* Call to action buttons */}
        <FadeIn direction="up" distance={20} delay={0.3} className="w-full sm:w-auto">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 w-full sm:w-auto max-w-full">
            <a
              href={SITE_INFO.portalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 sm:px-8 py-3.5 sm:py-4 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white text-center"
            >
              <CalendarCheck className="w-4 h-4 text-[#0B2440] shrink-0" />
              <span>Schedule an Appointment</span>
              <ArrowUpRight className="w-4 h-4 shrink-0" />
            </a>

            <button
              type="button"
              onClick={() => navigate("/contact")}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 sm:px-8 py-3.5 sm:py-4 text-xs sm:text-sm font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/20 active:scale-98 transition-all rounded-xl backdrop-blur-xs hover:-translate-y-0.5 text-center"
            >
              <MessageSquare className="w-4 h-4 shrink-0" />
              <span>Contact Our Team</span>
            </button>
          </div>
        </FadeIn>

        {/* Additional trust cues */}
        {showPhone && (
          <FadeIn direction="up" distance={16} delay={0.4}>
            <div className="mt-8 pt-6 border-t border-white/15 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-300">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#F5BD00]" />
                <span>In-Person in Tyngsborough, MA</span>
              </span>
              <span aria-hidden="true" className="opacity-40">·</span>
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#F5BD00]" />
                <span>Virtual Sessions in MA & NH</span>
              </span>
              <span aria-hidden="true" className="opacity-40">·</span>
              <a
                href={`tel:${SITE_INFO.phoneRaw}`}
                className="hover:text-white font-medium flex items-center gap-1.5 transition-colors underline"
              >
                <Phone className="w-3.5 h-3.5 text-[#F5BD00]" />
                <span>Call: {SITE_INFO.phone}</span>
              </a>
            </div>
          </FadeIn>
        )}
      </div>
    </section>
  );
};
