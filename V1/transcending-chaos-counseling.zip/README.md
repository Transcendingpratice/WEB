# Transcending Chaos Counseling — Premium Production Website

A redesigned, high-end, responsive web application for **Transcending Chaos Counseling**, an established mental health counseling, couples therapy, addiction treatment, and behavioral health practice based in Tyngsborough, Massachusetts, offering in-person care and virtual telehealth across Massachusetts and New Hampshire.

Official Website: [https://www.transcendingchaos.org/](https://www.transcendingchaos.org/)  
Client Portal: [https://transcendingchaos.clientsecure.me/](https://transcendingchaos.clientsecure.me/)

---

## Brand Architecture & Color Palette

- **Royal Blue (`#174F86`)**: Primary brand color, headers, trust indicators.
- **Deep Navy (`#0B2440`)**: Structural anchors, headings, high-contrast footer.
- **Golden Yellow (`#F5BD00`)**: Primary conversion CTAs, highlights, emblem heart.
- **Soft White (`#F6F8FC`)**: Alternating section backgrounds.
- **Pure White (`#FFFFFF`)**: Dominant canvas background.
- **Slate Gray (`#64748B`)**: Body text.
- **Light Blue (`#EAF2FA`)**: Subtle accents and icon backdrops.

### Brand Symbol
Preserves the verified original emblem featuring the 8 radiating directional arrows (Transcending Chaos Compass), centered Golden Heart, and the Eye of Clarity & Self-Mastery.

---

## Verified Clinical Team

1. **Cassandra Leclerc**, MA, MBA, LMFT, LADC-1, MLADC
   - 14+ years in Mental Health and Addiction Treatment
   - Specialties: Couples Therapy, Family Therapy, First Responders, Providers, Addiction, Veterans.
2. **Erica Michael**, MA, BCPC, CFC
   - 15+ years in Mental Health and Addiction Treatment
   - Specialties: Individual Therapy (Ages 16–99), Addiction, First Responders, Veterans, Justice-Involved individuals, Forensic Evaluations.
3. **Deb Smith**, MA, LADC-2
   - Outpatient clinician specializing in dual diagnosis, crisis intervention, mood disorders (anxiety, depression, bipolar, schizophrenia, OCD, PTSD).

---

## Verified Business Information

- **Telephone:** 978.447.3404
- **Fax:** 978.396.4384
- **Email:** Admin@TranscendingChaos.org
- **Practice Address:** 1 Bridgeview Circle, Suite 5, Tyngsborough, MA 01879-2053
- **Mailing Address:** 265 Chelmsford St., Suite 7, Chelmsford, MA 01824-2665
- **SimplePractice Portal:** `https://transcendingchaos.clientsecure.me/`
- **Client Sign-In:** `https://transcendingchaos.clientsecure.me/sign-in`

---

## Technology Stack

- **React 19**
- **TypeScript**
- **Vite 8**
- **Tailwind CSS v4**
- **Lucide React** (icons)
- **JSON-LD Schema.org Structured Data** (`MedicalBusiness`, `LocalBusiness`)

---

## Development & Production Commands

```bash
# Install dependencies
npm install

# Start local development server (port 3000)
npm run dev

# Build for production
npm run build
```
