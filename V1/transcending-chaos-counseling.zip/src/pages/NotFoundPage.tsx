import React from "react";
import { useRouter } from "../context/RouterContext";
import { BrandEmblem } from "../components/BrandLogo";
import { Home, Users, Briefcase, Phone, ArrowLeft } from "lucide-react";

export const NotFoundPage: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="min-h-[70vh] flex items-center justify-center py-20 px-4 bg-[#F6F8FC]">
      <div className="max-w-xl w-full text-center bg-white p-10 sm:p-14 rounded-3xl border border-slate-200/90 shadow-xl flex flex-col items-center">
        <BrandEmblem size={64} className="mb-6" />

        <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2">
          PAGE NOT FOUND · 404
        </span>

        <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight mb-4">
          Finding Your Center
        </h1>

        <p className="text-sm text-slate-600 leading-relaxed max-w-md mb-8">
          The page or link you requested is unavailable or may have moved. Let us help guide you back to clarity.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full mb-8">
          <button
            type="button"
            onClick={() => navigate("/")}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#174F86] text-white text-xs font-semibold hover:bg-[#123e6b] transition-colors"
          >
            <Home className="w-4 h-4" />
            <span>Return to Home</span>
          </button>

          <button
            type="button"
            onClick={() => navigate("/schedule")}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#F5BD00] text-[#0B2440] text-xs font-bold uppercase tracking-wider hover:bg-[#e0ad00] transition-colors"
          >
            <span>Schedule Here</span>
          </button>

          <button
            type="button"
            onClick={() => navigate("/providers")}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 text-slate-700 text-xs font-medium hover:bg-slate-200 transition-colors"
          >
            <Users className="w-4 h-4" />
            <span>Our Clinicians</span>
          </button>

          <button
            type="button"
            onClick={() => navigate("/services")}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 text-slate-700 text-xs font-medium hover:bg-slate-200 transition-colors"
          >
            <Briefcase className="w-4 h-4" />
            <span>Services Offered</span>
          </button>
        </div>

        <button
          type="button"
          onClick={() => window.history.back()}
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-600 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Go back to previous page</span>
        </button>
      </div>
    </div>
  );
};
