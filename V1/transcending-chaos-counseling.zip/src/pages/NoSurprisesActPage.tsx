import React from "react";
import { SITE_INFO } from "../data/siteInfo";
import { useRouter } from "../context/RouterContext";
import { ArrowLeft, ShieldCheck, ExternalLink } from "lucide-react";
import { FadeIn, TextReveal } from "../components/motion/MotionSystem";

export const NoSurprisesActPage: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="flex flex-col w-full bg-white">
      {/* Header with seamless gradient */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#F6F8FC] via-white to-[#F0F5FA] py-12 sm:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn direction="left" distance={16}>
            <button
              onClick={() => navigate("/")}
              className="inline-flex items-center gap-2 text-xs font-semibold text-[#174F86] hover:text-[#0B2440] transition-colors mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return to Home</span>
            </button>
          </FadeIn>

          <FadeIn direction="down" distance={16} delay={0.1}>
            <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2 block">
              CONSUMER PROTECTION DISCLOSURE
            </span>
          </FadeIn>

          <TextReveal
            tag="h1"
            text="No Surprises Act & Good Faith Estimate Notice"
            className="font-heading font-extrabold text-3xl sm:text-4xl text-[#0B2440] tracking-tight mb-4"
          />

          <FadeIn direction="up" distance={16} delay={0.2}>
            <p className="text-sm text-slate-600 leading-relaxed">
              Your Right to Receive a Good Faith Estimate of Expected Healthcare Costs
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Disclosure Content */}
      <section className="py-12 sm:py-16 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn direction="up" distance={20} delay={0.1}>
            <div className="prose prose-slate max-w-none space-y-10 text-slate-700 text-sm leading-relaxed">
              {/* Banner overview */}
              <div className="p-6 sm:p-8 rounded-2xl bg-white/95 backdrop-blur-xs border border-slate-100/90 shadow-md shadow-blue-950/5">
                <h2 className="font-heading font-bold text-lg text-[#0B2440] mb-3 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#174F86]" />
                  <span>Protection Against Surprise Medical Bills</span>
                </h2>
                <p>
                  Under Section 2799B-6 of the Public Health Service Act and the federal "No Surprises Act", healthcare providers are required to provide individuals who are not enrolled in an insurance plan or who choose not to file a claim with their insurance ("self-pay") an estimate of the expected charges for non-emergency medical items and services, including mental health counseling.
                </p>
              </div>

            {/* Core Rights */}
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                Key Protections for Clients
              </h3>
              <ul className="list-disc pl-5 space-y-3">
                <li>
                  <strong>Right to a Written Estimate:</strong> You have the right to receive a Good Faith Estimate (GFE) for the total expected cost of any non-emergency counseling sessions or psychiatric evaluations.
                </li>
                <li>
                  <strong>Timely Delivery:</strong> If you schedule a service at least 3 business days in advance, your provider must provide a written Good Faith Estimate within 1 business day of scheduling. If you schedule at least 10 business days in advance, you must receive it within 3 business days.
                </li>
                <li>
                  <strong>Advance Request:</strong> You can also request a Good Faith Estimate in writing before you schedule any appointment with our clinicians.
                </li>
                <li>
                  <strong>Billing Dispute Rights:</strong> If you receive a bill that is at least $400 more than your Good Faith Estimate, you have the right to dispute the bill through the federal patient-provider dispute resolution process.
                </li>
              </ul>
            </div>

            {/* Scope of Estimate */}
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                What is Included in Your Estimate
              </h3>
              <p className="mb-3">
                A Good Faith Estimate displays the expected costs of services that are reasonably expected for your mental health care needs. However, psychotherapy is an individualized process; frequency and duration may vary based on your personal progress and evolving clinical goals.
              </p>
              <p>
                The Good Faith Estimate does not obligate you to complete a specific number of sessions. You may pause, adjust, or discontinue services at any time.
              </p>
            </div>

            {/* Dispute Resolution */}
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                How to Dispute a Bill
              </h3>
              <p className="mb-3">
                If your bill exceeds your Good Faith Estimate by $400 or more:
              </p>
              <ol className="list-decimal pl-5 space-y-2">
                <li>Contact Transcending Chaos Counseling directly to review the billing discrepancy and resolve any administrative misunderstanding.</li>
                <li>You may initiate a dispute with the U.S. Department of Health and Human Services (HHS) within 120 days of the date on the initial bill.</li>
                <li>Initiating a dispute will not adversely affect the quality of your healthcare services.</li>
              </ol>
            </div>

            {/* HHS Official Reference */}
            <div className="pt-6 border-t border-slate-200">
              <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-3">
                Official Government Resources
              </h3>
              <p className="mb-4">
                For more information about your right to a Good Faith Estimate or the federal dispute resolution process, visit the Centers for Medicare & Medicaid Services (CMS) website:
              </p>
              <a
                href="https://www.cms.gov/nosurprises"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#EAF2FA] text-[#174F86] font-semibold text-xs hover:bg-[#d5e6f8] transition-colors"
              >
                <span>Visit CMS.gov/nosurprises</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
            </div>
          </FadeIn>
        </div>
      </section>
    </div>
  );
};
