import React from "react";
import { motion, useReducedMotion } from "motion/react";

// Premium custom cubic-bezier curves for healthcare & luxury editorial feel
export const EASING = {
  smooth: [0.21, 0.47, 0.32, 0.98] as const, // Gentle deceleration
  editorial: [0.16, 1, 0.3, 1] as const,     // High-end spring-like smooth settle
  soft: [0.25, 0.1, 0.25, 1] as const,       // Subtle natural glide
};

export interface MotionProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  duration?: number;
  viewportMargin?: string;
}

/**
 * FadeIn: Smooth directional entrance with opacity and subtle transform
 */
export const FadeIn: React.FC<
  MotionProps & {
    direction?: "up" | "down" | "left" | "right" | "none";
    distance?: number;
    blur?: boolean;
  }
> = ({
  children,
  className = "",
  direction = "up",
  distance = 28,
  delay = 0,
  duration = 0.7,
  blur = true,
  viewportMargin = "-40px",
}) => {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  const getOffset = () => {
    switch (direction) {
      case "up":
        return { y: distance, x: 0 };
      case "down":
        return { y: -distance, x: 0 };
      case "left":
        return { x: distance, y: 0 };
      case "right":
        return { x: -distance, y: 0 };
      case "none":
      default:
        return { x: 0, y: 0 };
    }
  };

  const offset = getOffset();

  return (
    <motion.div
      initial={{
        opacity: 0,
        x: offset.x,
        y: offset.y,
        filter: blur ? "blur(4px)" : "none",
      }}
      whileInView={{
        opacity: 1,
        x: 0,
        y: 0,
        filter: "blur(0px)",
      }}
      viewport={{ once: true, margin: viewportMargin }}
      transition={{
        duration,
        delay,
        ease: EASING.editorial,
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

/**
 * TextReveal: Staggered words or phrase entrance with blur-to-clear reveal
 */
export const TextReveal: React.FC<{
  text: string;
  className?: string;
  tag?: "h1" | "h2" | "h3" | "p" | "span";
  delay?: number;
  duration?: number;
}> = ({
  text,
  className = "",
  tag = "h1",
  delay = 0,
  duration = 0.5,
}) => {
  const shouldReduceMotion = useReducedMotion();
  const words = text.split(" ");

  if (shouldReduceMotion) {
    const Tag = tag;
    return <Tag className={className}>{text}</Tag>;
  }

  const Tag = motion[tag] as React.ElementType;

  return (
    <Tag
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-40px" }}
      variants={{
        hidden: {},
        visible: {
          transition: {
            staggerChildren: 0.04,
            delayChildren: delay,
          },
        },
      }}
      className={className}
    >
      {words.map((word, i) => (
        <motion.span
          key={`${word}-${i}`}
          className="inline-block mr-[0.28em] last:mr-0 will-change-transform"
          variants={{
            hidden: {
              opacity: 0,
              y: 18,
              filter: "blur(5px)",
            },
            visible: {
              opacity: 1,
              y: 0,
              filter: "blur(0px)",
              transition: {
                duration,
                ease: EASING.editorial,
              },
            },
          }}
        >
          {word}
        </motion.span>
      ))}
    </Tag>
  );
};

/**
 * StaggerContainer & StaggerItem: Orchestrated group reveals
 */
export const StaggerContainer: React.FC<{
  children: React.ReactNode;
  className?: string;
  staggerDelay?: number;
  initialDelay?: number;
  viewportMargin?: string;
}> = ({
  children,
  className = "",
  staggerDelay = 0.1,
  initialDelay = 0.05,
  viewportMargin = "-50px",
}) => {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: viewportMargin }}
      variants={{
        hidden: {},
        visible: {
          transition: {
            staggerChildren: staggerDelay,
            delayChildren: initialDelay,
          },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

export const StaggerItem: React.FC<{
  children: React.ReactNode;
  className?: string;
  direction?: "up" | "down" | "left" | "right" | "none";
  distance?: number;
}> = ({ children, className = "", direction = "up", distance = 24 }) => {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  const getOffset = () => {
    switch (direction) {
      case "up":
        return { y: distance, x: 0 };
      case "down":
        return { y: -distance, x: 0 };
      case "left":
        return { x: distance, y: 0 };
      case "right":
        return { x: -distance, y: 0 };
      case "none":
      default:
        return { x: 0, y: 0 };
    }
  };

  const offset = getOffset();

  return (
    <motion.div
      variants={{
        hidden: {
          opacity: 0,
          x: offset.x,
          y: offset.y,
          filter: "blur(4px)",
        },
        visible: {
          opacity: 1,
          x: 0,
          y: 0,
          filter: "blur(0px)",
          transition: {
            duration: 0.65,
            ease: EASING.editorial,
          },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

/**
 * ImageReveal: Editorial masked entrance with subtle zoom effect
 */
export const ImageReveal: React.FC<{
  src: string;
  alt: string;
  className?: string;
  imageClassName?: string;
  aspectRatio?: string;
  delay?: number;
}> = ({
  src,
  alt,
  className = "",
  imageClassName = "",
  aspectRatio = "aspect-4/3",
  delay = 0.1,
}) => {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return (
      <div className={`overflow-hidden rounded-2xl ${aspectRatio} ${className}`}>
        <img src={src} alt={alt} className={`w-full h-full object-cover ${imageClassName}`} />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{
        duration: 0.85,
        delay,
        ease: EASING.editorial,
      }}
      className={`relative overflow-hidden rounded-2xl ${aspectRatio} ${className} group`}
    >
      <motion.img
        src={src}
        alt={alt}
        className={`w-full h-full object-cover group-hover:scale-104 transition-transform duration-700 ease-out will-change-transform ${imageClassName}`}
      />
    </motion.div>
  );
};

/**
 * ScaleIn: Gentle scale & soft glow reveal for highlights or key cards
 */
export const ScaleIn: React.FC<
  MotionProps & {
    fromScale?: number;
  }
> = ({
  children,
  className = "",
  fromScale = 0.94,
  delay = 0,
  duration = 0.7,
  viewportMargin = "-40px",
}) => {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: fromScale, filter: "blur(4px)" }}
      whileInView={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
      viewport={{ once: true, margin: viewportMargin }}
      transition={{
        duration,
        delay,
        ease: EASING.editorial,
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};
