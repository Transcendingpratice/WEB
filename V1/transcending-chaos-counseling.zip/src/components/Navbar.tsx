import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { BrandEmblem } from "./BrandLogo";
import { useRouter } from "../context/RouterContext";
import { SITE_INFO } from "../data/siteInfo";
import { SERVICES } from "../data/services";
import { PROVIDERS } from "../data/providers";
import {
  Menu,
  X,
  ArrowUpRight,
  Phone,
  ChevronDown,
  ChevronRight,
  Laptop,
  MapPin,
  User,
  Heart,
  Scale,
  Shield,
  Award,
  ShieldAlert,
  Brain,
  Clock,
  Sparkles,
  ShieldCheck,
} from "lucide-react";

export const Navbar: React.FC = () => {
  const { currentPath, navigate } = useRouter();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Desktop Dropdown State
  const [openDropdown, setOpenDropdown] = useState<"services" | "providers" | "resources" | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Mobile Accordion States
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const [mobileTelehealthOpen, setMobileTelehealthOpen] = useState(false);
  const [mobileInPersonOpen, setMobileInPersonOpen] = useState(false);
  const [mobileProvidersOpen, setMobileProvidersOpen] = useState(false);
  const [mobileResourcesOpen, setMobileResourcesOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest(".nav-dropdown-container")) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  const handleMouseEnter = (menu: "services" | "providers" | "resources") => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setOpenDropdown(menu);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setOpenDropdown(null);
    }, 180);
  };

  const isServicesActive = currentPath === "/services" || currentPath.startsWith("/services/");
  const isProvidersActive = currentPath === "/providers" || currentPath.startsWith("/providers/");
  const isResourcesActive = currentPath === "/privacy" || currentPath === "/good-faith-estimate";

  return (
    <>
      {/* Top Banner Notice: Clinical Service Areas & Direct SimplePractice Booking */}
      <div className="bg-[#0B2440] text-slate-200 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 truncate">
            <span className="inline-block w-2 h-2 rounded-full bg-[#F5BD00] shrink-0" />
            <span className="truncate">
              In-Person in <strong>Tyngsborough, MA</strong> & Virtual Telehealth across{" "}
              <strong>MA & NH</strong>
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs shrink-0">
            <a
              href={`tel:${SITE_INFO.phoneRaw}`}
              className="hidden sm:inline-flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#F5BD00]" />
              <span>{SITE_INFO.phone}</span>
            </a>
            <span className="text-slate-600 hidden sm:inline" aria-hidden="true">|</span>
            <a
              href={SITE_INFO.portalSignInUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[#F5BD00] hover:text-white font-medium transition-colors"
              title="Existing Client Sign-In (SimplePractice)"
            >
              <span>Client Portal</span>
              <ArrowUpRight className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>

      {/* Top Navigation */}
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200/80 py-3"
            : "bg-white border-b border-slate-100 py-3.5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-8">
            {/* Zone 1: Brand Wordmark (Single text & emblem lockup) */}
            <a
              href="#/"
              onClick={(e) => {
                e.preventDefault();
                navigate("/");
              }}
              className="flex items-center gap-3 whitespace-nowrap shrink-0 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#174F86] rounded-lg p-1"
            >
              <BrandEmblem size={38} className="group-hover:scale-105 transition-transform" />
              <div className="flex flex-col">
                <span className="font-heading font-extrabold text-base sm:text-lg text-[#0B2440] tracking-tight leading-none group-hover:text-[#174F86] transition-colors">
                  Transcending Chaos
                </span>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#174F86] mt-0.5">
                  Counseling
                </span>
              </div>
            </a>

            {/* Zone 2: Navigation Links with Rich Dropdowns */}
            <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-700">
              {/* Home */}
              <a
                href="#/"
                onClick={(e) => {
                  e.preventDefault();
                  navigate("/");
                }}
                className={`whitespace-nowrap shrink-0 relative py-1.5 transition-colors ${
                  currentPath === "/" ? "text-[#174F86] font-semibold" : "hover:text-[#174F86]"
                }`}
              >
                Home
                {currentPath === "/" && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#174F86] rounded-full" />
                )}
              </a>

              {/* Our Services (with 2 Delivery Pathways & Sub-Dropdowns) */}
              <div
                className="relative nav-dropdown-container"
                onMouseEnter={() => handleMouseEnter("services")}
                onMouseLeave={handleMouseLeave}
              >
                <button
                  type="button"
                  onClick={() => {
                    navigate("/services");
                    setOpenDropdown(null);
                  }}
                  className={`inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 py-1.5 transition-colors cursor-pointer ${
                    isServicesActive ? "text-[#174F86] font-semibold" : "hover:text-[#174F86]"
                  }`}
                  aria-expanded={openDropdown === "services"}
                >
                  <span>Our Services</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      openDropdown === "services" ? "rotate-180 text-[#174F86]" : "text-slate-400"
                    }`}
                  />
                  {isServicesActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#174F86] rounded-full" />
                  )}
                </button>

                {/* Dropdown Menu for Our Services */}
                {openDropdown === "services" && (
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-[92vw] max-w-[820px] max-h-[82vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-slate-200/90 p-5 sm:p-6 z-50 animate-in fade-in duration-150">
                    {/* Primary Delivery Pathways: Telehealth & In-Person */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pb-5 border-b border-slate-100">
                      <a
                        href="#/services/telehealth-therapy"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/services/telehealth-therapy");
                          setOpenDropdown(null);
                        }}
                        className="group flex items-start gap-3.5 p-3.5 rounded-xl bg-[#F6F8FC] hover:bg-[#EAF2FA] border border-slate-200/70 hover:border-[#174F86]/40 transition-all"
                      >
                        <div className="w-10 h-10 rounded-lg bg-[#174F86] text-white flex items-center justify-center shrink-0 shadow-xs">
                          <Laptop className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-[#174F86] bg-white px-2 py-0.5 rounded border border-[#174F86]/20">
                              Virtual Care
                            </span>
                            <span className="text-[11px] text-slate-500 font-medium">MA & NH</span>
                          </div>
                          <div className="font-heading font-bold text-sm text-[#0B2440] group-hover:text-[#174F86] transition-colors mt-1">
                            Telehealth Therapy / Online
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                            Encrypted, confidential virtual sessions from your home
                          </p>
                        </div>
                      </a>

                      <a
                        href="#/services/in-person-therapy"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/services/in-person-therapy");
                          setOpenDropdown(null);
                        }}
                        className="group flex items-start gap-3.5 p-3.5 rounded-xl bg-[#F6F8FC] hover:bg-[#EAF2FA] border border-slate-200/70 hover:border-[#174F86]/40 transition-all"
                      >
                        <div className="w-10 h-10 rounded-lg bg-[#0B2440] text-white flex items-center justify-center shrink-0 shadow-xs">
                          <MapPin className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-[#0B2440] bg-white px-2 py-0.5 rounded border border-slate-300">
                              Office Visits
                            </span>
                            <span className="text-[11px] text-slate-500 font-medium">Tyngsborough, MA</span>
                          </div>
                          <div className="font-heading font-bold text-sm text-[#0B2440] group-hover:text-[#174F86] transition-colors mt-1">
                            In-Person Therapy
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                            Quiet, dedicated practice suites at 1 Bridgeview Circle
                          </p>
                        </div>
                      </a>
                    </div>

                    {/* Sub-Services Grid across Core, Evaluations, Needs & Coming Soon */}
                    <div className="grid grid-cols-3 gap-6 pt-5">
                      {/* Sub-column 1: Core Therapy & Evaluations */}
                      <div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 pb-2 mb-2 border-b border-slate-100">
                          Core Therapy & Evaluations
                        </div>
                        <div className="space-y-1">
                          {/* Individual Therapy */}
                          <a
                            href="#/services/individual-therapy"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/individual-therapy");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg hover:bg-[#F6F8FC] transition-colors"
                          >
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              Individual Therapy
                            </div>
                            <div className="text-[11px] text-slate-500 line-clamp-1">
                              Anxiety, depression, trauma & life transitions
                            </div>
                          </a>

                          {/* Couple Therapy */}
                          <a
                            href="#/services/couples-therapy"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/couples-therapy");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg hover:bg-[#F6F8FC] transition-colors"
                          >
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              Couple Therapy
                            </div>
                            <div className="text-[11px] text-slate-500 line-clamp-1">
                              Conflict de-escalation, trust repair & communication
                            </div>
                          </a>

                          {/* Court, Probation, RMV/DMV Evaluations */}
                          <a
                            href="#/services/court-probation-evaluations"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/court-probation-evaluations");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg hover:bg-[#F6F8FC] transition-colors"
                          >
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              Court, Probation, RMV/DMV Evaluations
                            </div>
                            <div className="text-[10px] text-slate-500 leading-tight mt-0.5">
                              Mental Health, Addiction, Recidivism, Driving, Etc.
                            </div>
                          </a>
                        </div>
                      </div>

                      {/* Sub-column 2: Services Offered to a Variety of Needs */}
                      <div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 pb-2 mb-2 border-b border-slate-100">
                          Services for a Variety of Needs
                        </div>
                        <div className="space-y-1">
                          {/* First Responders */}
                          <a
                            href="#/services/first-responders"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/first-responders");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg hover:bg-[#F6F8FC] transition-colors"
                          >
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              First Responders
                            </div>
                            <div className="text-[11px] text-slate-500 line-clamp-1">
                              Police, Fire, EMS, Dispatchers & Medical
                            </div>
                          </a>

                          {/* Veterans */}
                          <a
                            href="#/services/veterans"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/veterans");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg hover:bg-[#F6F8FC] transition-colors"
                          >
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              Veterans
                            </div>
                            <div className="text-[11px] text-slate-500 line-clamp-1">
                              Civilian transition, combat stress & moral injury
                            </div>
                          </a>

                          {/* Addiction */}
                          <a
                            href="#/services/addiction"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/addiction");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg hover:bg-[#F6F8FC] transition-colors"
                          >
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              Addiction Treatment
                            </div>
                            <div className="text-[10px] text-slate-500 leading-tight mt-0.5">
                              Alcohol, Drug, Gambling, Video Game, Sex, and Other Addictions
                            </div>
                          </a>

                          {/* Mental Health */}
                          <a
                            href="#/services/mental-health"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/mental-health");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg hover:bg-[#F6F8FC] transition-colors"
                          >
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              Mental Health Counseling
                            </div>
                            <div className="text-[10px] text-slate-500 leading-tight mt-0.5">
                              Depression, OCD, PTSD, ADHD, Anxiety, BPD, Bipolar, Schizophrenia, Personality Disorders
                            </div>
                          </a>
                        </div>
                      </div>

                      {/* Sub-column 3: Coming Soon! Group Therapy */}
                      <div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-[#F5BD00] pb-2 mb-2 border-b border-slate-100 flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-[#F5BD00]" />
                          <span>Coming Soon! (Early 2027)</span>
                        </div>
                        <div className="space-y-1">
                          <a
                            href="#/services/group-therapy"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services/group-therapy");
                              setOpenDropdown(null);
                            }}
                            className="group block p-2 rounded-lg bg-amber-50/50 hover:bg-amber-100/50 border border-amber-200/60 transition-colors mb-2"
                          >
                            <div className="text-xs font-bold text-amber-950 group-hover:text-[#174F86] transition-colors">
                              Group Therapy Cohorts
                            </div>
                            <div className="text-[11px] text-amber-800/80 leading-relaxed mt-1">
                              • Mental Health Group Therapy<br />
                              • Addiction Group Therapy<br />
                              • Gambling Group Therapy
                            </div>
                          </a>
                        </div>

                        <div className="pt-3 border-t border-slate-100 mt-4">
                          <a
                            href="#/services"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/services");
                              setOpenDropdown(null);
                            }}
                            className="text-xs font-bold text-[#174F86] hover:underline inline-flex items-center gap-1"
                          >
                            <span>Explore All Services Overview</span>
                            <span>→</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Providers (with Dropdown) */}
              <div
                className="relative nav-dropdown-container"
                onMouseEnter={() => handleMouseEnter("providers")}
                onMouseLeave={handleMouseLeave}
              >
                <button
                  type="button"
                  onClick={() => {
                    navigate("/providers");
                    setOpenDropdown(null);
                  }}
                  className={`inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 py-1.5 transition-colors cursor-pointer ${
                    isProvidersActive ? "text-[#174F86] font-semibold" : "hover:text-[#174F86]"
                  }`}
                  aria-expanded={openDropdown === "providers"}
                >
                  <span>Providers</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      openDropdown === "providers" ? "rotate-180 text-[#174F86]" : "text-slate-400"
                    }`}
                  />
                  {isProvidersActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#174F86] rounded-full" />
                  )}
                </button>

                {/* Dropdown Menu for Providers */}
                {openDropdown === "providers" && (
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-200/90 p-4 z-50 animate-in fade-in duration-150">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 pb-2 mb-2 border-b border-slate-100">
                      Our Licensed Clinicians
                    </div>
                    <div className="space-y-1.5">
                      {PROVIDERS.map((provider) => (
                        <a
                          key={provider.id}
                          href={`#/providers/${provider.slug}`}
                          onClick={(e) => {
                            e.preventDefault();
                            navigate(`/providers/${provider.slug}`);
                            setOpenDropdown(null);
                          }}
                          className="group flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#F6F8FC] transition-colors"
                        >
                          <img
                            src={provider.image}
                            alt={provider.name}
                            className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                          />
                          <div>
                            <div className="text-xs font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                              {provider.name}
                            </div>
                            <div className="text-[11px] text-[#174F86] font-medium">
                              {provider.credentials}
                            </div>
                            <div className="text-[10px] text-slate-400 line-clamp-1">
                              {provider.experience}
                            </div>
                          </div>
                        </a>
                      ))}
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-100 text-center">
                      <a
                        href="#/providers"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/providers");
                          setOpenDropdown(null);
                        }}
                        className="text-xs font-bold text-[#174F86] hover:underline inline-flex items-center gap-1"
                      >
                        <span>Meet All Clinicians & Bios</span>
                        <span>→</span>
                      </a>
                    </div>
                  </div>
                )}
              </div>

              {/* Resources & Legal Dropdown */}
              <div
                className="relative nav-dropdown-container"
                onMouseEnter={() => handleMouseEnter("resources")}
                onMouseLeave={handleMouseLeave}
              >
                <button
                  type="button"
                  className={`inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 py-1.5 transition-colors cursor-pointer ${
                    isResourcesActive ? "text-[#174F86] font-semibold" : "hover:text-[#174F86]"
                  }`}
                  aria-expanded={openDropdown === "resources"}
                >
                  <span>Resources & Legal</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      openDropdown === "resources" ? "rotate-180 text-[#174F86]" : "text-slate-400"
                    }`}
                  />
                  {isResourcesActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#174F86] rounded-full" />
                  )}
                </button>

                {openDropdown === "resources" && (
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200/90 p-4 z-50 animate-in fade-in duration-150">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 pb-2 mb-2 border-b border-slate-100">
                      Disclosures & Policies
                    </div>
                    <div className="space-y-1">
                      <a
                        href="#/privacy"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/privacy");
                          setOpenDropdown(null);
                        }}
                        className="block p-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-[#F6F8FC] hover:text-[#174F86] transition-colors"
                      >
                        Notice of Privacy Practices (HIPAA)
                      </a>
                      <a
                        href="#/good-faith-estimate"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/good-faith-estimate");
                          setOpenDropdown(null);
                        }}
                        className="block p-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-[#F6F8FC] hover:text-[#174F86] transition-colors"
                      >
                        No Surprises Act & Good Faith Estimate
                      </a>
                      <a
                        href="#/schedule"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/schedule");
                          setOpenDropdown(null);
                        }}
                        className="block p-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-[#F6F8FC] hover:text-[#174F86] transition-colors"
                      >
                        Scheduling & Telehealth FAQ
                      </a>
                    </div>
                  </div>
                )}
              </div>

              {/* Contact */}
              <a
                href="#/contact"
                onClick={(e) => {
                  e.preventDefault();
                  navigate("/contact");
                }}
                className={`whitespace-nowrap shrink-0 relative py-1.5 transition-colors ${
                  currentPath === "/contact"
                    ? "text-[#174F86] font-semibold"
                    : "hover:text-[#174F86]"
                }`}
              >
                Contact
                {currentPath === "/contact" && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#174F86] rounded-full" />
                )}
              </a>
            </nav>

            {/* Zone 3: 1 Primary Action (Schedule Here CTA) & Mobile Toggle */}
            <div className="flex items-center gap-3 shrink-0">
              <a
                href="#/schedule"
                onClick={(e) => {
                  e.preventDefault();
                  navigate("/schedule");
                }}
                className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-lg shadow-sm whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#174F86]"
              >
                <span>Schedule Here</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#0B2440]" />
              </a>

              {/* Mobile menu trigger */}
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg text-slate-700 hover:text-[#174F86] hover:bg-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#174F86]"
                aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
                aria-expanded={isMobileMenuOpen}
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Animated Mobile Slide-Over Drawer Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden overflow-hidden">
            {/* Backdrop with blur & click to dismiss */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="absolute inset-0 bg-[#071626]/75 backdrop-blur-xs"
              aria-hidden="true"
            />

            {/* Slide-Over Panel */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 300 }}
              className="absolute inset-y-0 right-0 w-full max-w-sm sm:max-w-md bg-white shadow-2xl flex flex-col justify-between overflow-hidden"
            >
              {/* Drawer Header */}
              <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-100 bg-[#F6F8FC]/60">
                <a
                  href="#/"
                  onClick={(e) => {
                    e.preventDefault();
                    setIsMobileMenuOpen(false);
                    navigate("/");
                  }}
                  className="flex items-center gap-2.5 group"
                >
                  <BrandEmblem size={30} className="shrink-0" />
                  <div className="flex flex-col">
                    <span className="font-heading font-extrabold text-sm text-[#0B2440] leading-tight">
                      Transcending Chaos
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#174F86]">
                      Counseling
                    </span>
                  </div>
                </a>

                <button
                  type="button"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-9 h-9 flex items-center justify-center text-slate-500 hover:text-slate-900 rounded-xl hover:bg-slate-200/60 active:scale-95 transition-all"
                  aria-label="Close navigation menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Navigation Body */}
              <div className="flex-1 overflow-y-auto px-4 sm:px-5 py-4 space-y-2">
                {/* Practice location notice */}
                <div className="p-2.5 rounded-xl bg-[#EAF2FA] text-[11px] text-[#174F86] font-medium flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#F5BD00] shrink-0" />
                  <span>Tyngsborough Sanctuary & Telehealth MA & NH</span>
                </div>

                <nav className="flex flex-col gap-1 pt-1">
                  {/* Home */}
                  <a
                    href="#/"
                    onClick={(e) => {
                      e.preventDefault();
                      setIsMobileMenuOpen(false);
                      navigate("/");
                    }}
                    className={`px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors flex items-center justify-between ${
                      currentPath === "/"
                        ? "bg-[#174F86] text-white shadow-xs"
                        : "text-slate-800 hover:bg-slate-50"
                    }`}
                  >
                    <span>Home</span>
                    <span className="text-xs opacity-60">→</span>
                  </a>

                  {/* Our Services Accordion */}
                  <div className="rounded-xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setMobileServicesOpen(!mobileServicesOpen)}
                      className={`w-full px-3.5 py-3 rounded-xl text-sm font-semibold flex items-center justify-between transition-colors ${
                        isServicesActive
                          ? "bg-[#EAF2FA] text-[#174F86]"
                          : "text-slate-800 hover:bg-slate-50"
                      }`}
                    >
                      <span>Our Clinical Services</span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform duration-200 ${
                          mobileServicesOpen ? "rotate-180 text-[#174F86]" : "text-slate-400"
                        }`}
                      />
                    </button>

                    {mobileServicesOpen && (
                      <div className="pl-3 pr-2 py-2 space-y-2.5 bg-slate-50/80 rounded-xl mt-1 text-xs">
                        <a
                          href="#/services"
                          onClick={(e) => {
                            e.preventDefault();
                            setIsMobileMenuOpen(false);
                            navigate("/services");
                          }}
                          className="block px-3 py-2 font-bold text-[#174F86] hover:underline"
                        >
                          → View All Services Overview
                        </a>

                        {/* Delivery Modes */}
                        <div className="grid grid-cols-1 gap-2 px-1">
                          <a
                            href="#/services/telehealth-therapy"
                            onClick={(e) => {
                              e.preventDefault();
                              setIsMobileMenuOpen(false);
                              navigate("/services/telehealth-therapy");
                            }}
                            className="p-2.5 rounded-lg bg-white border border-slate-200/70 hover:border-[#174F86]/40 flex items-center gap-2.5 font-medium text-slate-800"
                          >
                            <Laptop className="w-4 h-4 text-[#174F86] shrink-0" />
                            <div className="min-w-0">
                              <span className="font-bold text-xs block text-[#0B2440]">Telehealth Therapy</span>
                              <span className="text-[10px] text-slate-500">Virtual across MA & NH</span>
                            </div>
                          </a>

                          <a
                            href="#/services/in-person-therapy"
                            onClick={(e) => {
                              e.preventDefault();
                              setIsMobileMenuOpen(false);
                              navigate("/services/in-person-therapy");
                            }}
                            className="p-2.5 rounded-lg bg-white border border-slate-200/70 hover:border-[#174F86]/40 flex items-center gap-2.5 font-medium text-slate-800"
                          >
                            <MapPin className="w-4 h-4 text-[#F5BD00] shrink-0" />
                            <div className="min-w-0">
                              <span className="font-bold text-xs block text-[#0B2440]">In-Person Therapy</span>
                              <span className="text-[10px] text-slate-500">Tyngsborough, MA Sanctuary</span>
                            </div>
                          </a>
                        </div>

                        {/* Core Services Links */}
                        <div className="pt-2 border-t border-slate-200/50 space-y-1 pl-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                            Core Specialized Therapy:
                          </span>
                          {[
                            { name: "Individual Therapy", path: "/services/individual-therapy" },
                            { name: "Couple Therapy", path: "/services/couples-therapy" },
                            { name: "Court, Probation & RMV Evaluations", path: "/services/court-probation-evaluations" },
                            { name: "First Responders Support", path: "/services/first-responders" },
                            { name: "Veterans Support", path: "/services/veterans" },
                            { name: "Addiction Treatment", path: "/services/addiction" },
                            { name: "Mental Health Counseling", path: "/services/mental-health" },
                            { name: "Group Therapy (Coming Soon 2027)", path: "/services/group-therapy" },
                          ].map((item) => (
                            <a
                              key={item.path}
                              href={`#${item.path}`}
                              onClick={(e) => {
                                e.preventDefault();
                                setIsMobileMenuOpen(false);
                                navigate(item.path);
                              }}
                              className="block py-1.5 px-2 text-xs text-slate-700 hover:text-[#174F86] rounded-md hover:bg-white transition-colors"
                            >
                              • {item.name}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Providers Accordion */}
                  <div className="rounded-xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setMobileProvidersOpen(!mobileProvidersOpen)}
                      className={`w-full px-3.5 py-3 rounded-xl text-sm font-semibold flex items-center justify-between transition-colors ${
                        isProvidersActive
                          ? "bg-[#EAF2FA] text-[#174F86]"
                          : "text-slate-800 hover:bg-slate-50"
                      }`}
                    >
                      <span>Our Clinicians</span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform duration-200 ${
                          mobileProvidersOpen ? "rotate-180 text-[#174F86]" : "text-slate-400"
                        }`}
                      />
                    </button>

                    {mobileProvidersOpen && (
                      <div className="pl-3 pr-2 py-2 space-y-1.5 bg-slate-50/80 rounded-xl mt-1 text-xs">
                        <a
                          href="#/providers"
                          onClick={(e) => {
                            e.preventDefault();
                            setIsMobileMenuOpen(false);
                            navigate("/providers");
                          }}
                          className="block px-3 py-1.5 font-bold text-[#174F86] hover:underline"
                        >
                          → Meet All Clinicians Directory
                        </a>
                        {PROVIDERS.map((p) => (
                          <a
                            key={p.id}
                            href={`#/providers/${p.slug}`}
                            onClick={(e) => {
                              e.preventDefault();
                              setIsMobileMenuOpen(false);
                              navigate(`/providers/${p.slug}`);
                            }}
                            className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-white transition-colors"
                          >
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200"
                            />
                            <div className="min-w-0">
                              <span className="font-semibold text-xs text-[#0B2440] block truncate">
                                {p.name}
                              </span>
                              <span className="text-[10px] text-[#174F86] block truncate">
                                {p.credentials}
                              </span>
                            </div>
                          </a>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Resources & Legal Accordion */}
                  <div className="rounded-xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setMobileResourcesOpen(!mobileResourcesOpen)}
                      className={`w-full px-3.5 py-3 rounded-xl text-sm font-semibold flex items-center justify-between transition-colors ${
                        isResourcesActive
                          ? "bg-[#EAF2FA] text-[#174F86]"
                          : "text-slate-800 hover:bg-slate-50"
                      }`}
                    >
                      <span>Resources & Legal</span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform duration-200 ${
                          mobileResourcesOpen ? "rotate-180 text-[#174F86]" : "text-slate-400"
                        }`}
                      />
                    </button>

                    {mobileResourcesOpen && (
                      <div className="pl-3 pr-2 py-2 space-y-1 bg-slate-50/80 rounded-xl mt-1 text-xs">
                        <a
                          href="#/privacy"
                          onClick={(e) => {
                            e.preventDefault();
                            setIsMobileMenuOpen(false);
                            navigate("/privacy");
                          }}
                          className="block px-3 py-2 text-slate-700 hover:text-[#174F86]"
                        >
                          • Notice of Privacy Practices (HIPAA)
                        </a>
                        <a
                          href="#/good-faith-estimate"
                          onClick={(e) => {
                            e.preventDefault();
                            setIsMobileMenuOpen(false);
                            navigate("/good-faith-estimate");
                          }}
                          className="block px-3 py-2 text-slate-700 hover:text-[#174F86]"
                        >
                          • No Surprises Act & Good Faith Estimate
                        </a>
                        <a
                          href="#/schedule"
                          onClick={(e) => {
                            e.preventDefault();
                            setIsMobileMenuOpen(false);
                            navigate("/schedule");
                          }}
                          className="block px-3 py-2 text-slate-700 hover:text-[#174F86]"
                        >
                          • Scheduling & Telehealth FAQ
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Contact */}
                  <a
                    href="#/contact"
                    onClick={(e) => {
                      e.preventDefault();
                      setIsMobileMenuOpen(false);
                      navigate("/contact");
                    }}
                    className={`px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors flex items-center justify-between ${
                      currentPath === "/contact"
                        ? "bg-[#174F86] text-white shadow-xs"
                        : "text-slate-800 hover:bg-slate-50"
                    }`}
                  >
                    <span>Contact & Location</span>
                    <span className="text-xs opacity-60">→</span>
                  </a>
                </nav>
              </div>

              {/* Drawer Footer Actions */}
              <div className="p-4 sm:p-5 border-t border-slate-100 bg-[#F6F8FC] flex flex-col gap-2.5">
                <a
                  href="#/schedule"
                  onClick={(e) => {
                    e.preventDefault();
                    setIsMobileMenuOpen(false);
                    navigate("/schedule");
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 rounded-xl shadow-xs text-center transition-all min-h-[44px]"
                >
                  <span>Schedule an Appointment</span>
                  <ArrowUpRight className="w-4 h-4 text-[#0B2440]" />
                </a>

                <a
                  href={SITE_INFO.portalSignInUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-[#174F86] bg-white border border-slate-200/80 hover:bg-slate-50 active:scale-98 rounded-xl text-center transition-all min-h-[40px]"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Client Portal Sign-In</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>

                <div className="flex items-center justify-between pt-2 text-xs text-slate-600">
                  <a
                    href={`tel:${SITE_INFO.phoneRaw}`}
                    className="flex items-center gap-1.5 font-bold text-[#174F86] hover:underline"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#F5BD00]" />
                    <span>{SITE_INFO.phone}</span>
                  </a>
                  <a href="tel:988" className="text-[10px] text-slate-500 hover:text-slate-800">
                    Crisis Lifeline: <strong className="text-slate-700">988</strong>
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
