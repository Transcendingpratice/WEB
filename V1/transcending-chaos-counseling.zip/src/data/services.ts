export interface ServiceItem {
  id: string;
  slug: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  deliveryModes: ("telehealth" | "in-person")[];
  category: "core" | "evaluations" | "specialized" | "future";
  keyTopics: string[];
  evidenceBasedApproaches: string[];
  format: string;
  targetAudience?: string;
  bgImage?: string;
  quote?: string;
  details?: {
    whoItIsFor?: string[];
    whatToExpect?: string[];
    commonConcerns?: { title: string; description: string }[];
    clinicalQuestions?: { q: string; a: string }[];
  };
  isComingSoon?: boolean;
  expectedDate?: string;
  subservices?: string[];
}

export const SERVICES: ServiceItem[] = [
  {
    id: "telehealth-therapy",
    slug: "telehealth-therapy",
    title: "Telehealth Therapy / Online",
    shortDescription:
      "Encrypted, confidential virtual therapy delivered to clients throughout Massachusetts and New Hampshire from the comfort of home.",
    fullDescription:
      "Our online telehealth therapy connects you directly with our licensed clinicians via a secure, HIPAA-compliant SimplePractice video portal. Available to residents across Massachusetts and New Hampshire, virtual counseling offers the same clinical rigor, confidentiality, and deep connection as in-office visits—without the friction of commuting, traffic, or scheduling barriers.",
    deliveryModes: ["telehealth"],
    category: "core",
    targetAudience: "Clients residing in Massachusetts and New Hampshire seeking flexible, high-caliber psychotherapy and counseling.",
    bgImage: "/assets/services/serene-nature.jpg",
    quote: "Therapeutic excellence delivered directly to your private, comfortable setting across MA & NH.",
    keyTopics: [
      "Statewide access across Massachusetts and New Hampshire",
      "Encrypted 256-bit HIPAA-compliant SimplePractice video",
      "Flexible morning, afternoon, and evening appointment times",
      "Zero commute time and reduced scheduling stress",
      "Direct portal access from smartphone, tablet, or laptop"
    ],
    evidenceBasedApproaches: [
      "Telehealth-Optimized Cognitive Behavioral Therapy (CBT)",
      "Acceptance and Commitment Therapy (ACT)",
      "Mindfulness-Based Stress Reduction",
      "Client-Centered Teletherapy"
    ],
    format: "Virtual Telehealth (Licensed in MA & NH)"
  },
  {
    id: "in-person-therapy",
    slug: "in-person-therapy",
    title: "In-Person Therapy",
    shortDescription:
      "Warm, confidential face-to-face clinical sessions at our welcoming practice office in Tyngsborough, Massachusetts.",
    fullDescription:
      "For clients who value the grounding presence of a dedicated therapeutic sanctuary, our Tyngsborough office offers a warm, quiet, and completely private clinical environment. Conveniently situated near Route 3 and the New Hampshire border, our suites provide comfortable seating, gentle natural lighting, and a peaceful atmosphere designed to help you decompress and focus on healing.",
    deliveryModes: ["in-person"],
    category: "core",
    targetAudience: "Individuals and couples in Greater Lowell, Tyngsborough, Chelmsford, Westford, and Southern NH who prefer in-person therapy.",
    bgImage: "/assets/hero/hero-sanctuary.jpg",
    quote: "A peaceful physical sanctuary designed for deep reflection, emotional safety, and personal growth.",
    keyTopics: [
      "Dedicated clinical sanctuary at 1 Bridgeview Circle, Suite 5, Tyngsborough, MA",
      "Convenient access from Route 3 with ample free on-site parking",
      "Private, sound-insulated consultation suites with gentle natural light",
      "Serving Greater Lowell, Merrimack Valley, and Southern New Hampshire",
      "Scheduled by appointment through our secure portal"
    ],
    evidenceBasedApproaches: [
      "Client-Centered Humanistic Counseling",
      "In-Person Relational Systems Therapy",
      "Somatic Grounding & Stress De-escalation",
      "Cognitive Behavioral Therapy (CBT)"
    ],
    format: "In-Person (1 Bridgeview Circle, Suite 5, Tyngsborough, MA)"
  },
  {
    id: "individual-therapy",
    slug: "individual-therapy",
    title: "Individual Therapy",
    shortDescription:
      "One-on-one therapy for adults feeling stretched thin, navigating anxiety, processing trauma, or seeking mental mastery.",
    fullDescription:
      "Individual therapy at Transcending Chaos Counseling provides a secure, confidential sanctuary where you can explore personal challenges, confront emotional roadblocks, and gain clarity. Whether you are navigating chronic anxiety that prevents your mind from shutting down, depression that turns everyday routines into overwhelming burdens, or trauma that your nervous system hasn't finished processing, our clinicians adapt evidence-based modalities to your unique pace and life story.",
    deliveryModes: ["telehealth", "in-person"],
    category: "core",
    targetAudience: "Adults seeking personalized growth, anxiety relief, trauma recovery, and emotional resilience.",
    bgImage: "/assets/services/individual-therapy-bg.webp",
    quote: "When everything takes more effort than it should, therapy gives you a compassionate space to set down what you've been carrying.",
    keyTopics: [
      "Chronic anxiety, racing thoughts, and sleep disturbance",
      "Depressive exhaustion and emotional disconnection",
      "Trauma and nervous system hyper-vigilance",
      "Grief, bereavement, and complex loss with no rigid timeline",
      "Life transitions, burnout, and establishing healthy boundaries",
      "Identity discovery and breaking multigenerational patterns"
    ],
    evidenceBasedApproaches: [
      "Cognitive Behavioral Therapy (CBT)",
      "Acceptance and Commitment Therapy (ACT)",
      "Trauma-Focused Psychotherapy",
      "Mindfulness-Based Stress Reduction",
      "Client-Centered Humanistic Counseling"
    ],
    format: "In-Person (Tyngsborough, MA) or Virtual Telehealth (MA & NH)",
    details: {
      whoItIsFor: [
        "Adults whose brains won't switch off before bed, trapped in cycles of anticipation.",
        "Anyone who feels that slowing down isn't allowed, leading to chronic physical and emotional exhaustion.",
        "Individuals navigating traumatic experiences that their bodies continue to react to.",
        "Those moving through grief with no expectation of rushing through mourning."
      ],
      whatToExpect: [
        "A confidential, judgment-free clinical relationship where you lead the agenda.",
        "Practical tools to interrupt physiological panic and racing worry loops.",
        "Pacing that respects your boundaries—we never force you to recount trauma before you feel grounded.",
        "Direct integration with simple self-care routines that hold up in daily life."
      ],
      commonConcerns: [
        {
          title: "Anxiety & Racing Thoughts",
          description:
            "The constant inner monologue that won't quiet down, waking up in the middle of the night anticipating the next day, and a persistent physical knot in your chest. Therapy helps you identify subconscious triggers and regulate your autonomic nervous system."
        },
        {
          title: "Depression & Low Vitality",
          description:
            "When even routine tasks demand immense effort, and hobbies or relationships that once mattered lose their color. You don't have to wait until you reach a breaking point to deserve clinical support."
        },
        {
          title: "Trauma & Lingering Impact",
          description:
            "Whether from a single catastrophic incident or years of invalidating relationships that left you feeling chronically guarded. We utilize gentle, trauma-informed interventions that help you regain control."
        }
      ]
    }
  },
  {
    id: "couples-therapy",
    slug: "couples-therapy",
    title: "Couple Therapy",
    shortDescription:
      "For the argument you keep having and can't seem to finish. Rebuild trust, resolve communication loops, and feel like a team again.",
    fullDescription:
      "It is rarely one catastrophic blowup that leads couples into therapy—it is usually the argument you've had a dozen times before that never seems to finish, leaving both partners emotionally drained and distant. Our couple therapy approaches the relationship as the client, helping partners dismantle defensive communication patterns, process breaches of trust, and restore intimate partnership.",
    deliveryModes: ["telehealth", "in-person"],
    category: "core",
    targetAudience: "Married, dating, partnered, premarital, and LGBTQ+ couples navigating conflict, emotional drift, or trust rebuilds.",
    bgImage: "/assets/services/couples-therapy-bg.webp",
    quote: "When couples are worn down by repeating the same argument, we help you step out of the cycle and rediscover each other as allies.",
    keyTopics: [
      "De-escalating recurring conflict and defensive cycles",
      "Infidelity recovery through honest processing & earned trust",
      "Rebuilding emotional intimacy and physical connection",
      "Non-defensive, collaborative communication skills",
      "Premarital counseling and foundational alignment",
      "Navigating parenting transitions, finances, and blended family dynamics",
      "LGBTQ+ relationship affirming care and partnership dynamics"
    ],
    evidenceBasedApproaches: [
      "Systemic Relational Therapy",
      "Emotion-Focused Couples Strategies",
      "Attachment-Informed Communication Models",
      "Two-Track Infidelity Repair Protocol"
    ],
    format: "In-Person (Tyngsborough, MA) or Virtual Telehealth (MA & NH)",
    details: {
      whoItIsFor: [
        "Couples stuck in the same repeating argument where neither feels heard.",
        "Partners recovering from an affair or emotional betrayal seeking structured reconciliation.",
        "Couples considering separation who want an objective, respectful space to determine next steps.",
        "Dating, engaged, and long-term partners wanting to deepen connection."
      ],
      whatToExpect: [
        "A neutral, objective clinician who never takes sides or plays referee.",
        "Direct focus on communication mechanics—how tone, defensiveness, and withdrawal perpetuate fights.",
        "For infidelity work, a clear two-track approach: processing the emotional impact honestly without minimizing, while building verifiable trust.",
        "Homework and practical dialogue exercises to practice between sessions."
      ]
    }
  },
  {
    id: "court-probation-evaluations",
    slug: "court-probation-evaluations",
    title: "Court, Probation, RMV/DMV Evaluations",
    shortDescription:
      "Certified diagnostic evaluations for court mandates, probation conditions, and RMV/DMV license reinstatement.",
    fullDescription:
      "When legal proceedings, probation requirements, or registry hearings necessitate a certified, objective clinical assessment, Transcending Chaos Counseling provides thorough diagnostic evaluations. With credentials including Pre-Licensed Board Certified Professional Counselor and Certified Forensic Counselor (CFC), our team conducts rigorous, impartial assessments and delivers professional clinical documentation for mental health, addiction, recidivism, and driving evaluations.",
    deliveryModes: ["in-person"],
    category: "evaluations",
    targetAudience: "Individuals requiring official mental health, addiction, recidivism, or driving reinstatement assessments.",
    bgImage: "/assets/services/counseling-space.jpg",
    quote: "Objective, certified forensic documentation delivered with clinical integrity and timeliness.",
    subservices: [
      "Mental Health Evaluations",
      "Addiction Evaluations",
      "Recidivism-Related Risk Evaluations",
      "RMV / DMV Driving-Related Evaluations",
      "Probation & Court-Mandated Clinical Documentation"
    ],
    keyTopics: [
      "Diagnostic mental health clinical evaluations",
      "Comprehensive addiction and chemical dependency assessments",
      "Recidivism risk factor evaluations",
      "RMV / DMV driving-related evaluations and license reinstatement reports",
      "Compliance documentation and multidisciplinary reporting"
    ],
    evidenceBasedApproaches: [
      "Standardized Clinical Diagnostic Assessments",
      "Certified Forensic Interviewing Protocols",
      "Objective Risk & Recidivism Assessment",
      "Strict Evidentiary Clinical Documentation"
    ],
    format: "In-Person (Tyngsborough, MA) by Appointment"
  },
  {
    id: "first-responders",
    slug: "first-responders",
    title: "First Responders",
    shortDescription:
      "Culturally competent mental health support for police, firefighters, EMTs, dispatchers, and healthcare workers.",
    fullDescription:
      "First responders routinely absorb secondary trauma, critical incident stress, hyper-vigilance, and cumulative burnout that few outside the uniform can comprehend. Our clinicians possess extensive direct experience working with emergency services, providing a culturally competent space where you can speak candidly without judgment or career stigma.",
    deliveryModes: ["telehealth", "in-person"],
    category: "specialized",
    targetAudience: "Police officers, firefighters, EMTs, paramedics, 911 dispatchers, corrections personnel, and emergency medical providers.",
    bgImage: "/assets/hero/hero-sanctuary.jpg",
    quote: "A confidential haven for those who protect and serve our communities.",
    keyTopics: [
      "Critical incident stress management & debriefing",
      "Cumulative shift trauma and operational stress",
      "Hyper-vigilance and transition back to home life",
      "Substance use coping mechanisms and prevention",
      "Sleep disruption and autonomic nervous system regulation",
      "Relationship preservation under high-stakes career demands"
    ],
    evidenceBasedApproaches: [
      "First Responder Culturally Competent Care",
      "Trauma-Informed CBT",
      "Somatic Grounding & Stress De-escalation",
      "Confidential Peer-Informed Clinical Support"
    ],
    format: "In-Person (Tyngsborough, MA) or Virtual Telehealth (MA & NH)"
  },
  {
    id: "veterans",
    slug: "veterans",
    title: "Veterans",
    shortDescription:
      "Compassionate mental health care for veterans navigating civilian adjustment, combat trauma, and moral injury.",
    fullDescription:
      "Military service demands a resilience that often leaves lasting emotional imprints. Transitioning back into civilian routines can bring profound disorientation, isolation, loss of purpose, and unresolved combat or operational stress. We honor your service by delivering focused, compassionate therapy designed to restore balance and purpose.",
    deliveryModes: ["telehealth", "in-person"],
    category: "specialized",
    targetAudience: "Veterans of all military branches, active reservists, National Guard members, and their immediate families.",
    bgImage: "/assets/services/serene-nature.jpg",
    quote: "Honoring your service with grounded, evidence-based trauma and transition care.",
    keyTopics: [
      "Civilian reintegration and identity transition",
      "Combat and non-combat trauma recovery",
      "Moral injury and emotional reconciliation",
      "Overcoming isolation and rebuilding community",
      "Co-occurring chronic pain, insomnia, and anxiety",
      "Family dynamic shifts following military service"
    ],
    evidenceBasedApproaches: [
      "Trauma-Focused Cognitive Therapy",
      "Acceptance and Commitment Therapy (ACT)",
      "Strength-Based Reintegration Counseling",
      "Mindfulness & Emotional Self-Regulation"
    ],
    format: "In-Person (Tyngsborough, MA) or Virtual Telehealth (MA & NH)"
  },
  {
    id: "addiction-treatment",
    slug: "addiction",
    title: "Addiction Treatment",
    shortDescription:
      "Alcohol, Drug, Gambling, Video Game, Sex, and Other Addictions — specialized outpatient recovery and family support.",
    fullDescription:
      "Addiction impacts every dimension of a person's life and ripples throughout their family system. Our specialized Licensed Alcohol and Drug Counselors (LADC-1, MLADC, LADC-2) provide compassionate, evidence-based care across substance and behavioral addictions. We meet you where you are at, formulating practical harm-reduction or abstinence treatment plans tailored to sustainable, long-term recovery.",
    deliveryModes: ["telehealth", "in-person"],
    category: "specialized",
    targetAudience: "Individuals struggling with substance dependency, behavioral compulsions, and families impacted by addiction.",
    bgImage: "/assets/services/counseling-space.jpg",
    quote: "Meeting you where you are with clinical expertise, radical empathy, and zero judgment.",
    subservices: [
      "Alcohol Addiction & Recovery",
      "Drug & Chemical Substance Use",
      "Gambling & Betting Compulsions",
      "Video Game & Digital Media Addiction",
      "Sex & Intimacy Behavioral Compulsions",
      "Other Compulsive & Addictive Behaviors"
    ],
    keyTopics: [
      "Alcohol and drug dependence",
      "Gambling addiction and compulsive behavior",
      "Video game and digital behavioral addictions",
      "Sexual compulsivity and relationship impacts",
      "Dual diagnosis (co-occurring mental health & substance use)",
      "Relapse prevention, triggers, and case management",
      "Counseling for family members affected by a loved one's addiction"
    ],
    evidenceBasedApproaches: [
      "Relapse Prevention Therapy (RPT)",
      "Motivational Interviewing (MI)",
      "Cognitive Behavioral Therapy for Substance Use",
      "Harm Reduction & Dual-Diagnosis Protocols"
    ],
    format: "In-Person (Tyngsborough, MA) or Virtual Telehealth (MA & NH)"
  },
  {
    id: "mental-health-counseling",
    slug: "mental-health",
    title: "Mental Health",
    shortDescription:
      "Depression, OCD, PTSD, ADHD, Anxiety, BPD, Bipolar, Schizophrenia, Personality Disorders, and many others.",
    fullDescription:
      "When anxiety, depressive episodes, intrusive thoughts, or disruptive mood patterns overwhelm daily functioning, our team provides grounded, clinically rigorous interventions. We address symptoms with deep clinical understanding, validating your lived experience while equipping you with cognitive tools and emotional stability.",
    deliveryModes: ["telehealth", "in-person"],
    category: "specialized",
    targetAudience: "Individuals managing mild to severe mental health symptoms, chronic distress, or diagnosed psychiatric conditions.",
    bgImage: "/assets/services/serene-nature.jpg",
    quote: "Clinically rigorous care that treats you as a whole person, not a diagnostic code.",
    subservices: [
      "Depression & Major Depressive Disorder",
      "Obsessive-Compulsive Disorder (OCD)",
      "Post-Traumatic Stress Disorder (PTSD) & Complex Trauma",
      "Attention Deficit Hyperactivity Disorder (ADHD)",
      "Anxiety & Panic Spectrum Disorders",
      "Borderline Personality Disorder (BPD)",
      "Bipolar Disorder (I & II)",
      "Schizophrenia & Psychotic Spectrum Outpatient Support",
      "Personality Disorders & Emotional Dysregulation"
    ],
    keyTopics: [
      "Depression and persistent depressive disorders",
      "Anxiety disorders, panic attacks, and social anxiety",
      "Obsessive-Compulsive Disorder (OCD) and intrusive thoughts",
      "Post-Traumatic Stress Disorder (PTSD) & acute trauma",
      "Attention Deficit Hyperactivity Disorder (ADHD)",
      "Borderline Personality Disorder (BPD) & emotional dysregulation",
      "Bipolar Disorder and mood stabilization support",
      "Schizophrenia and psychotic spectrum support in outpatient care",
      "Personality disorders and interpersonal distress"
    ],
    evidenceBasedApproaches: [
      "Dialectical Behavioral Therapy (DBT) skills",
      "Cognitive Behavioral Therapy (CBT)",
      "Trauma-Focused Clinical Modalities",
      "Psychodynamic Insight & Grounding"
    ],
    format: "In-Person (Tyngsborough, MA) or Virtual Telehealth (MA & NH)"
  },
  {
    id: "group-therapy",
    slug: "group-therapy",
    title: "Coming Soon! Group Therapy (Early 2027)",
    shortDescription:
      "Mental Health Group Therapy, Addiction Group Therapy, and Gambling Group Therapy planned for early 2027.",
    fullDescription:
      "Transcending Chaos Counseling is actively expanding our continuum of community care. Beginning in early 2027, we plan to launch therapist-facilitated group therapy cohorts providing community connection, shared insight, and structured therapeutic curricula. These planned cohorts will include Mental Health Group Therapy, Addiction Group Therapy, and specialized Gambling Group Therapy.",
    deliveryModes: ["telehealth", "in-person"],
    category: "future",
    targetAudience: "Individuals seeking collaborative group support and peer connection under clinical guidance.",
    bgImage: "/assets/hero/hero-sanctuary.jpg",
    quote: "Connecting with peers on shared journeys of healing, accountability, and self-mastery.",
    subservices: [
      "Mental Health Group Therapy (Depression, Anxiety, Mood Resilience)",
      "Addiction Group Therapy (Recovery Maintenance, Peer Accountability)",
      "Gambling Group Therapy (Compulsive Behavior Interruption)"
    ],
    keyTopics: [
      "Mental Health Group Therapy (Depression, Anxiety, Mood Resilience)",
      "Addiction Group Therapy (Recovery Maintenance, Peer Accountability)",
      "Gambling Group Therapy (Compulsive Behavior Interruption)",
      "Shared vulnerability and non-judgmental community space"
    ],
    evidenceBasedApproaches: [
      "Curriculum-Based Cognitive Group Therapy",
      "Peer-Led Clinical Process Groups",
      "Psychoeducational Modules"
    ],
    format: "Planned for Early 2027 (Join Inquiry Waitlist)",
    isComingSoon: true,
    expectedDate: "Early 2027"
  }
];
