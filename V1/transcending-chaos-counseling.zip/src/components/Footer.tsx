import React from "react";
import { BrandLogo } from "./BrandLogo";
import { useRouter } from "../context/RouterContext";
import { SITE_INFO } from "../data/siteInfo";
import { PROVIDERS } from "../data/providers";
import { SERVICES } from "../data/services";
import {
  Phone,
  Mail,
  Printer,
  MapPin,
  ArrowUpRight,
  Shield,
  FileText,
  HeartHandshake,
} from "lucide-react";
import { FadeIn, StaggerContainer, StaggerItem } from "./motion/MotionSystem";

export const Footer: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <footer className="bg-gradient-to-b from-[#0B2440] via-[#091C31] to-[#071626] text-slate-300 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Practice Directory & Links 4-column layout */}
        <StaggerContainer
          staggerDelay={0.08}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-slate-800/80"
        >
          {/* Column 1: Practice identity & philosophy (4 cols) */}
          <div className="lg:col-span-4 flex flex-col gap-5">
            <BrandLogo variant="light" showSubtitle />
            <p className="text-sm text-slate-300 leading-relaxed max-w-sm">
              Rooted in evidence-based modalities and compassionate, client-centered care. Helping individuals, couples, first responders, and veterans transcend life's unpredictability and discover their true resilience.
            </p>

            <div className="flex flex-col gap-2 pt-1 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F5BD00]" />
                <span>In-Person Care: Tyngsborough, Massachusetts</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F5BD00]" />
                <span>Virtual Telehealth: Massachusetts & New Hampshire</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-3">
              <a
                href={SITE_INFO.portalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 bg-[#174F86] hover:bg-[#1f63a3] text-white rounded-md transition-colors"
              >
                <span>SimplePractice Portal</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
              <a
                href={SITE_INFO.psychologyTodayUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md transition-colors"
              >
                <span>Psychology Today</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
              <a
                href={SITE_INFO.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md transition-colors"
              >
                <span>LinkedIn</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Column 2: Clinical Services (3 cols) */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <h3 className="font-heading font-semibold text-white text-sm tracking-wide uppercase">
              Clinical Services
            </h3>
            <ul className="flex flex-col gap-2.5 text-sm">
              {SERVICES.map((s) => (
                <li key={s.id}>
                  <a
                    href={`#/services/${s.slug}`}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate(`/services/${s.slug}`);
                    }}
                    className="text-slate-300 hover:text-[#F5BD00] transition-colors inline-flex items-center gap-1.5"
                  >
                    <span>{s.title}</span>
                    {s.isComingSoon && (
                      <span className="text-[10px] text-[#F5BD00] font-mono">2027</span>
                    )}
                  </a>
                </li>
              ))}
              <li className="pt-1">
                <a
                  href="#/services"
                  onClick={(e) => {
                    e.preventDefault();
                    navigate("/services");
                  }}
                  className="text-xs font-semibold text-[#F5BD00] hover:text-white transition-colors"
                >
                  View All Our Services →
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Clinical Providers (2 cols) */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            <h3 className="font-heading font-semibold text-white text-sm tracking-wide uppercase">
              Our Providers
            </h3>
            <ul className="flex flex-col gap-3 text-sm">
              {PROVIDERS.map((p) => (
                <li key={p.id}>
                  <a
                    href={`#/providers/${p.slug}`}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate(`/providers/${p.slug}`);
                    }}
                    className="group block"
                  >
                    <span className="text-white group-hover:text-[#F5BD00] font-medium transition-colors block">
                      {p.name}
                    </span>
                    <span className="text-xs text-slate-400 block">{p.credentials}</span>
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <a
                  href="#/schedule"
                  onClick={(e) => {
                    e.preventDefault();
                    navigate("/schedule");
                  }}
                  className="text-xs font-semibold text-[#F5BD00] hover:text-white transition-colors"
                >
                  Schedule Appointment →
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact & Locations (3 cols) */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <h3 className="font-heading font-semibold text-white text-sm tracking-wide uppercase">
              Contact & Locations
            </h3>

            <div className="flex flex-col gap-3 text-sm">
              <a
                href={`tel:${SITE_INFO.phoneRaw}`}
                className="flex items-start gap-2.5 text-slate-300 hover:text-white transition-colors"
              >
                <Phone className="w-4 h-4 text-[#F5BD00] shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs text-slate-400 block">Phone</span>
                  <span className="font-medium text-white">{SITE_INFO.phone}</span>
                </div>
              </a>

              <div className="flex items-start gap-2.5 text-slate-300">
                <Printer className="w-4 h-4 text-[#F5BD00] shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs text-slate-400 block">Confidential Fax</span>
                  <span>{SITE_INFO.fax}</span>
                </div>
              </div>

              <a
                href={`mailto:${SITE_INFO.email}`}
                className="flex items-start gap-2.5 text-slate-300 hover:text-white transition-colors"
              >
                <Mail className="w-4 h-4 text-[#F5BD00] shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs text-slate-400 block">Clinical Inquiries</span>
                  <span>{SITE_INFO.email}</span>
                </div>
              </a>

              <div className="flex items-start gap-2.5 text-slate-300 pt-2 border-t border-slate-800">
                <MapPin className="w-4 h-4 text-[#F5BD00] shrink-0 mt-0.5" />
                <div className="text-xs leading-relaxed">
                  <span className="font-semibold text-white block">Practice Address:</span>
                  <span>{SITE_INFO.practiceAddress.full}</span>
                  <span className="text-slate-400 block italic text-[11px] mt-0.5">
                    (In-person sessions by appointment)
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-2.5 text-slate-300">
                <FileText className="w-4 h-4 text-[#F5BD00] shrink-0 mt-0.5" />
                <div className="text-xs leading-relaxed">
                  <span className="font-semibold text-white block">Mailing Address:</span>
                  <span>{SITE_INFO.mailingAddress.full}</span>
                  <span className="text-slate-400 block italic text-[11px] mt-0.5">
                    (Correspondence & billing only)
                  </span>
                </div>
              </div>
            </div>
          </div>
        </StaggerContainer>

        {/* Crisis Warning Banner */}
        <FadeIn direction="up" distance={16} delay={0.2}>
          <div className="my-8 p-4 bg-slate-900/90 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5 text-slate-300">
              <HeartHandshake className="w-5 h-5 text-[#F5BD00] shrink-0" />
              <span>
                <strong>Emergency & Crisis Support:</strong> If you or someone you know is experiencing a mental health emergency, please dial <strong>911</strong> or call/text the National Suicide & Crisis Lifeline at <strong>988</strong> (available 24/7).
              </span>
            </div>
            <span className="text-slate-400 shrink-0 font-mono text-[11px]">
              Dial 988 · 24/7 Free & Confidential
            </span>
          </div>
        </FadeIn>

        {/* Bottom bar with legal & copyright */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400 text-center md:text-left">
          <div>
            © {new Date().getFullYear()} Transcending Chaos Counseling, LLC. All rights reserved.
          </div>

          <div className="flex flex-wrap items-center justify-center md:justify-end gap-x-4 gap-y-2 text-[11px] sm:text-xs">
            <a
              href="#/privacy"
              onClick={(e) => {
                e.preventDefault();
                navigate("/privacy");
              }}
              className="hover:text-white transition-colors"
            >
              Notice of Privacy Practices
            </a>
            <span className="text-slate-700 hidden sm:inline" aria-hidden="true">·</span>
            <a
              href="#/good-faith-estimate"
              onClick={(e) => {
                e.preventDefault();
                navigate("/good-faith-estimate");
              }}
              className="hover:text-white transition-colors"
            >
              Good Faith Estimate
            </a>
            <span className="text-slate-700 hidden sm:inline" aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => window.dispatchEvent(new CustomEvent("replay-intro"))}
              className="hover:text-[#F5BD00] transition-colors cursor-pointer inline-flex items-center gap-1"
              title="Replay the welcome logo animation"
            >
              <span>Replay Intro</span>
            </button>
            <span className="text-slate-700 hidden sm:inline" aria-hidden="true">·</span>
            <a
              href={SITE_INFO.portalSignInUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#F5BD00] transition-colors inline-flex items-center gap-1"
            >
              <span>Client Portal</span>
              <ArrowUpRight className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
