import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { RouterProvider, useRouter } from "./context/RouterContext";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { HomePage } from "./pages/HomePage";
import { ProvidersPage } from "./pages/ProvidersPage";
import { ProviderDetailPage } from "./pages/ProviderDetailPage";
import { ServicesPage } from "./pages/ServicesPage";
import { ServiceDetailPage } from "./pages/ServiceDetailPage";
import { SchedulePage } from "./pages/SchedulePage";
import { ContactPage } from "./pages/ContactPage";
import { PrivacyPolicyPage } from "./pages/PrivacyPolicyPage";
import { NoSurprisesActPage } from "./pages/NoSurprisesActPage";
import { NotFoundPage } from "./pages/NotFoundPage";

import { IntroLoader } from "./components/IntroLoader";

const AppContent: React.FC = () => {
  const { currentPath } = useRouter();
  const [showIntro, setShowIntro] = React.useState(true);

  // Allow replaying intro via custom event if triggered
  React.useEffect(() => {
    const handleReplay = () => setShowIntro(true);
    window.addEventListener("replay-intro", handleReplay);
    return () => window.removeEventListener("replay-intro", handleReplay);
  }, []);

  // Smooth scroll to top on path change
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [currentPath]);

  // Route matching logic
  const renderPage = () => {
    if (currentPath === "/" || currentPath === "") {
      return <HomePage />;
    }

    if (currentPath === "/providers") {
      return <ProvidersPage />;
    }

    if (currentPath.startsWith("/providers/")) {
      const slug = currentPath.replace("/providers/", "");
      return <ProviderDetailPage slug={slug} />;
    }

    if (currentPath === "/services") {
      return <ServicesPage />;
    }

    if (currentPath.startsWith("/services/")) {
      const slug = currentPath.replace("/services/", "");
      return <ServiceDetailPage slug={slug} />;
    }

    if (currentPath === "/schedule") {
      return <SchedulePage />;
    }

    if (currentPath === "/contact") {
      return <ContactPage />;
    }

    if (currentPath === "/privacy") {
      return <PrivacyPolicyPage />;
    }

    if (currentPath === "/good-faith-estimate" || currentPath === "/no-surprises-act") {
      return <NoSurprisesActPage />;
    }

    return <NotFoundPage />;
  };

  return (
    <>
      {showIntro && <IntroLoader onComplete={() => setShowIntro(false)} />}
      <div className="min-h-screen flex flex-col bg-white text-slate-800 antialiased selection:bg-[#174F86]/15 selection:text-[#174F86]">
        <Navbar />
      <main className="flex-grow overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPath}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
    </div>
    </>
  );
};

export default function App() {
  return (
    <RouterProvider>
      <AppContent />
    </RouterProvider>
  );
}
