import React from "react";
import { SITE_INFO } from "../data/siteInfo";
import { PROVIDERS } from "../data/providers";
import {
  Calendar,
  Lock,
  ArrowUpRight,
  HelpCircle,
  UserCheck,
} from "lucide-react";
import {
  FadeIn,
  TextReveal,
  StaggerContainer,
  StaggerItem,
} from "../components/motion/MotionSystem";

export const SchedulePage: React.FC = () => {
  return (
    <div className="flex flex-col w-full bg-white">
      {/* Hero Header with unified color gradient overlay & blended background (Inspired by Trust Therapeutics) */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#07172B] via-[#0B2440] to-[#103761] text-white py-14 sm:py-20">
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {/* Subtle textured background image with clear visibility */}
          <img
            src="/assets/hero/hero-sanctuary.jpg"
            alt=""
            aria-hidden="true"
            className="w-full h-full object-cover object-center opacity-70 filter brightness-95 contrast-105"
            referrerPolicy="no-referrer"
          />
          {/* Full-bleed rich brand color gradient overlay across the entire width */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#071626]/85 via-[#0B2440]/70 to-[#103761]/55" />
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#F5BD00]/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#174F86]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#F5BD00] mb-3 inline-block">
                APPOINTMENT BOOKING & CLIENT PORTAL
              </span>
            </FadeIn>

            <TextReveal
              tag="h1"
              text="Schedule Your Appointment"
              className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-tight mb-4"
            />

            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base sm:text-lg text-slate-200 leading-relaxed mb-8">
                We manage all appointment scheduling and secure client communications through our official, HIPAA-compliant SimplePractice portal. Book your first visit, manage recurring sessions, or sign in to your client account.
              </p>
            </FadeIn>

            {/* Two Primary Portal Launch Actions */}
            <FadeIn direction="up" distance={20} delay={0.25}>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <a
                  href={SITE_INFO.portalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2.5 px-8 py-4 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl shadow-md hover:shadow-xl hover:-translate-y-0.5 text-center"
                >
                  <Calendar className="w-4 h-4 text-[#0B2440]" />
                  <span>Launch Appointment Booking Portal</span>
                  <ArrowUpRight className="w-4 h-4" />
                </a>

                <a
                  href={SITE_INFO.portalSignInUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2.5 px-8 py-4 text-xs font-bold uppercase tracking-wider text-white bg-white/10 hover:bg-white/20 active:scale-98 transition-all rounded-xl text-center border border-white/20 backdrop-blur-md hover:-translate-y-0.5"
                >
                  <UserCheck className="w-4 h-4 text-[#F5BD00]" />
                  <span>Existing Client Sign-In</span>
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </FadeIn>

            <FadeIn direction="up" distance={16} delay={0.35} className="mt-6 flex items-center gap-2 text-xs text-slate-300">
              <Lock className="w-3.5 h-3.5 text-[#F5BD00]" />
              <span>
                Encrypted with 256-bit bank-grade HIPAA security via SimplePractice.
              </span>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 4-Step Process Explanation (Seamlessly blended, no harsh top border) */}
      <section className="relative py-12 sm:py-16 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2 inline-block">
                SIMPLE & CONFIDENTIAL
              </span>
            </FadeIn>
            <TextReveal
              tag="h2"
              text="How Scheduling Works"
              className="font-heading font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#0B2440] tracking-tight"
            />
            <FadeIn direction="up" distance={16} delay={0.15}>
              <p className="text-sm sm:text-base text-slate-600 mt-2">
                A transparent, hassle-free path to starting care without endless telephone tag.
              </p>
            </FadeIn>
          </div>

          <StaggerContainer
            staggerDelay={0.08}
            className="grid grid-cols-1 md:grid-cols-4 gap-6"
          >
            {[
              {
                step: "01",
                title: "Choose Your Clinician",
                desc: "Review provider bios and choose Cassandra, Erica, or Deb based on your clinical goals and preferences.",
              },
              {
                step: "02",
                title: "Select Session Format",
                desc: "Choose between in-person therapy at our Tyngsborough, MA office or virtual telehealth across MA & NH.",
              },
              {
                step: "03",
                title: "Pick Your Date & Time",
                desc: "Browse live calendar availability and reserve a session time that accommodates your schedule.",
              },
              {
                step: "04",
                title: "Complete Intake Online",
                desc: "Receive encrypted digital intake documents via SimplePractice to complete privately before your first visit.",
              },
            ].map((st) => (
              <StaggerItem
                key={st.step}
                direction="up"
                distance={20}
                className="p-7 rounded-2xl bg-white/90 backdrop-blur-xs border border-slate-100/90 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <span className="text-2xl font-extrabold text-[#174F86]/30 font-mono block mb-3">
                    {st.step}
                  </span>
                  <h3 className="font-heading font-bold text-base text-[#0B2440] mb-2">
                    {st.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{st.desc}</p>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* Direct Clinician Booking Selection (Seamless gradient blend) */}
      <section className="relative py-14 sm:py-20 bg-gradient-to-b from-white via-[#F6F8FC] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2 inline-block">
                DIRECT PROVIDER BOOKING
              </span>
            </FadeIn>
            <TextReveal
              tag="h2"
              text="Select a Clinician to Book"
              className="font-heading font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#0B2440] tracking-tight"
            />
            <FadeIn direction="up" distance={16} delay={0.15}>
              <p className="text-sm sm:text-base text-slate-600 mt-2">
                All three clinicians are currently accepting new clients for in-person and telehealth appointments.
              </p>
            </FadeIn>
          </div>

          <StaggerContainer
            staggerDelay={0.1}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto"
          >
            {PROVIDERS.map((provider) => (
              <StaggerItem
                key={provider.id}
                direction="up"
                distance={24}
                className="bg-white/95 backdrop-blur-xs rounded-2xl p-5 sm:p-7 border border-slate-100/90 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between w-full max-w-full overflow-hidden"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-3.5 mb-4 min-w-0">
                    <img
                      src={provider.image}
                      alt={provider.name}
                      className="w-14 h-14 rounded-full object-cover border border-slate-200 shadow-xs shrink-0"
                    />
                    <div className="min-w-0">
                      <h3 className="font-heading font-bold text-base text-[#0B2440] break-words">
                        {provider.name}
                      </h3>
                      <p className="text-xs font-semibold text-[#174F86] break-words">
                        {provider.credentials}
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed mb-4 line-clamp-3 break-words">
                    {provider.shortBio}
                  </p>

                  <div className="text-[11px] text-slate-500 mb-6 space-y-1 min-w-0">
                    <div className="break-words">
                      <strong>Experience:</strong> {provider.experience}
                    </div>
                    <div className="break-words">
                      <strong>Focus:</strong> {provider.clientFocus.slice(0, 2).join(", ")}
                    </div>
                  </div>
                </div>

                <a
                  href={SITE_INFO.portalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-1.5 py-3 px-4 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl text-center shadow-xs hover:shadow-md min-h-[42px]"
                >
                  <span>Book with {provider.name.split(" ")[0]}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
                </a>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* Scheduling FAQs (Seamless blend into pure white) */}
      <section className="relative py-14 sm:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#174F86] mb-2 inline-block">
                QUESTIONS & ANSWERS
              </span>
            </FadeIn>
            <TextReveal
              tag="h2"
              text="Frequently Asked Scheduling Questions"
              className="font-heading font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#0B2440] tracking-tight"
            />
          </div>

          <StaggerContainer staggerDelay={0.08} className="space-y-4">
            {[
              {
                q: "How does the SimplePractice portal work?",
                a: "SimplePractice is a top-tier healthcare platform used for self-scheduling, electronic documentation, secure credit card processing, and encrypted telehealth video visits. When you click 'Launch Appointment Booking Portal', you will be guided through selecting your service, date, and provider.",
              },
              {
                q: "What states do you serve for virtual telehealth?",
                a: "Our clinicians are actively licensed in both Massachusetts and New Hampshire. You must be physically present in Massachusetts or New Hampshire at the time of your virtual telehealth appointment.",
              },
              {
                q: "Where is the physical office located for in-person therapy?",
                a: "Our clinical office is located at 1 Bridgeview Circle, Suite 5, Tyngsborough, MA 01879-2053, with ample free parking and quiet, private consultation suites.",
              },
              {
                q: "Can existing clients change or reschedule sessions?",
                a: "Yes. Existing clients can sign in to the client portal at https://transcendingchaos.clientsecure.me/sign-in to view upcoming appointments, request time changes, or message their clinician directly.",
              },
              {
                q: "What is your cancellation and rescheduling policy?",
                a: "We require 24 hours advance notice for cancellations or rescheduling to avoid late cancellation charges, allowing us to offer the reserved time slot to other clients in need.",
              },
            ].map((faq) => (
              <StaggerItem
                key={faq.q}
                direction="up"
                distance={16}
                className="p-6 rounded-2xl bg-[#F6F8FC]/90 hover:bg-[#EEF4FB] border border-slate-100/80 transition-colors"
              >
                <h3 className="font-heading font-bold text-base text-[#0B2440] mb-2 flex items-start gap-2.5">
                  <HelpCircle className="w-4 h-4 text-[#174F86] shrink-0 mt-1" />
                  <span>{faq.q}</span>
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed pl-6.5">
                  {faq.a}
                </p>
              </StaggerItem>
            ))}
          </StaggerContainer>

          <FadeIn direction="up" distance={16} delay={0.2} className="mt-12 text-center p-6 rounded-2xl bg-[#EAF2FA] text-slate-700 text-xs sm:text-sm">
            Have questions before booking? Contact us directly at{" "}
            <a href={`tel:${SITE_INFO.phoneRaw}`} className="font-bold text-[#174F86] underline">
              {SITE_INFO.phone}
            </a>{" "}
            or email{" "}
            <a href={`mailto:${SITE_INFO.email}`} className="font-bold text-[#174F86] underline">
              {SITE_INFO.email}
            </a>
            .
          </FadeIn>
        </div>
      </section>
    </div>
  );
};
