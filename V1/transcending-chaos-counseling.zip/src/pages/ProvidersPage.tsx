import React, { useState } from "react";
import { PROVIDERS } from "../data/providers";
import { ProviderCard } from "../components/ProviderCard";
import { CTASection } from "../components/CTASection";
import { Award, GraduationCap, HeartHandshake, CheckCircle } from "lucide-react";
import {
  FadeIn,
  TextReveal,
  StaggerContainer,
  StaggerItem,
} from "../components/motion/MotionSystem";

export const ProvidersPage: React.FC = () => {
  const [filterSpecialty, setFilterSpecialty] = useState<string>("all");

  const specialtiesList = [
    { id: "all", label: "All Clinicians" },
    { id: "addiction", label: "Addiction & Recovery" },
    { id: "couples", label: "Couples & Family" },
    { id: "first-responders", label: "First Responders & Veterans" },
    { id: "mental-health", label: "Mood & Trauma" },
  ];

  const filteredProviders = PROVIDERS.filter((p) => {
    if (filterSpecialty === "all") return true;
    if (filterSpecialty === "addiction") {
      return p.specialties.some((s) => s.toLowerCase().includes("addiction"));
    }
    if (filterSpecialty === "couples") {
      return p.specialties.some((s) => s.toLowerCase().includes("couple") || s.toLowerCase().includes("family"));
    }
    if (filterSpecialty === "first-responders") {
      return p.specialties.some(
        (s) => s.toLowerCase().includes("first responder") || s.toLowerCase().includes("veteran")
      );
    }
    if (filterSpecialty === "mental-health") {
      return p.specialties.some(
        (s) =>
          s.toLowerCase().includes("trauma") ||
          s.toLowerCase().includes("mood") ||
          s.toLowerCase().includes("dual diagnosis")
      );
    }
    return true;
  });

  return (
    <div className="flex flex-col w-full bg-white">
      {/* Header section with unified color gradient overlay & blended background (Inspired by Trust Therapeutics) */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#07172B] via-[#0B2440] to-[#103761] text-white py-14 sm:py-20">
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {/* Subtle textured background image with clear visibility */}
          <img
            src="/assets/hero/hero-sanctuary.jpg"
            alt=""
            aria-hidden="true"
            className="w-full h-full object-cover object-center opacity-70 filter brightness-95 contrast-105"
            referrerPolicy="no-referrer"
          />
          {/* Full-bleed rich brand color gradient overlay across the entire width */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#071626]/85 via-[#0B2440]/70 to-[#103761]/55" />
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#F5BD00]/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#174F86]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#F5BD00] mb-3 inline-block">
                OUR CLINICAL TEAM
              </span>
            </FadeIn>

            <TextReveal
              tag="h1"
              text="Meet Our Licensed Clinicians"
              className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-tight mb-4"
            />

            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base sm:text-lg text-slate-200 leading-relaxed mb-6">
                Our clinicians blend compassionate, client-centered care with advanced clinical training and decades of combined outpatient experience in addiction recovery, family systems, trauma, and mood disorders.
              </p>
            </FadeIn>

            <FadeIn direction="up" distance={16} delay={0.25}>
              <div className="flex flex-wrap items-center gap-6 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#F5BD00]" />
                  <span>Licensed in Massachusetts & New Hampshire</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#F5BD00]" />
                  <span>In-Person & Virtual Telehealth Available</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#F5BD00]" />
                  <span>Accepting New Clients via SimplePractice</span>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Directory Section with StaggerContainer */}
      <section className="relative py-12 sm:py-16 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Functional filter pills */}
          <FadeIn direction="down" distance={16} delay={0.1}>
            <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 sm:mb-10 no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mr-2 shrink-0">
                Filter By Specialty:
              </span>
              {specialtiesList.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setFilterSpecialty(item.id)}
                  className={`px-4 py-2 text-xs font-medium rounded-full transition-all duration-200 whitespace-nowrap shrink-0 ${
                    filterSpecialty === item.id
                      ? "bg-[#174F86] text-white shadow-md shadow-blue-900/15 font-semibold scale-102"
                      : "bg-white/80 border border-slate-200/60 text-slate-700 hover:bg-[#EAF2FA] hover:text-[#174F86]"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </FadeIn>

          {/* Providers Grid - Adaptive layout prevents empty column voids on laptop */}
          <StaggerContainer
            key={filterSpecialty}
            staggerDelay={0.1}
            initialDelay={0.05}
            className={`grid gap-8 ${
              filteredProviders.length === 1
                ? "grid-cols-1 max-w-xl mx-auto"
                : filteredProviders.length === 2
                ? "grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto"
                : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
            }`}
          >
            {filteredProviders.map((provider) => (
              <StaggerItem key={provider.id} direction="up" distance={24}>
                <ProviderCard provider={provider} />
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* Clinical Standards Banner (Seamless blend, no harsh border) */}
      <section className="relative py-14 sm:py-20 bg-gradient-to-b from-white via-[#F6F8FC] to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <StaggerContainer
            staggerDelay={0.1}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            <StaggerItem direction="up" distance={24}>
              <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 transition-all duration-300 h-full">
                <div className="w-12 h-12 rounded-xl bg-[#EAF2FA] text-[#174F86] flex items-center justify-center mb-5 shadow-xs">
                  <Award className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-2">
                  Decades of Outpatient Practice
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Our clinicians hold extensive outpatient experience spanning 14+ and 15+ years in healthcare systems, outpatient clinics, forensic settings, and addiction rehabilitation.
                </p>
              </div>
            </StaggerItem>

            <StaggerItem direction="up" distance={24}>
              <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 transition-all duration-300 h-full">
                <div className="w-12 h-12 rounded-xl bg-[#EAF2FA] text-[#174F86] flex items-center justify-center mb-5 shadow-xs">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-2">
                  Advanced Degrees & Specialized Licenses
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Holders of Master of Arts in Marriage and Family Therapy, MBA in Healthcare Administration, Master's in Forensic Psychology, and specialized state licensure (LMFT, LADC-1, MLADC, LADC-2, BCPC, CFC).
                </p>
              </div>
            </StaggerItem>

            <StaggerItem direction="up" distance={24}>
              <div className="bg-white/90 backdrop-blur-xs p-8 rounded-2xl border border-slate-100/90 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 hover:-translate-y-1 transition-all duration-300 h-full">
                <div className="w-12 h-12 rounded-xl bg-[#EAF2FA] text-[#174F86] flex items-center justify-center mb-5 shadow-xs">
                  <HeartHandshake className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#0B2440] mb-2">
                  Client-Centered Human Connection
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  We believe in the power of connection by creating a safe non-judgmental space where clients can build a more fulfilling life and transcend chaotic seasons.
                </p>
              </div>
            </StaggerItem>
          </StaggerContainer>
        </div>
      </section>

      <CTASection
        title="Ready to Begin Your Care?"
        description="Select your clinician and view available appointment slots directly through our encrypted SimplePractice portal."
      />
    </div>
  );
};
