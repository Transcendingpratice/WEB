export interface ContactInfo {
  businessName: string;
  tagline: string;
  heroHeadline: string;
  heroDescription: string;
  phone: string;
  phoneRaw: string;
  fax: string;
  faxRaw: string;
  email: string;
  practiceAddress: {
    street: string;
    suite: string;
    city: string;
    state: string;
    zip: string;
    full: string;
    note: string;
  };
  mailingAddress: {
    street: string;
    suite: string;
    city: string;
    state: string;
    zip: string;
    full: string;
    note: string;
  };
  portalUrl: string;
  portalSignInUrl: string;
  psychologyTodayUrl: string;
  linkedinUrl: string;
  officialWebsite: string;
  serviceAreas: string[];
}

export const SITE_INFO: ContactInfo = {
  businessName: "Transcending Chaos Counseling",
  tagline: "Therapeutic Excellence, Thoughtfully Delivered",
  heroHeadline: "Go Beyond The Range of Unpredictability.",
  heroDescription:
    "Providing the ability to master one's mind, remain centered, and render ourselves untouchable by life's destructive influence. To transcend through the chaos and go beyond our comfort zones to help discover our true potential.",
  phone: "978.447.3404",
  phoneRaw: "+19784473404",
  fax: "978.396.4384",
  faxRaw: "+19783964384",
  email: "Admin@TranscendingChaos.org",
  practiceAddress: {
    street: "1 Bridgeview Circle",
    suite: "Suite 5",
    city: "Tyngsborough",
    state: "MA",
    zip: "01879-2053",
    full: "1 Bridgeview Circle, Suite 5, Tyngsborough, MA 01879-2053",
    note: "In-Person Clinical Sessions & Appointments",
  },
  mailingAddress: {
    street: "265 Chelmsford St.",
    suite: "Suite 7",
    city: "Chelmsford",
    state: "MA",
    zip: "01824-2665",
    full: "265 Chelmsford St., Suite 7, Chelmsford, MA 01824-2665",
    note: "Official Mail & Billing Correspondence Only",
  },
  portalUrl: "https://transcendingchaos.clientsecure.me/",
  portalSignInUrl: "https://transcendingchaos.clientsecure.me/sign-in",
  psychologyTodayUrl:
    "https://www.psychologytoday.com/us/therapists/transcending-chaos-counseling-tyngsborough-ma/1769379",
  linkedinUrl: "https://www.linkedin.com/company/transcending-chaos-counseling",
  officialWebsite: "https://www.transcendingchaos.org/",
  serviceAreas: ["Tyngsborough, MA (In-Person)", "Massachusetts (Virtual Telehealth)", "New Hampshire (Virtual Telehealth)"],
};
