import React from "react";
import { motion } from "motion/react";
import { Provider } from "../data/providers";
import { useRouter } from "../context/RouterContext";
import { SITE_INFO } from "../data/siteInfo";
import { User, ArrowUpRight, Award, CheckCircle, ArrowRight } from "lucide-react";

interface ProviderCardProps {
  provider: Provider;
  featured?: boolean;
  variant?: "vertical" | "horizontal";
  className?: string;
}

export const ProviderCard: React.FC<ProviderCardProps> = ({
  provider,
  featured = false,
  variant = "vertical",
  className = "",
}) => {
  const { navigate } = useRouter();

  if (variant === "horizontal") {
    return (
      <motion.article
        whileHover={{ y: -3, transition: { duration: 0.2, ease: [0.16, 1, 0.3, 1] } }}
        className={`group bg-white rounded-2xl border border-slate-200/80 hover:border-[#174F86]/35 p-4 sm:p-5 md:p-6 transition-all duration-300 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 w-full max-w-full overflow-hidden ${
          featured ? "ring-1 ring-[#174F86]/20 bg-gradient-to-r from-white via-white to-[#F8FAFD]" : ""
        } ${className}`}
      >
        {/* Small Clinician Photo */}
        <div className="relative w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-2xl overflow-hidden shrink-0 bg-[#F6F8FC] border border-slate-100 shadow-xs">
          <img
            src={provider.image}
            alt={`${provider.name}, ${provider.credentials}`}
            className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
            referrerPolicy="no-referrer"
          />
          {/* Status dot */}
          <span
            className="absolute top-1.5 right-1.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white shadow-xs"
            title="Accepting New Clients"
          />
        </div>

        {/* Short Designed Description & Credentials */}
        <div className="flex-grow text-center sm:text-left min-w-0 w-full overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2.5 mb-1.5 min-w-0">
            <h3 className="font-heading font-bold text-base sm:text-lg md:text-xl text-[#0B2440] group-hover:text-[#174F86] transition-colors leading-tight break-words">
              {provider.name}
            </h3>
            <span className="text-xs font-semibold text-[#174F86] tracking-wide break-words">
              {provider.credentials}
            </span>
          </div>

          <p className="text-xs text-slate-500 font-medium mb-1.5 break-words leading-relaxed">
            {provider.title} · <span className="text-[#174F86] font-semibold">{provider.experience}</span>
          </p>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-3 sm:line-clamp-2 break-words">
            {provider.shortBio}
          </p>

          <div className="mt-2.5 flex flex-wrap items-center justify-center sm:justify-start gap-1.5 text-[11px] text-slate-500 min-w-0">
            <span className="font-medium text-slate-400 uppercase tracking-wider text-[10px] shrink-0">Specialties:</span>
            <span className="text-slate-600 break-words leading-tight">
              {provider.specialties.slice(0, 3).join(" · ")}
            </span>
          </div>
        </div>

        {/* Action Buttons: View Profile & Book Visit */}
        <div className="shrink-0 flex flex-col gap-2 w-full sm:w-auto items-stretch sm:items-end pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-100">
          <button
            type="button"
            onClick={() => navigate(`/providers/${provider.slug}`)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl shadow-xs hover:shadow-md text-center cursor-pointer min-h-[42px]"
          >
            <User className="w-3.5 h-3.5 shrink-0" />
            <span>View Profile</span>
            <ArrowRight className="w-3.5 h-3.5 shrink-0" />
          </button>

          <a
            href={SITE_INFO.portalUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1 text-xs font-semibold text-[#174F86] hover:text-[#0B2440] transition-colors py-1 px-2 text-center min-h-[32px]"
          >
            <span>Book Visit</span>
            <ArrowUpRight className="w-3 h-3 shrink-0" />
          </a>
        </div>
      </motion.article>
    );
  }

  return (
    <motion.article
      whileHover={{ y: -5, transition: { duration: 0.25, ease: [0.16, 1, 0.3, 1] } }}
      className={`group bg-gradient-to-b from-white via-white to-[#F8FAFD] rounded-2xl border border-slate-100/90 hover:border-[#174F86]/25 transition-all duration-300 shadow-xs hover:shadow-xl hover:shadow-blue-950/5 flex flex-col h-full w-full max-w-full overflow-hidden ${
        featured ? "ring-1 ring-[#174F86]/20" : ""
      } ${className}`}
    >
      {/* Clinician Photo Container with verified original photograph */}
      <div className="relative aspect-4/5 w-full bg-[#F6F8FC] overflow-hidden">
        <img
          src={provider.image}
          alt={`${provider.name}, ${provider.credentials} - Mental health clinician at Transcending Chaos Counseling`}
          className="w-full h-full object-cover object-top group-hover:scale-102 transition-transform duration-500"
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={(e) => {
            const target = e.currentTarget;
            target.style.display = "none";
          }}
        />

        {/* Clean status badge in quiet container */}
        <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs py-1 px-2.5 rounded-md text-[11px] font-medium text-[#174F86] shadow-xs flex items-center gap-1.5 border border-slate-100">
          <CheckCircle className="w-3 h-3 text-[#174F86] shrink-0" />
          <span>Accepting New Clients</span>
        </div>

        {/* Experience Overlay */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#0B2440]/90 via-[#0B2440]/50 to-transparent p-4 text-white">
          <div className="flex items-center gap-1.5 text-xs text-[#F5BD00] font-medium">
            <Award className="w-3.5 h-3.5 shrink-0" />
            <span>{provider.experience}</span>
          </div>
        </div>
      </div>

      {/* Provider Details */}
      <div className="p-5 sm:p-6 flex flex-col flex-grow min-w-0 overflow-hidden">
        <div className="mb-3 min-w-0">
          <h3 className="font-heading font-bold text-lg sm:text-xl text-[#0B2440] group-hover:text-[#174F86] transition-colors leading-tight break-words">
            {provider.name}
          </h3>
          <p className="text-xs font-semibold text-[#174F86] tracking-wide mt-0.5 break-words">
            {provider.credentials}
          </p>
          <p className="text-xs text-slate-500 mt-1 line-clamp-2 break-words leading-snug">
            {provider.title}
          </p>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-3 mb-4 break-words">
          {provider.shortBio}
        </p>

        {/* Specialties rendered as clean typography */}
        <div className="mt-auto pt-4 border-t border-slate-100 min-w-0">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Key Specialties
          </div>
          <div className="text-xs text-slate-700 leading-relaxed flex flex-wrap gap-x-2 gap-y-1 break-words">
            {provider.specialties.slice(0, 4).map((spec, i) => (
              <span key={spec} className="inline-flex items-center break-words">
                <span>{spec}</span>
                {i < Math.min(provider.specialties.length, 4) - 1 && (
                  <span className="text-slate-300 ml-2" aria-hidden="true">
                    ·
                  </span>
                )}
              </span>
            ))}
          </div>
        </div>

        {/* Dual Actions: Stacked cleanly on mobile, side-by-side on sm+ screens */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col sm:grid sm:grid-cols-2 gap-2 w-full">
          <button
            type="button"
            onClick={() => navigate(`/providers/${provider.slug}`)}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-[#0B2440] bg-slate-100 hover:bg-[#EAF2FA] hover:text-[#174F86] transition-colors rounded-xl text-center min-h-[42px] active:scale-98"
          >
            <User className="w-3.5 h-3.5 shrink-0" />
            <span>View Profile</span>
          </button>

          <a
            href={SITE_INFO.portalUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e5b100] active:scale-98 transition-all rounded-xl text-center shadow-xs min-h-[42px]"
          >
            <span>Book Visit</span>
            <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
          </a>
        </div>
      </div>
    </motion.article>
  );
};
