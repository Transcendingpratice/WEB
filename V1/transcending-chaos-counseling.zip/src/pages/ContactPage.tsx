import React from "react";
import { SITE_INFO } from "../data/siteInfo";
import {
  Phone,
  Mail,
  Printer,
  MapPin,
  ExternalLink,
  ShieldAlert,
  Calendar,
  ArrowUpRight,
  Lock,
  UserCheck,
  CheckCircle2,
} from "lucide-react";
import {
  FadeIn,
  TextReveal,
} from "../components/motion/MotionSystem";

export const ContactPage: React.FC = () => {
  return (
    <div className="flex flex-col w-full bg-white">
      {/* Hero Header with unified color gradient overlay & blended background */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#07172B] via-[#0B2440] to-[#103761] text-white py-14 sm:py-20">
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {/* Subtle textured background image with clear visibility */}
          <img
            src="/assets/services/counseling-space.jpg"
            alt=""
            aria-hidden="true"
            className="w-full h-full object-cover object-center opacity-70 filter brightness-95 contrast-105"
            referrerPolicy="no-referrer"
          />
          {/* Full-bleed rich brand color gradient overlay across the entire width */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#071626]/85 via-[#0B2440]/70 to-[#103761]/55" />
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#F5BD00]/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#174F86]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <FadeIn direction="down" distance={16}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#F5BD00] mb-3 inline-block">
                REACH OUR PRACTICE
              </span>
            </FadeIn>

            <TextReveal
              tag="h1"
              text="Contact Transcending Chaos"
              className="font-heading font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-tight mb-4"
            />

            <FadeIn direction="up" distance={20} delay={0.15}>
              <p className="text-base sm:text-lg text-slate-200 leading-relaxed">
                We welcome your questions regarding our services, clinician availability, or scheduling an appointment. Reach us by phone, email, confidential fax, or schedule directly through our SimplePractice portal.
              </p>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Practice Details & Direct SimplePractice Portal Scheduling */}
      <section className="relative py-12 sm:py-18 bg-gradient-to-b from-[#F0F5FA] via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
            {/* Left: Contact Info & Addresses (5 cols) */}
            <div className="lg:col-span-5 flex flex-col gap-8">
              {/* Communication channels card */}
              <FadeIn direction="right" distance={24} delay={0.1}>
                <div className="p-5 sm:p-7 rounded-2xl bg-white/95 backdrop-blur-xs border border-slate-100/90 shadow-md shadow-blue-950/5 flex flex-col gap-5">
                  <h2 className="font-heading font-bold text-lg text-[#0B2440]">
                    Direct Contact Channels
                  </h2>

                  <div className="space-y-4">
                    <a
                      href={`tel:${SITE_INFO.phoneRaw}`}
                      className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[#F6F8FC] hover:bg-[#EEF4FB] border border-slate-100/80 hover:border-[#174F86]/30 transition-all duration-200 group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-[#EAF2FA] text-[#174F86] flex items-center justify-center shrink-0 group-hover:bg-[#174F86] group-hover:text-white transition-colors">
                        <Phone className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs text-slate-500 font-medium block">
                          Telephone (Direct Line)
                        </span>
                        <span className="text-base font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors">
                          {SITE_INFO.phone}
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                          Voicemails returned within 1 business day
                        </span>
                      </div>
                    </a>

                    <a
                      href={`mailto:${SITE_INFO.email}`}
                      className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[#F6F8FC] hover:bg-[#EEF4FB] border border-slate-100/80 hover:border-[#174F86]/30 transition-all duration-200 group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-[#EAF2FA] text-[#174F86] flex items-center justify-center shrink-0 group-hover:bg-[#174F86] group-hover:text-white transition-colors">
                        <Mail className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs text-slate-500 font-medium block">
                          Email Inquiries
                        </span>
                        <span className="text-sm font-bold text-[#0B2440] group-hover:text-[#174F86] transition-colors break-all">
                          {SITE_INFO.email}
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                          General practice & intake administration
                        </span>
                      </div>
                    </a>

                    <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[#F6F8FC] border border-slate-100/80">
                      <div className="w-10 h-10 rounded-lg bg-[#EAF2FA] text-[#174F86] flex items-center justify-center shrink-0">
                        <Printer className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs text-slate-500 font-medium block">
                          Confidential Medical Fax
                        </span>
                        <span className="text-sm font-bold text-[#0B2440]">
                          {SITE_INFO.fax}
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                          HIPAA-compliant document transmission
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </FadeIn>

              {/* Physical vs. Mailing Address */}
              <FadeIn direction="right" distance={24} delay={0.2}>
                <div className="p-5 sm:p-7 rounded-2xl bg-white/95 backdrop-blur-xs border border-slate-100/90 shadow-md shadow-blue-950/5 flex flex-col gap-6">
                  <h3 className="font-heading font-bold text-lg text-[#0B2440]">
                    Practice & Mailing Addresses
                  </h3>

                  <div className="space-y-4 text-sm">
                    <div className="p-4 rounded-xl bg-[#F6F8FC] border border-slate-100/80">
                      <div className="flex items-center gap-2 text-xs font-bold text-[#174F86] uppercase tracking-wider mb-1.5">
                        <MapPin className="w-4 h-4 text-[#F5BD00]" />
                        <span>Physical Practice Office</span>
                      </div>
                      <p className="font-bold text-[#0B2440] text-sm">
                        1 Bridgeview Circle, Suite 5
                      </p>
                      <p className="text-slate-600 text-xs">
                        Tyngsborough, MA 01879-2053
                      </p>
                      <p className="text-[11px] text-slate-500 mt-2 italic">
                        *For scheduled in-person therapy sessions and clinical evaluations. Ample on-site parking available.
                      </p>
                      <a
                        href="https://maps.google.com/?q=1+Bridgeview+Circle+Suite+5+Tyngsborough+MA+01879"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#174F86] hover:underline mt-3"
                      >
                        <span>Open in Google Maps</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    <div className="p-4 rounded-xl bg-[#F6F8FC] border border-slate-100/80">
                      <div className="flex items-center gap-2 text-xs font-bold text-[#174F86] uppercase tracking-wider mb-1.5">
                        <Mail className="w-4 h-4 text-[#F5BD00]" />
                        <span>Official Mailing Address</span>
                      </div>
                      <p className="font-bold text-[#0B2440] text-sm">
                        265 Chelmsford St., Suite 7
                      </p>
                      <p className="text-slate-600 text-xs">
                        Chelmsford, MA 01824-2665
                      </p>
                      <p className="text-[11px] text-slate-500 mt-2 italic">
                        *Please direct all official mail, legal requests, insurance verification, and billing correspondence to this address.
                      </p>
                    </div>
                  </div>
                </div>
              </FadeIn>
            </div>

            {/* Right: Direct SimplePractice Scheduling & Client Portal (7 cols) */}
            <div className="lg:col-span-7 flex flex-col">
              <FadeIn direction="left" distance={24} delay={0.15}>
                <div className="p-6 sm:p-8 md:p-10 rounded-2xl bg-white border border-slate-100/90 shadow-xl shadow-blue-950/5 flex flex-col gap-6">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-[#174F86] block mb-1.5">
                      ONLINE SCHEDULING & CLIENT PORTAL
                    </span>
                    <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-[#0B2440] leading-tight">
                      Book Your Appointment Directly via SimplePractice
                    </h2>
                    <p className="text-sm sm:text-base text-slate-600 mt-3 leading-relaxed">
                      To protect your privacy and streamline care, all appointment requests, intake paperwork, and secure client messaging are handled exclusively through our encrypted, HIPAA-compliant SimplePractice portal.
                    </p>
                  </div>

                  {/* Primary Scheduling & Sign-In Actions */}
                  <div className="flex flex-col gap-3.5 pt-2">
                    <a
                      href={SITE_INFO.portalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full inline-flex items-center justify-center gap-2.5 py-4 px-6 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0B2440] bg-[#F5BD00] hover:bg-[#e0ad00] active:scale-98 transition-all rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 text-center"
                    >
                      <Calendar className="w-4 h-4 text-[#0B2440] shrink-0" />
                      <span>Launch Appointment Scheduling Portal</span>
                      <ArrowUpRight className="w-4 h-4 shrink-0" />
                    </a>

                    <a
                      href={SITE_INFO.portalSignInUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full inline-flex items-center justify-center gap-2.5 py-3.5 px-6 text-xs sm:text-sm font-semibold text-[#174F86] bg-[#EAF2FA] hover:bg-[#d9e8f7] active:scale-98 transition-all rounded-xl text-center"
                    >
                      <UserCheck className="w-4 h-4 shrink-0" />
                      <span>Existing Client Portal Sign-In</span>
                      <ArrowUpRight className="w-4 h-4 shrink-0" />
                    </a>
                  </div>

                  {/* Portal Benefits */}
                  <div className="pt-6 border-t border-slate-100 space-y-3">
                    <h3 className="font-heading font-bold text-sm text-[#0B2440]">
                      What You Can Do Inside the Portal
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-600">
                      <div className="p-3.5 rounded-xl bg-[#F6F8FC] border border-slate-100/80 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0 mt-0.5" />
                        <span>Browse real-time clinician availability for in-person & virtual slots</span>
                      </div>
                      <div className="p-3.5 rounded-xl bg-[#F6F8FC] border border-slate-100/80 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0 mt-0.5" />
                        <span>Select Cassandra, Erica, or Deb based on your clinical focus</span>
                      </div>
                      <div className="p-3.5 rounded-xl bg-[#F6F8FC] border border-slate-100/80 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0 mt-0.5" />
                        <span>Complete confidential digital intake forms prior to your visit</span>
                      </div>
                      <div className="p-3.5 rounded-xl bg-[#F6F8FC] border border-slate-100/80 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-[#174F86] shrink-0 mt-0.5" />
                        <span>Message your provider securely and manage upcoming sessions</span>
                      </div>
                    </div>
                  </div>

                  {/* Security & Direct Phone Callout */}
                  <div className="p-4 rounded-xl bg-[#0B2440] text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 text-slate-200">
                      <Lock className="w-4 h-4 text-[#F5BD00] shrink-0" />
                      <span>256-bit HIPAA-compliant encryption via SimplePractice.</span>
                    </div>
                    <a
                      href={`tel:${SITE_INFO.phoneRaw}`}
                      className="text-[#F5BD00] hover:text-white font-semibold whitespace-nowrap transition-colors"
                    >
                      Need help? Call {SITE_INFO.phone}
                    </a>
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Crisis Resource Banner */}
      <section className="py-8 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-5 h-5 text-[#F5BD00] shrink-0" />
              <span className="text-slate-300">
                <strong>Emergency Notice:</strong> This website is not monitored 24/7 and should not be used for acute psychological crises. If you are in immediate danger, call <strong>911</strong> or text/call <strong>988</strong>.
              </span>
            </div>
            <a
              href="tel:988"
              className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-[#F5BD00] font-mono text-xs font-bold whitespace-nowrap transition-colors"
            >
              Suicide & Crisis Lifeline: 988
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
