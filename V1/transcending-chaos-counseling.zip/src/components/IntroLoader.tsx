import React, { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "motion/react";

interface IntroLoaderProps {
  onComplete: () => void;
}

export const IntroLoader: React.FC<IntroLoaderProps> = ({ onComplete }) => {
  const [isExiting, setIsExiting] = useState(false);
  const reduce = useReducedMotion();

  // TOTAL: 7s + 0.8s fade = 7.8s
  useEffect(() => {
    if (reduce) { onComplete(); return; }
    const t1 = setTimeout(() => setIsExiting(true), 7000);
    const t2 = setTimeout(() => onComplete(), 7800);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onComplete, reduce]);

  return (
    <AnimatePresence>
      {!isExiting && (
        <motion.div
          key="cinematic-intro"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.06, filter: "blur(14px) brightness(1.2)" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-[100] overflow-hidden select-none bg-[#050D1A]"
        >
          {/* ===== CINEMATIC BACKGROUND - Deep Navy + Cinematic Light ===== */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,#0B2440_0%,#071626_45%,#030A14_100%)]" />

          {/* Cinematic Light Beam from Top */}
          <motion.div
            initial={{ opacity: 0, scaleY: 0 }}
            animate={{ opacity: [0, 0.5, 0.35], scaleY: 1 }}
            transition={{ duration: 2.2, delay: 0.2, ease: "easeOut" }}
            className="absolute left-1/2 top-0 -translate-x-1/2 w-[1px] h-[70vh] bg-gradient-to-b from-white/60 via-[#F5BD00]/40 to-transparent blur-[1px]"
          />
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.25, 0.15] }}
            transition={{ duration: 2.5, delay: 0.4 }}
            className="absolute left-1/2 top-0 -translate-x-1/2 w-[420px] h-[520px] bg-[radial-gradient(ellipse_at_top,rgba(245,189,0,0.22)_0%,transparent_65%)] blur-2xl"
          />

          {/* Vignette - Film Look */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(0,0,0,0.65)_100%)]" />

          {/* ===== CENTER STAGE - Canvas scaled responsively ===== */}
          <div className="relative h-full w-full flex flex-col items-center justify-center px-4">

            {/* Skip button for user convenience */}
            <button
              type="button"
              onClick={() => setIsExiting(true)}
              className="absolute top-5 right-5 z-30 px-3 py-1.5 rounded-full text-[10px] font-semibold tracking-wider uppercase text-white/50 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 backdrop-blur-md transition-all cursor-pointer"
            >
              Skip
            </button>

            <div className="relative w-[270px] h-[270px] xs:w-[320px] xs:h-[320px] sm:w-[480px] sm:h-[480px] max-w-[94vw] max-h-[94vw] flex items-center justify-center">

              {/* --- SCENE 1: MAGICAL RINGS FORMING (0s - 2s) --- */}
              {/* Outer Golden Thin Ring - draws slowly like in brand films */}
              <svg viewBox="0 0 480 480" className="absolute inset-0 w-full h-full overflow-visible" fill="none">
                <motion.circle cx="240" cy="240" r="218" stroke="#F5BD00" strokeWidth="0.8" opacity={0.55}
                  initial={{ pathLength: 0, rotate: -90 }} animate={{ pathLength: 1, rotate: 0 }}
                  transition={{ duration: 2.2, delay: 0.3, ease: [0.65, 0, 0.35, 1] }}
                  style={{ transformOrigin: "240px 240px" }} />
                <motion.circle cx="240" cy="240" r="196" stroke="#2A73BA" strokeWidth="0.6" opacity={0.4} strokeDasharray="1 5"
                  initial={{ pathLength: 0, rotate: 90 }} animate={{ pathLength: 1, rotate: 0 }}
                  transition={{ duration: 2.4, delay: 0.6, ease: [0.65, 0, 0.35, 1] }}
                  style={{ transformOrigin: "240px 240px" }} />
                <motion.circle cx="240" cy="240" r="172" stroke="white" strokeWidth="0.5" opacity={0.25}
                  initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
                  transition={{ duration: 1.8, delay: 1.0, ease: "easeInOut" }} />

                {/* Elegant Curved Lines - MedHeave inspired but cinematic */}
                <motion.path d="M 240 8 C 340 8 472 110 472 240 C 472 370 340 472 240 472" stroke="#F5BD00" strokeWidth="0.8" opacity={0.35}
                  initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
                  transition={{ duration: 2.0, delay: 1.4, ease: "easeInOut" }} />
                <motion.path d="M 240 472 C 140 472 8 370 8 240 C 8 110 140 8 240 8" stroke="#2A73BA" strokeWidth="0.8" opacity={0.35}
                  initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
                  transition={{ duration: 2.0, delay: 1.6, ease: "easeInOut" }} />

                {/* Golden Spark Dots travelling on rings */}
                <motion.circle r="3" fill="#F5BD00" style={{ filter: "drop-shadow(0 0 6px #F5BD00)" }}
                  initial={{ cx: 240, cy: 22, opacity: 0 }} animate={{ cx: 458, cy: 240, opacity: [0, 1, 1, 0] }}
                  transition={{ duration: 1.8, delay: 2.2, ease: "easeInOut" }} />
                <motion.circle r="2.2" fill="#fff" style={{ filter: "drop-shadow(0 0 6px white)" }}
                  initial={{ cx: 22, cy: 240, opacity: 0 }} animate={{ cx: 240, cy: 458, opacity: [0, 1, 1, 0] }}
                  transition={{ duration: 1.8, delay: 2.5, ease: "easeInOut" }} />
              </svg>

              {/* --- SCENE 2: LOGO APPEARS LIKE MAGIC (1.2s - 3.5s) --- */}
              <div className="relative w-[210px] h-[210px] sm:w-[280px] sm:h-[280px] flex items-center justify-center">

                {/* Magical Golden Glow Pulse behind logo */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.6 }}
                  animate={{ opacity: [0, 0.7, 0.35], scale: [0.6, 1.15, 1] }}
                  transition={{ duration: 2.2, delay: 1.0, ease: "easeOut" }}
                  className="absolute inset-[-30px] rounded-full bg-[radial-gradient(circle,rgba(245,189,0,0.45)_0%,rgba(42,115,186,0.18)_45%,transparent_70%)] blur-[22px]"
                />

                {/* The Real Emblem - Cinematic Reveal */}
                <motion.img
                  src="/assets/logo/logo-original-1.png"
                  alt="Transcending Chaos Counseling"
                  draggable={false}
                  initial={{ opacity: 0, scale: 0.7, filter: "blur(18px) brightness(2)", y: 12 }}
                  animate={{
                    opacity: 1,
                    scale: [0.7, 1.06, 1],
                    filter: ["blur(18px) brightness(2)", "blur(0px) brightness(1.15)", "blur(0px) brightness(1)"],
                    y: 0,
                  }}
                  transition={{
                    duration: 2.2,
                    delay: 1.2,
                    times: [0, 0.7, 1],
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  className="w-full h-full object-contain relative z-10 drop-shadow-[0_0_45px_rgba(245,189,0,0.45)]"
                />

                {/* Shine Sweep across logo - like light passing in films */}
                <motion.div
                  initial={{ x: "-130%", opacity: 0, rotate: 12 }}
                  animate={{ x: "130%", opacity: [0, 0.55, 0] }}
                  transition={{ duration: 1.1, delay: 3.2, ease: "easeInOut" }}
                  className="absolute inset-0 z-20 w-[35%] bg-gradient-to-r from-transparent via-white/70 to-transparent blur-md pointer-events-none"
                />

                {/* Breathing after reveal - subtle alive feel */}
                <motion.div
                  animate={{ scale: [1, 1.025, 1], opacity: [0.2, 0.35, 0.2] }}
                  transition={{ duration: 3, delay: 3.8, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute inset-[-12px] rounded-full bg-[#F5BD00]/20 blur-[18px] -z-0"
                />
              </div>

              {/* --- SCENE 3: RADIAL LINES EXPLODE SOFTLY OUTWARD (2.8s - 4.5s) --- */}
              <svg viewBox="0 0 480 480" className="absolute inset-0 w-full h-full overflow-visible pointer-events-none" fill="none">
                {[
                  { x1: 240, y1: 28, x2: 240, y2: 78 },
                  { x1: 240, y1: 452, x2: 240, y2: 402 },
                  { x1: 28, y1: 240, x2: 78, y2: 240 },
                  { x1: 452, y1: 240, x2: 402, y2: 240 },
                  { x1: 92, y1: 92, x2: 128, y2: 128 },
                  { x1: 388, y1: 92, x2: 352, y2: 128 },
                  { x1: 92, y1: 388, x2: 128, y2: 352 },
                  { x1: 388, y1: 388, x2: 352, y2: 352 },
                ].map((l, i) => (
                  <motion.line key={i} x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2}
                    stroke={i % 2 === 0 ? "#F5BD00" : "#2A73BA"} strokeWidth="1.2" strokeLinecap="round"
                    initial={{ pathLength: 0, opacity: 0 }}
                    animate={{ pathLength: 1, opacity: 0.75 }}
                    transition={{ delay: 2.9 + i * 0.08, duration: 0.9, ease: [0.22, 1, 0.36, 1] }} />
                ))}
                {/* Small golden dots at line ends */}
                {[
                  { cx: 240, cy: 28 }, { cx: 240, cy: 452 }, { cx: 28, cy: 240 }, { cx: 452, cy: 240 },
                ].map((p, i) => (
                  <motion.circle key={`dot-${i}`} cx={p.cx} cy={p.cy} r="2.2" fill="#F5BD00"
                    initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 3.8 + i * 0.1, duration: 0.4 }}
                    style={{ filter: "drop-shadow(0 0 5px #F5BD00)" }} />
                ))}
              </svg>
            </div>

            {/* --- SCENE 4: BRAND NAME - Letter by Letter Cinematic Reveal (4.2s - 6.2s) --- */}
            <div className="mt-[-10px] sm:mt-[-16px] text-center relative z-10 max-w-full px-2">
              <div className="overflow-hidden">
                <motion.h1
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ delay: 4.2, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                  className="text-[17px] xs:text-[21px] sm:text-[32px] font-extrabold tracking-[0.12em] xs:tracking-[0.18em] sm:tracking-[0.22em] uppercase text-white leading-none"
                >
                  Transcending <span className="text-[#F5BD00]">Chaos</span>
                </motion.h1>
              </div>

              {/* Golden thin line under title - draws left to right */}
              <motion.div
                initial={{ scaleX: 0, opacity: 0 }}
                animate={{ scaleX: 1, opacity: 1 }}
                transition={{ delay: 5.0, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                className="mx-auto mt-3 sm:mt-4 h-px w-[140px] xs:w-[180px] sm:w-[240px] bg-gradient-to-r from-transparent via-[#F5BD00] to-transparent"
              />

              <motion.p
                initial={{ opacity: 0, letterSpacing: "0.5em", y: 8 }}
                animate={{ opacity: 1, letterSpacing: "0.36em", y: 0 }}
                transition={{ delay: 5.3, duration: 0.9, ease: "easeOut" }}
                className="text-[9px] xs:text-[10px] sm:text-[12px] font-semibold uppercase text-[#A8C4E0] mt-2.5 sm:mt-3 pl-1 sm:pl-2"
              >
                Counseling
              </motion.p>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 5.8, duration: 0.8 }}
                className="text-[9px] xs:text-[10px] sm:text-[11px] tracking-[0.12em] xs:tracking-[0.18em] uppercase text-white/45 mt-2 sm:mt-3"
              >
                Therapy & Clinical Sanctuary · MA & NH
              </motion.p>
            </div>

            {/* --- SCENE 5: Final Glow Bloom (6.2s - 7s) --- */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: [0, 0.5, 0.25], scale: [0.9, 1.1, 1] }}
              transition={{ delay: 6.2, duration: 0.8, ease: "easeOut" }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] rounded-full bg-[#F5BD00]/10 blur-[80px] pointer-events-none"
            />
          </div>

          {/* Bottom Cinematic Bars - Film Look */}
          <motion.div initial={{ scaleY: 0 }} animate={{ scaleY: 1 }} transition={{ delay: 0.1, duration: 0.6 }} className="absolute top-0 left-0 right-0 h-[3px] bg-black/60 origin-top" />
          <motion.div initial={{ scaleY: 0 }} animate={{ scaleY: 1 }} transition={{ delay: 0.1, duration: 0.6 }} className="absolute bottom-0 left-0 right-0 h-[3px] bg-black/60 origin-bottom" />
        </motion.div>
      )}
    </AnimatePresence>
  );
};